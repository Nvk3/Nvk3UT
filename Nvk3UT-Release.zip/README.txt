Nvk3UT v0.4.10 — stable To‑Do: single category + safe in‑panel Top‑Category dropdown filter. No tree injection, no crashes; search respected; live rebuild.
