---------------------------------------------------
-- FRENCH LOCALIZATION FOR ENDEAVOR TRACKER --
---------------------------------------------------

-- SafeAddString(SI_TIMEDACTIVITYTYPE0, "Journalière", 0)
-- SafeAddString(SI_TIMEDACTIVITYTYPE1, "Hebdomadaire", 1)

ZO_CreateStringId("ENDEAVOR_TRACKER_Misc_HighEndeavorReward", "HAUTE RÉCOMPENSE")
ZO_CreateStringId("ENDEAVOR_TRACKER_Misc_Rewards", "Récompenses ")

-- DEFAULTS --
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings1", "Désactivé")
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings2", "Volontés manquantes")
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings3", "Journalières manquantes seulement")
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings4", "Hebdomadaires manquantes seulement")
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings5", "Toujours affiché")

-- PANEL --
ZO_CreateStringId("ENDEAVOR_TRACKER_HeaderEndeavorsCompleted", "<<Z:1>>S : ACCOMPLIES")
ZO_CreateStringId("ENDEAVOR_TRACKER_HeaderEndeavorsInProgress", "<<Z:1>>S : EN COURS")
ZO_CreateStringId("ENDEAVOR_TRACKER_HeaderEndeavorsNotStarted", "<<Z:1>>S : PAS COMMENCÉ")

-- CHAT MESSAGES --
ZO_CreateStringId("ENDEAVOR_TRACKER_ChatMsgEndeavorProgress", "Volonté <<c:1>> en cours ")
ZO_CreateStringId("ENDEAVOR_TRACKER_ChatMsgEndeavorCompleted", "Volonté <<c:1>> accomplie")
ZO_CreateStringId("ENDEAVOR_TRACKER_ChatMsgNewEndeavorsAvailable", "Nouvelles volontés disponibles !")
ZO_CreateStringId("ENDEAVOR_TRACKER_ChatMsgListRefreshed", "Liste de volontés actualisée !")

-- SETTINGS MENU --
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsTogglePanel", "|cECB8A2/et|r |c7E7E7E- Afficher/masquer Endeavour Tracker|r")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsToggleHistory", "|cECB8A2/ethistory|r |c7E7E7E- Afficher/masquer l'histoire des volontés|r")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsToggleSettings", "|cECB8A2/ethelp|r |c7E7E7E- Ouvrir ces paramètres|r")

ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsFeedbackButton", "Envoyer des commentaires")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsFeedbackTooltip", "Envoyez-moi des rapports de bugs, des commentaires ou des suggestions !")

ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsHeaderDisplayOptions", "Option d'affichage")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayInCombat", "Afficher pendant le combat")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayInDungeons", "Afficher dans les donjons et les épreuves")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayInCyroAndBGs", "Afficher dans Cyrodiil, la cité impériale et Champs de bataille")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayShortcutIcon", "Afficher l'icône de raccourci")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayCheckboxes", "Afficher les cases à cocher")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayTimeRemaining", "Afficher le temps restant jusqu'à la réinitialisation")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsHideCompleted", "Afficher/masquer automatiquement les sections terminées")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsShowPanel", "Afficher le panneau Endeavour Tracker")

ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsHeaderCustomization", "Options de personnalisation")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsFontSize", "Changer la taille de la police")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayBackground", "Afficher la texture d'arrière-plan")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsBackdropAlpha", "Opacité d'arrière-plan")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsColorCompleted", "Volontés accomplies")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsColorInProgress", "Volontés en cours")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsColorNotStartedHeader", "Volontés non commencées (en-tête)")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsColorNotStartedList", "Volontés non commencées (liste)")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsPanelAnchor", "Panneau d'ancrage depuis le bas")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsPanelAnchorTooltip", "Lorsqu'il est activé, le panneau Endeavour Tracker s'agrandira verticalement vers le haut plutôt que vers le bas.")

ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsHeaderChatOptions", "Options de messages")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsPostProgressUpdates", "Publier les mises à jour sur le chat")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsPostCompletionMessage", "Publier l'achèvement des volontés dans le chat")

-- TOOLTIPS --
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipRefresh", "Rafraîchir")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipHistoryButton", "L'histoire des volontés")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipEndeavorTotal", "Votre total de Sceaux des Volontés\n(Click to open store)")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipDailyExpandButton", "Montrer les volontés journalières")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipDailyCollapseButton", "Masquer les volontés journalières")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipWeeklyExpandButton", "Montrer les volontés hebdomadaires")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipWeeklyCollapseButton", "Masquer les volontés hebdomadaires")

-- BINDINGS --
ZO_CreateStringId("SI_BINDING_NAME_ENDEAVOR_TRACKER_TOGGLE", "Activer/désactiver Endeavor Tracker")

-- HISTORY PANEL
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelDailiesButton", "Journaliéres accomplies")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelWeekliesButton", "Hebdomadaires accomplies")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStatsButton", "Statistiques")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelTrackingDate", "|cC5C29ESuivi depuis :|r ")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelTrackingDateTooltip", "Les valeurs sont estimées et peuvent ne pas être exactes.")

ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelHeaderDate", "Date")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelHeaderName", "Nom")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelHeaderRewards", "Récompenses")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelHeaderMisc", "Autre")

ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalDailyCompleted", "Total des volontés journaliéres accomplies")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalWeeklyCompleted", "Total des volontés hebdomadaires accomplies")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalSealsDailies", "Total des sceaux des volontés journaliéres")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalSealsWeeklies", "Total des sceaux des volontés hebdomadaires")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_AverageSealsDailies", "Sceaux moyens des volontés journaliéres")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_AverageSealsWeeklies", "Sceaux moyens des volontés hebdomadaires")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_MostSealsDailies", "La plupart des sceaux acquis d'un seule volonté journaliére")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_MostSealsWeeklies", "La plupart des sceaux acquis d'un seule volonté hebdomadaire")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalLifetimeSeals", "Total des sceaux des volontés à vie acquis")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalSealsSpent", "Total des sceaux des volontés dépensés")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_CurrentTotalSeals", "Total actuel des sceaux des volontés")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalGoldAcquired", "Total de l'or acquis des volontés")
