---------------------------------------------------
-- ENGLISH LOCALIZATION FOR ENDEAVOR TRACKER --
---------------------------------------------------

-- SafeAddString(SI_TIMEDACTIVITYTYPE0, "Daily", 0)
-- SafeAddString(SI_TIMEDACTIVITYTYPE1, "Weekly", 1)

ZO_CreateStringId("ENDEAVOR_TRACKER_Misc_HighEndeavorReward", "HIGH ENDEAVOR REWARD")
ZO_CreateStringId("ENDEAVOR_TRACKER_Misc_Rewards", "Rewards")

-- DEFAULTS --
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings1", "Off")
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings2", "Missing endeavors")
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings3", "Missing dailies only")
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings4", "Missing weeklies only")
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings5", "Always on")

-- PANEL --
ZO_CreateStringId("ENDEAVOR_TRACKER_HeaderEndeavorsCompleted", "<<Z:1>> ENDEAVORS: COMPLETED")
ZO_CreateStringId("ENDEAVOR_TRACKER_HeaderEndeavorsInProgress", "<<Z:1>> ENDEAVORS: IN PROGRESS")
ZO_CreateStringId("ENDEAVOR_TRACKER_HeaderEndeavorsNotStarted", "<<Z:1>> ENDEAVORS: NOT STARTED")

-- CHAT MESSAGES --
ZO_CreateStringId("ENDEAVOR_TRACKER_ChatMsgEndeavorProgress", "<<1>> Endeavor Progress")
ZO_CreateStringId("ENDEAVOR_TRACKER_ChatMsgEndeavorCompleted", "<<1>> Endeavor Completed")
ZO_CreateStringId("ENDEAVOR_TRACKER_ChatMsgNewEndeavorsAvailable", "New endeavors available!")
ZO_CreateStringId("ENDEAVOR_TRACKER_ChatMsgListRefreshed", "Endeavor list refreshed!")

-- SETTINGS MENU --
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsTogglePanel", "|cECB8A2/et|r |c7E7E7E- Toggle the Endeavor Tracker panel|r")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsToggleHistory", "|cECB8A2/ethistory|r |c7E7E7E- Show Endeavor History|r")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsToggleSettings", "|cECB8A2/ethelp|r |c7E7E7E- Open these settings|r")

ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsFeedbackButton", "Send feedback")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsFeedbackTooltip", "Send me a mail with any bug reports, feedback, or suggestions!")

ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsHeaderDisplayOptions", "Display Options")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayInCombat", "Display during combat")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayInDungeons", "Display in dungeons and trials")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayInCyroAndBGs", "Display in Cyrodiil, Imperial City and battlegrounds")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayShortcutIcon", "Display the shortcut icon")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayCheckboxes", "Display checkboxes")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayTimeRemaining", "Show time remaining until reset")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsHideCompleted", "Automatically show/hide completed sections")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsShowPanel", "Display the Endeavor Tracker panel")

ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsHeaderCustomization", "Customization Options")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsFontSize", "Change font size")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayBackground", "Display background texture")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsBackdropAlpha", "Background Opacity")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsColorCompleted", "Completed Endeavors")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsColorInProgress", "Endeavors in Progress")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsColorNotStartedHeader", "Endeavors not Started (header)")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsColorNotStartedList", "Endeavors not Started (list)")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsPanelAnchor", "Anchor panel from below")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsPanelAnchorTooltip", "When enabled, the Endeavor Tracker panel will grow vertically upwards instead of downwards. ")

ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsHeaderChatOptions", "Chat Options")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsPostProgressUpdates", "Post endeavor progress updates to chat")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsPostCompletionMessage", "Post completion of endeavors in chat")

-- TOOLTIPS --
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipRefresh", "Refresh Endeavor List")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipHistoryButton", "Endeavor History")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipEndeavorTotal", "Your total Seals of Endeavor\n(Click to open store)")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipDailyExpandButton", "Show Daily Endeavors")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipDailyCollapseButton", "Hide Daily Endeavors")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipWeeklyExpandButton", "Show Weekly Endeavors")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipWeeklyCollapseButton", "Hide Weekly Endeavors")

-- BINDINGS --
ZO_CreateStringId("SI_BINDING_NAME_ENDEAVOR_TRACKER_TOGGLE", "Toggle Endeavor Tracker")

-- HISTORY PANEL
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelDailiesButton", "Completed Dailies")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelWeekliesButton", "Completed Weeklies")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStatsButton", "Stats")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelTrackingDate", "|cC5C29ETracking since:|r ")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelTrackingDateTooltip", "Values are estimates and may not be accurate.")

ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelHeaderDate", "Date")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelHeaderName", "Name")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelHeaderRewards", "Rewards")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelHeaderMisc", "Misc")

ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalDailyCompleted", "Total daily endeavors completed")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalWeeklyCompleted", "Total weekly endeavors completed")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalSealsDailies", "Total seals from daily endeavors")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalSealsWeeklies", "Total seals from weekly endeavors")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_AverageSealsDailies", "Average seals from daily endeavors")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_AverageSealsWeeklies", "Average seals from weekly endeavors")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_MostSealsDailies", "Most seals acquired from a single daily endeavor")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_MostSealsWeeklies", "Most seals acquired from a single weekly endeavor")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalLifetimeSeals", "Total lifetime seals of endeavor acquired")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalSealsSpent", "Total seals of endeavor spent")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_CurrentTotalSeals", "Current total seals of endeavor")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalGoldAcquired", "Total gold acquired from endeavors")
