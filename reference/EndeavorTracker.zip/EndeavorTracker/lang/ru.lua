---------------------------------------------------
-- RUSSIAN LOCALIZATION FOR ENDEAVOR TRACKER --
---------------------------------------------------

-- SafeAddString(SI_TIMEDACTIVITYTYPE0, "Ежедневные", 0)
-- SafeAddString(SI_TIMEDACTIVITYTYPE1, "Еженедельные", 1)

ZO_CreateStringId("ENDEAVOR_TRACKER_Misc_HighEndeavorReward", "ВЫСОКОЕ НАГРАЖДЕНИЕ")
ZO_CreateStringId("ENDEAVOR_TRACKER_Misc_Rewards", "Награды")

-- DEFAULTS --
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings1", "выключено")
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings2", "Невыполненные свершения")
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings3", "Невыполненные ежедневные свершения")
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings4", "Невыполненные еженедельные свершения")
ZO_CreateStringId("ENDEAVOR_TRACKER_DefaultsDisplaySettings5", "Всегда включено")

-- PANEL --
ZO_CreateStringId("ENDEAVOR_TRACKER_HeaderEndeavorsCompleted", "<<Z:1>>: ЗАВЕРШЕНО")
ZO_CreateStringId("ENDEAVOR_TRACKER_HeaderEndeavorsInProgress", "<<Z:1>>: В ПРОЦЕССЕ")
ZO_CreateStringId("ENDEAVOR_TRACKER_HeaderEndeavorsNotStarted", "<<Z:1>>: НЕ НАЧАТО")

-- CHAT MESSAGES --
ZO_CreateStringId("ENDEAVOR_TRACKER_ChatMsgEndeavorProgress", "<<1>> прогресс свершения")
ZO_CreateStringId("ENDEAVOR_TRACKER_ChatMsgEndeavorCompleted", "<<1>> свершение выполнено")
ZO_CreateStringId("ENDEAVOR_TRACKER_ChatMsgNewEndeavorsAvailable", "Доступны новые свершения!")
ZO_CreateStringId("ENDEAVOR_TRACKER_ChatMsgListRefreshed", "Список свершений обновлён!")

-- SETTINGS MENU --
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsTogglePanel", "|cECB8A2/et|r |c7E7E7E- Показать/спрятать Endeavor Tracker|r")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsToggleHistory", "|cECB8A2/ethistory|r |c7E7E7E- Показать/спрятать Endeavor History|r")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsToggleSettings", "|cECB8A2/ethelp|r |c7E7E7E- Откройте эти настройки|r")

ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsFeedbackButton", "Отправить отзыв")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsFeedbackTooltip", "Отправьте мне письмо с любыми сообщением об ошибках, отзывом или предложением!")

ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsHeaderDisplayOptions", "Настройки отображения")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayInCombat", "Показывать во время боя")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayInDungeons", "Показывать во подземелья и испытаниях")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayInCyroAndBGs", "Показывать в Сиродиле, Имперском городе и полях сражений")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayShortcutIcon", "Показывать значок быстрого доступа")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayCheckboxes", "Показывать флажки")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayTimeRemaining", "Показывать время до обновления свершений")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsHideCompleted", "Автоматически скрывать выполненные свершения")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsShowPanel", "Показывать панель аддона Endeavor Tracker")

ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsHeaderCustomization", "Дополнительные настройки")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsFontSize", "Изменить размер шрифта")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsDisplayBackground", "Показывать фон")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsColorCompleted", "Завершенные свершения")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsBackdropAlpha", "Непрозрачность фона")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsColorInProgress", "Свершения в процессе")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsColorNotStartedHeader", "Неначатые свершения (заголовок)")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsColorNotStartedList", "Неначатые свершения (список)")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsPanelAnchor", "Анкерная панель снизу")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsPanelAnchorTooltip", "Если этот параметр включен, панель Endeavour Tracker будет расти вертикально вверх, а не вниз.")

ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsHeaderChatOptions", "Опции чата")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsPostProgressUpdates", "Публиковать обновления в чат")
ZO_CreateStringId("ENDEAVOR_TRACKER_SettingsPostCompletionMessage", "Опубликовать завершение свершения в чат")

-- TOOLTIPS --
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipRefresh", "Обновить лист свершений")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipHistoryButton", "Endeavor History")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipEndeavorTotal", "Ваши печати свершений\n(Открыть магазин)")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipDailyExpandButton", "Показать ежедневные свершения")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipDailyCollapseButton", "Скрыть ежедневные свершения")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipWeeklyExpandButton", "Показать еженедельные свершения")
ZO_CreateStringId("ENDEAVOR_TRACKER_TooltipWeeklyCollapseButton", "Скрыть еженежельные свершения")

-- BINDINGS --
ZO_CreateStringId("SI_BINDING_NAME_ENDEAVOR_TRACKER_TOGGLE", "Показать/спрятать Endeavor Tracker")

-- HISTORY PANEL
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelDailiesButton", "Ежедневные свершения")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelWeekliesButton", "Еженедельные свершения")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStatsButton", "Статистика")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelTrackingDate", "|cC5C29EОтслеживается с:|r ")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelTrackingDateTooltip", "Значения могут быть неточными.")

ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelHeaderDate", "Дата")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelHeaderName", "Название")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelHeaderRewards", "Награда")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelHeaderMisc", "Разное")

ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalDailyCompleted", "Всего ежедневных свершения завершено")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalWeeklyCompleted", "Всего еженедельных свершения завершено")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalSealsDailies", "Всего печатей получено за ежедневные свершения")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalSealsWeeklies", "Всего печатей получено за еженедельные свершения")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_AverageSealsDailies", "Печатей в среднем за ежедневные свершение")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_AverageSealsWeeklies", "Печатей в среднем за еженедельное свершение")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_MostSealsDailies", "Наибольшее количество печатей за ежедневное свершение")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_MostSealsWeeklies", "Наибольшее количество печатей за еженедельное свершение")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalLifetimeSeals", "Всего получено печатей за свершения")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalSealsSpent", "Всего потрачено печатей")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_CurrentTotalSeals", "Текущее количество печатей")
ZO_CreateStringId("ENDEAVOR_TRACKER_HistoryPanelStats_TotalGoldAcquired", "Всего получено золота за свершения")
