﻿-- Translation by @lexo1000
SafeAddString(SI_VOTANS_ACHIEVEMENT_FAVORITES, "Favoris")
SafeAddString(SI_VOTANS_ACHIEVEMENT_FAVORITE_ADD, "Ajouter aux favoris")
SafeAddString(SI_VOTANS_ACHIEVEMENT_FAVORITE_REMOVE, "Retirer des favoris")