ZO_CreateStringId("SI_VOTANS_ACHIEVEMENT_FAVORITES", "Favorites")
ZO_CreateStringId("SI_VOTANS_ACHIEVEMENT_FAVORITE_ADD", "Add to Favorites")
ZO_CreateStringId("SI_VOTANS_ACHIEVEMENT_FAVORITE_REMOVE", "Remove from Favorites")
