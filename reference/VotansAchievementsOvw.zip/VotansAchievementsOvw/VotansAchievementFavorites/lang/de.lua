﻿SafeAddString(SI_VOTANS_ACHIEVEMENT_FAVORITES, "Favoriten")
SafeAddString(SI_VOTANS_ACHIEVEMENT_FAVORITE_ADD, "Zu Favoriten hinzufügen")
SafeAddString(SI_VOTANS_ACHIEVEMENT_FAVORITE_REMOVE, "Von Favoriten entfernen")
