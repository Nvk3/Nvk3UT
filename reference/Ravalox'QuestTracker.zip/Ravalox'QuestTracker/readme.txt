﻿; This dummy files are provided to overwrite the obsolete folder with the old add-on name.
; There is no problem in manually discarding the folder containing this file, including its contents.
