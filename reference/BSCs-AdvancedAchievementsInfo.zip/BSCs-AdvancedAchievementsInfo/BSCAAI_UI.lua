BSCAAchievemntsInfo = BSCAAchievemntsInfo or {}
local BSCAAI = BSCAAchievemntsInfo

function BSCAAI:InitTrackingUI()
	BSCAAI.TrackingFragment = ZO_SimpleSceneFragment:New(BSCAAI_FavWidget)
	BSCAAI:RestoreFavWidgetPosition()
	BSCAAI:AdjustTrackingLayout()
	BSCAAI.UpdateFavWidget()
	BSCAAI:UpdateSettings()
end
function BSCAAI:UpdateSettings()
	if BSCAAI.SV_CHAR.UI_ENABLE then
		SCENE_MANAGER:GetScene("hud"):AddFragment(BSCAAI.TrackingFragment)
		SCENE_MANAGER:GetScene("hudui"):AddFragment(BSCAAI.TrackingFragment)				
	else		
		SCENE_MANAGER:GetScene("hud"):RemoveFragment(BSCAAI.TrackingFragment)
		SCENE_MANAGER:GetScene("hudui"):RemoveFragment(BSCAAI.TrackingFragment)
	end
end
function BSCAAI.OnFavWidgetMoveStop()
    local left, top = BSCAAI_FavWidget:GetLeft(), BSCAAI_FavWidget:GetTop()
    BSCAAI.SV_CHAR.UI_X = left
    BSCAAI.SV_CHAR.UI_Y = top
end
function BSCAAI.OnFavWidgetResizeStop()
    local width, height = BSCAAI_FavWidget:GetDimensions()
    BSCAAI.SV_CHAR.UI_WIDTH = width
    BSCAAI.SV_CHAR.UI_HEIGHT = height	
	BSCAAI:AdjustTrackingLayout()
	BSCAAI.UpdateFavWidget()
	BSCAAI.OnFavWidgetMoveStop()
end
function BSCAAI:RestoreFavWidgetPosition()
    local x = BSCAAI.SV_CHAR.UI_X
    local y = BSCAAI.SV_CHAR.UI_Y
    local width = BSCAAI.SV_CHAR.UI_WIDTH or 400
    local height = BSCAAI.SV_CHAR.UI_HEIGHT or 300

    if not x or not y then
        local screenWidth, screenHeight = GuiRoot:GetDimensions()
        local widgetWidth = BSCAAI_FavWidget:GetWidth()
        local widgetHeight = BSCAAI_FavWidget:GetHeight()

        x = screenWidth - widgetWidth
        y = (screenHeight / 2) - (widgetHeight / 2)

        BSCAAI.SV_CHAR.UI_X = x
        BSCAAI.SV_CHAR.UI_Y = y
    end

    BSCAAI_FavWidget:ClearAnchors()
    BSCAAI_FavWidget:SetAnchor(TOPLEFT, GuiRoot, TOPLEFT, x, y)
	BSCAAI_FavWidget:SetDimensions(width, height)
	BSCAAI_FavWidget:SetResizeToFitDescendents(false)
end


function BSCAAI:AdjustTrackingLayout()
    local win   = BSCAAI_FavWidget
    local list  = win:GetNamedChild("List")
    local child = list:GetNamedChild("ScrollChild")

    local padL, padR = 10, 10        -- gleiche Pads wie in XML
    local avail = math.max(100, win:GetWidth() - (padL + padR))

    -- Titel füllt die Breite und wrappt
    local title = win:GetNamedChild("Title")
    title:ClearAnchors()
    title:SetAnchor(TOPLEFT,  win, TOPLEFT,  padL, 10)
    title:SetAnchor(TOPRIGHT, win, TOPRIGHT, -padR, 10)
    title:SetWrapMode(TEXT_WRAP_MODE_NORMAL)
    title:SetMaxLineCount(2)           -- Titel darf um 2 Zeilen umbrechen

    -- ScrollChild bekommt exakt die aktuelle Breite
    child:SetWidth(avail)

    return avail
end

local function CreateEntry(parent, id, yOffset, maxWidth, sbWidth)
    sbWidth = sbWidth or 16

    local name, _, _, icon = GetAchievementInfo(id)
    local numCriteria = GetAchievementNumCriteria(id)

    local entry = WINDOW_MANAGER:CreateControl(nil, parent, CT_CONTROL)
    entry:SetAnchor(TOPLEFT, parent, TOPLEFT, 0, yOffset)
    entry:SetWidth(maxWidth)
	
    local iconSize = 24
    local gap = 6

    local done, total = 0, 0
    for i = 1, numCriteria do
        local _, d, t = GetAchievementCriterion(id, i)
        done, total = done + d, total + t
    end

    -- Head Container
    local head = WINDOW_MANAGER:CreateControl(nil, entry, CT_CONTROL)
    head:SetAnchor(TOPLEFT, entry, TOPLEFT, 0, 0)
    head:SetAnchor(TOPRIGHT, entry, TOPRIGHT, 0, 0)
    head:SetResizeToFitDescendents(true)

    -- Fortschritt rechts, aber innerhalb des Scrollbereichs
    local progress = WINDOW_MANAGER:CreateControl(nil, head, CT_LABEL)
    progress:SetFont("ZoFontGame")
    progress:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
    progress:SetWrapMode(TEXT_WRAP_MODE_ELLIPSIS)
    local rightPad = 0
    progress:SetAnchor(TOPRIGHT, head, TOPRIGHT, 0, 0)
    progress:SetText(zo_strformat("<<1>> / <<2>>", done, total))
    local progressWidth = progress:GetTextWidth() + 10

    -- Icon links
    local iconCtrl = WINDOW_MANAGER:CreateControl(nil, head, CT_TEXTURE)
    iconCtrl:SetTexture(icon)
    iconCtrl:SetDimensions(iconSize, iconSize)
    iconCtrl:SetAnchor(TOPLEFT, head, TOPLEFT, 0, 0)

    -- Titel neben dem Icon
    local title = WINDOW_MANAGER:CreateControl(nil, head, CT_LABEL)
    title:SetFont("ZoFontWinH4")
    title:SetWrapMode(TEXT_WRAP_MODE_NORMAL)
    title:SetMaxLineCount(0)
    title:SetHorizontalAlignment(TEXT_ALIGN_LEFT)

    local usableWidth = maxWidth - iconSize - progressWidth - (3 * gap)
    if usableWidth < 100 then usableWidth = 100 end
    title:SetWidth(usableWidth)
    title:SetAnchor(TOPLEFT, iconCtrl, TOPRIGHT, gap, 0)
    title:SetText(name)

    local headHeight = math.max(title:GetTextHeight(), iconSize)
    head:SetHeight(headHeight)

    local totalHeight = headHeight
    local prev = head

    -- Kriterien
    for i = 1, numCriteria do
        local critText, numDone, numNeed, isDone = GetAchievementCriterion(id, i)
        local line = WINDOW_MANAGER:CreateControl(nil, entry, CT_LABEL)
        line:SetFont("ZoFontGame")
        line:SetWrapMode(TEXT_WRAP_MODE_NORMAL)
        line:SetMaxLineCount(0)
        line:SetHorizontalAlignment(TEXT_ALIGN_LEFT)
        line:SetWidth(maxWidth - 10)
        line:SetAnchor(TOPLEFT, prev, BOTTOMLEFT, 0, 4)
        line:SetText(zo_strformat("<<1>> (<<2>>/<<3>>)", critText, numDone, numNeed))
        if isDone or numDone >= numNeed then
            line:SetColor(0, 1, 0, 1)
        else
            line:SetColor(1, 1, 1, 1)
        end
        prev = line
        totalHeight = totalHeight + line:GetTextHeight() + 4
    end

    entry:SetHeight(totalHeight)
    return entry, totalHeight
end

function BSCAAI.UpdateFavWidget()
    local window = BSCAAI_FavWidget
    local list = window:GetNamedChild("List")
    local listContainer = list:GetNamedChild("ScrollChild")
    local scrollBar = list:GetNamedChild("ScrollBar")

    -- Breite der Scrollbar (Default 16)
    local sbWidth = (scrollBar and scrollBar:GetWidth()) or 16
    local sidePadding = 10

    -- verfügbare Breite (ohne Scrollbar!)
    local availWidth = list:GetWidth() - sbWidth - sidePadding
    if availWidth <= 0 then
        availWidth = BSCAAI_FavWidget:GetWidth() - sbWidth - 2 * sidePadding
    end

    -- Alte Einträge entfernen
    BSCAAI.favEntries = BSCAAI.favEntries or {}
    for _, c in ipairs(BSCAAI.favEntries) do
        if c then
            c:SetHidden(true)
            c:ClearAnchors()
            c:SetParent(nil)
        end
    end
    BSCAAI.favEntries = {}

    local accountTrack, charTrack = BSCAAI:GetTrackingSplit()
    if #accountTrack == 0 and #charTrack == 0 then
        listContainer:SetHeight(0)
        return
    end

    local yOffset = 0

    local function AddHeader(text)
        local h = WINDOW_MANAGER:CreateControl(nil, listContainer, CT_LABEL)
        h:SetFont("ZoFontWinH3")
        h:SetColor(1, 0.85, 0.2, 1)
        h:SetWrapMode(TEXT_WRAP_MODE_NORMAL)
        h:SetHorizontalAlignment(TEXT_ALIGN_LEFT)
        h:SetAnchor(TOPLEFT, listContainer, TOPLEFT, 0, yOffset)
        h:SetWidth(availWidth)
        h:SetText(text)
        local hHeight = h:GetTextHeight()
        yOffset = yOffset + hHeight + 8
        table.insert(BSCAAI.favEntries, h)
    end

    if #accountTrack > 0 then
        AddHeader("Account Tracking")
        for i = 1, math.min(5, #accountTrack) do
            local entry, height = CreateEntry(listContainer, accountTrack[i], yOffset, availWidth, sbWidth)
            yOffset = yOffset + height + 10
            table.insert(BSCAAI.favEntries, entry)
        end
    end

    if #charTrack > 0 then
        AddHeader("Character Tracking")
        for i = 1, math.min(5, #charTrack) do
            local entry, height = CreateEntry(listContainer, charTrack[i], yOffset, availWidth, sbWidth)
            yOffset = yOffset + height + 10
            table.insert(BSCAAI.favEntries, entry)
        end
    end

    -- Gesamthöhe setzen → Scroll funktioniert
    listContainer:SetHeight(yOffset)
end
