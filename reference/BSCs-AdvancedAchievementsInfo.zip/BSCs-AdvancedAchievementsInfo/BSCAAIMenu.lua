BSCAAchievemntsInfo = BSCAAchievemntsInfo or {}
local BSCAAI = BSCAAchievemntsInfo

local optionsTable = {}

local function AddSendFeedBack()
    table.insert(optionsTable, {
        type = "button",
        name = "Donate",
        tooltip = "Main - EU Server",
        func = function()
              local function PrefillMail()
                ZO_MailSendToField:SetText(BSCAAI.Author)
                ZO_MailSendSubjectField:SetText(BSCAAI.NameSpaced)
                ZO_MailSendBodyField:TakeFocus()
              end
                SCENE_MANAGER:Show('mailSend')
                zo_callLater(PrefillMail, 250)
        end,
        width = "half",
        warning = "",	
    })
end

local function AddSettings()
	table.insert(optionsTable, {
        type = "header",
        name = "Testing",
    })	
	table.insert(optionsTable, {
        type = "checkbox",
        name = "Show Tracking UI",
        getFunc = function() return BSCAAI.SV_CHAR.UI_ENABLE end,
        setFunc = function(value)
            BSCAAI.SV_CHAR.UI_ENABLE = value
			BSCAAI:UpdateSettings()
        end,
    })
end

function BSCAAI:InitMenu()
	if not LibAddonMenu2 then return end

	local panelData = {
		type = "panel",
		name = BSCAAI.Name,
		displayName = BSCAAI.NameSpaced,
		author = BSCAAI.Author,
		version = BSCAAI.VersionDisplay,
		registerForRefresh = true,
	}	
	
	AddSendFeedBack()
	AddSettings()	
		
    local addonpanel = LibAddonMenu2:RegisterAddonPanel(BSCAAI.NameSpaced, panelData)
    LibAddonMenu2:RegisterOptionControls(BSCAAI.NameSpaced, optionsTable)
			
	CALLBACK_MANAGER:RegisterCallback("LAM-PanelOpened", function(currentpanel) if addonpanel == currentpanel then BSCAAI_FavWidget:SetHidden(false) end end )
	CALLBACK_MANAGER:RegisterCallback("LAM-PanelClosed", function(currentpanel) if addonpanel == currentpanel then BSCAAI_FavWidget:SetHidden(true) end end )
end