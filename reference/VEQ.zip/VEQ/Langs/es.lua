-- Translated by: Cisneros

VEQ.mylanguage = {
	-- Menu
	["lang_quests_category_view_settings"] = "Configuración para la vista de categoría de zona",
	["lang_class_show_zone"] = "Mostrar zona en la vista de categoría de clase",
	["lang_class_show_zone_tip"] = "Cuando se usa la vista de categoría de zona, muestra la zona de las misiones de clase",
	["lang_craft_show_zone"] = "Mostrar zona en la vista de categoría de artesanía",
	["lang_craft_show_zone_tip"] = "Cuando se usa la vista de categoría de zona, muestra la zona de las misiones de artesanía",
	["lang_Group_show_zone"] = "Mostrar zona en la vista de categoría de grupo",
	["lang_Group_show_zone_tip"] = "Cuando se usa la vista de categoría de zona, muestra la zona de las misiones de grupo",
	["lang_Dungeon_show_zone"] = "Mostrar zona en la vista de categoría de mazmorra",
	["lang_Dungeon_show_zone_tip"] = "Cuando se usa la vista de categoría de zona, muestra la zona de las misiones de mazmorra",
	["lang_Raid_show_zone"] = "Mostrar zona en la vista de categoría de Prueba",
	["lang_Raid_show_zone_tip"] = "Cuando se usa la vista de categoría de zona, muestra la zona de las misiones de Prueba",
	["lang_HideOptObjective"] = "Ocultar objetivos opcionales",
	["lang_HideOptObjective_tip"] = "Oculta los objetivos opcionales de las misiones",
	["lang_HideOptionalInfo"] = "Ocultar información opcional",
	["lang_HideOptionalInfo_tip"] = "Oculta la información opcional de la misión",
	["lang_HideHintsOption"] = "Ocultar pistas de la misión",
	["lang_HideHintsOption_tip"] = "Oculta las pistas de la misión",
	["lang_HideHiddenOptions"] = "Ocultar pistas ocultas de la misión",
	["lang_HideHiddenOptions_tip"] = "Oculta pistas ocultas de la misión.",
	["lang_HintColor"] = "Color de las pistas de la misión",
	["lang_HintColor_tip"] = "Color de las pistas de la misión",
	["lang_HintCompleteColor"] = "Color de las pistas de la misión",
	["lang_HintCompleteColor_tip"] = "Color de las pistas de la misión.",
	["lang_HideInCombat"] = "Ocultar rastreador en combate",
	["lang_HideInCombat_tip"] = "Oculta rastreador en combate",
	["lang_QuestObjIcon"] = "Mostrar iconos de pasos de misión",
	["lang_QuestObjIcon_tip"] = "Muestra iconos de pasos de misión en lugar de símbolos de texto.",
	["lang_HideObjOption"] = "Ocultar objetivos para todas las misiones EXCEPTO",
	["lang_HideObjOption_tip"] = "Opción para ocultar todos los objetivos excepto las tres opciones. Deshabilitado ignorará esta opción, misión seleccionada ocultará todos los objetivos excepto la misión seleccionada, zona seleccionada ocultará todos los objetivos excepto la zona en la que se encuentra la misión seleccionada.",
	["lang_Miscellaneous"] = "Varios",
	["lang_Toggle_AutoHide_off"] = "Ocultar automáticamente zona/categoría configurada en Apagado",
	["lang_Toggle_AutoHide_on"] = "Ocultar automáticamente zona/categoría configurada en Encendido",
	["lang_Collaspe_All_Zones"] = "Colapsar todas las zonas/categorías",
	["lang_Expand_All_Zones"] = "Expandir todas las zonas/categorías",
	["lang_Toggle_Category_off"] = "Cambiar a vista de zona",
	["lang_Toggle_Category_on"] = "Cambiar a vista de categoría",
	["lang_Toggle_NotFocusTrans_on"] = "Transparencia no seleccionada configurada en Encendido",
	["lang_Toggle_NotFocusTrans_off"] = "Transparencia no seleccionada configurada en Apagado",
	["lang_Toggle_HintsHidden_on"] = "Ocultar pistas y pistas ocultas configuradas en Encendido",
	["lang_Toggle_HintsHidden_off"] = "Ocultar pistas y pistas ocultas configuradas en Apagado",
	["lang_Toggle_HideObjOption_Disabled"] = "Objetivos activados para todas las misiones",
	["lang_Toggle_HideObjOption_FocusedQuest"] = "Objetivos activados solo para la misión seleccionada",
	["lang_Toggle_HideObjOption_FocusedZone"] = "Objetivos activados para las misiones de la zona seleccionada",

	

	
	["lang_Chat_AddonMessages"] = "Habilitar mensajes de chat para el complemento",
	["lang_Chat_AddonMessages_tip"] = "Habilita mensajes de chat, mensajes del complemento sobre cambios por teclas de acceso rápido, errores, etc.",
	["lang_Chat_QuestInfo"] = "Habilitar mensajes de chat para la información de misiones",
	["lang_Chat_QuestInfo_tip"] = "Habilita mensajes de chat para la información de misiones.",
	["lang_chat_settings"] = "Configuración del chat",
	["lang_Chat_AddonMessage_HeaderColor"] = "Color del encabezado de mensajería del complemento",
	["lang_Chat_AddonMessage_HeaderColor_tip"] = "Establece el color del encabezado para la mensajería del complemento.",
	["lang_Chat_AddonMessage_MsgColor"] = "Color de mensaje de mensajería del complemento",
	["lang_Chat_AddonMessage_MsgColor_tip"] = "Establece el color del mensaje para la mensajería del complemento.",
	["lang_Chat_QuestInfo_HeaderColor"] = "Color del encabezado de la información de misiones",
	["lang_Chat_QuestInfo_HeaderColor_tip"] = "Establece el color del encabezado para la mensajería de misiones.",
	["lang_Chat_QuestInfo_MsgColor"] = "Color del mensaje de la información de misiones",
	["lang_Chat_QuestInfo_MsgColor_tip"] = "Establece el color del mensaje para la información de misiones.",
	

	
	["lang_quests_timer_settings"] = "Configuración del temporizador de misiones",
	["lang_quests_timer_settings_Tip"] = "Habilitaa/deshabilita el temporizador de misiones y establecer fuentes y colores..",
	["lang_veq_settings"] = "Vestige's Epic Quest",
	["lang_global_settings"] = "Configuración global",
	
	["lang_language_settings"] = "Idioma",
	["lang_preset_settings"] = "Preajuste",
	["lang_quests_filtered_settings"] = "Mostrar tipos de misiones",
	["lang_overall_transparency"] = "Transparencia general",
	["lang_overall_width"] = "Anchura general",
	["lang_position_lock"] = "Bloquear posición del fondo",
	["lang_backgroundcolor_opt"] = "Habilitar color de fondo",
	["lang_backgroundcolor_value"] = "Color de fondo",
    ["lang_intelligent_background"] = "Fondo inteligente",
	["lang_intelligent_background_tip"] = "El fondo inteligente se desvanece cuando te mueves o estás en combate y se desvanece cuando no lo estás",
	

	["lang_mouse_settings"] = "Configuración de controles del ratón",
	["lang_mouse_1"] = "Botón izquierdo del ratón",
	["lang_mouse_2"] = "Botón central del ratónn",
	["lang_mouse_3"] = "Botón derecho del ratón",
	["lang_mouse_4"] = "Botón 4 del ratón",
	["lang_mouse_5"] = "Botón 5 del ratón",

	["lang_timer_title_font"] = "Fuente del temporizador de la misión",
	["lang_timer_title_font_tip"] = "Fuente para el temporizador de la misión mostrada en las misiones enfocadas que tienen un temporizador.",
	["lang_timer_title_style"] = "Estilo de fuente del temporizador de la misión",
	["lang_timer_title_style_tip"] = "Estilo de fuente utilizado en el temporizador de la misión mostrada en las misiones enfocadas que tienen un temporizador.",
	["lang_timer_title_size"] = "Tamaño de fuente del temporizador de la misión",
	["lang_timer_title_size_tip"] = "Tamaño de fuente para el temporizador de la misión mostrada en las misiones enfocadas que tienen un temporizador.",
	["lang_timer_title_color"] = "Color de fuente del temporizador de la misión",
	["lang_timer_title_color_tip"] = "Color de fuente para el temporizador de la misión mostrada en las misiones enfocadas que tienen un temporizador ",
	
	["lang_area_settings"] = "Configuración de misiones de zonas",
	["lang_area_name"] = "Mostrar nombre de zona/categoría de misiones",
	["lang_area_font"] = "Fuente de zona/categoría",
	["lang_area_style"] = "Estilo de fuente de zona/categoría",
	["lang_area_size"] = "Tamaño de fuente de zona/categoría",
	["lang_area_padding"] = "Tamaño del relleno de zona/categoría",
	["lang_area_color"] = "Color de zona/categoría",
	["lang_autohidequestzone_option"] = "Habilitar ocultación automática de zona",
	["lang_questzone_option"] = "Mostrar solo misiones en la zona actual",
	["lang_quests_guild"] = "Mostrar misiones de gremios",
	["lang_quests_mainstory"] = "Mostrar misiones de la historia principal",
	["lang_quests_cyrodiil"] = "Mostrar misiones de Cyrodiil",

	["lang_quests_class"] = "Mostrar misiones de clase",
	["lang_quests_class_tip"] = "Alterna la visibilidad de las misiones de clase.",
	["lang_quests_crafting"] = "Mostrar misiones de artesanía",
	["lang_quests_crafting_tip"] = "Alterna la visibilidad de las misiones de artesaníae.",
	["lang_quests_group"] = "Mostrar misiones de grupo",
	["lang_quests_group_tip"] = "Alterna la visibilidad de las misiones de grupo.",
	["lang_quests_dungeon"] = "Mostrar misiones de mazmorra",
	["lang_quests_dungeon_tip"] = "Alterna la visibilidad de las misiones de mazmmorra.",
	["lang_quests_raid"] = "Mostrar misiones de Prueba",
	["lang_quests_raid_tip"] = "Alterna la visibilidad de las misiones de prueba.",
	["lang_quests_AVA"] = "Mostrar misiones AVA",
	["lang_quests_AVA_tip"] = "Alterna la visibilidad de las misiones AVA.",
	["lang_quests_event"] = "Mostrar misiones de evento/festividades",
	["lang_quests_event_tip"] = "Alterna la visibilidad de las misiones de evento/festividades.",
	["lang_quests_BG"] = "Mostrar misiones de campos de batalla",
	["lang_quests_BG_tip"] = "Alterna la visibilidad de las misiones de campos de batalla.",
	["lang_area_hybrid"] = "Mostrar vista de zona de categoría",
	["lang_area_hybrid_tip"] = "Muestra zonas en la vista clásica de categoría. Por ejemplo, misiones de gremio listadas en su propia categoría, no en la zona en la que están.",

	["lang_no_trans_focused_zone"] = "Transparencia de zona de misión seleccionada",
	["lang_no_trans_focused_zone_tip"] = "La zona o categoría en la que se encuentra la misión seleccionada no usará la transparencia de no enfocado",
	
	["lang_quests_settings"] = "Configuración de misiones",
	["lang_quests_sort"] = "Ordenar misiones por...",
	["lang_quests_nb"] = "Misiones mostradas para la misma zona", 
	["lang_quests_show_timer"] = "Mostrar temporizador de misión",
	["lang_quests_show_timer_tip"] = "Muestra un temporizador de misión para la misión seleccionada cuando hay un temporizador de finalización. Tenga en cuenta que aparecerá un campo en blanco en el",
	
	

	["lang_quests_hide_obj"] = "Ocultar objetivos/pistas excepto cuando estén seleccionados",
	["lang_quests_hide_obj_tip"] = "Oculta los objetivos y pistas de todas las misiones excepto en la misión seleccionada.",
	
	["lang_quests_hide_obj_optional"] = "Ocultar pistas y objetivos completados",
	["lang_quests_hide_obj_optional_tip"] = "Oculta los objetivos/pistas opcionales de las misiones que se han completado.",
	
	["lang_quests_level"] = "Mostrar nivel de misiones",
	["lang_quests_optinfos"] = "Ocultar todas las pistas y la información opcional",
	["lang_quests_autoshare"] = "Compartir misiones automáticamente",
	["lang_quests_autountrack"] = "Dejar de rastrear misiones ocultas automáticamente",
	["lang_icon_opt"] = "Habilitar icono de misiónn",
	["lang_icon_texture"] = "Textura del icono de misión",
	["lang_icon_size"] = "Tamaño del icono de misión",
	["lang_icon_color"] = "Color del icono de misión",
	["lang_quests_transparency_opt"] = "Habilita la transparencia para misiones que no están seleccionadas.",
	["lang_quests_transparency"] = "Transparencia de misiones no seleccionadas",

	["lang_titles_settings"] = "Configuración de nombres de misiones",
	["lang_titles_font"] = "Fuente del nombre de la misión",
	["lang_titles_style"] = "Estilo de fuente del nombre de la misión",
	["lang_titles_size"] = "Tamaño de fuente del nombre de la misión",
	["lang_titles_padding"] = "Tamaño del relleno del nombre de la misión",
	["lang_titles_default"] = "Color predeterminado del nombre de la misión",
	["lang_titles_custom"] = "Colores personalizados de los títuloss",
	["lang_titles_veasy"] = "Color del nombre de la misión para misiones muy fáciles",
	["lang_titles_easy"] = "Color del nombre de la misión para misiones fáciles",
	["lang_titles_normal"] = "Color del nombre de la misión para misiones normales",
	["lang_titles_hard"] = "Color del nombre de la misión para misiones difíciles",
	["lang_titles_vhard"] = "Color del nombre de la misión para misiones muy difíciles",

	["lang_obj_settings"] = "Configuración de objetivos/pistas",
	["lang_obj_font"] = "Fuente de objetivos",
	["lang_obj_style"] = "Estilo de fuente de objetivos",
	["lang_obj_size"] = "Tamaño de fuente de objetivos",
	["lang_obj_padding"] = "Tamaño del relleno de objetivos",
	["lang_obj_color"] = "Color de fuente de objetivos",
	["lang_obj_ccolor"] = "Color de fuente de objetivos completados",
	["lang_obj_optcolor"] = "Color de fuente de objetivos opcionales",
	["lang_obj_optccolor"] = "Color de fuente de objetivos opcionales completados",

	["lang_infos_settings"] = "Configuración de información",
	["lang_infos_font"] = "Fuente de información",
	["lang_infos_style"] = "Estilo de fuente de información",
	["lang_infos_size"] = "Tamaño de fuente de información",
	["lang_infos_color"] = "Color de fuente de información",
	
	["lang_NumbQuest_opt"] = "Mostrar número de misiones",
	["lang_NumbQuest_opt_tip"] = "Muestra el número de misiones iniciadas y número total de misiones",
	["lang_ShowClock_opt"] = "Mostrar reloj",
	["lang_ShowClock_opt_tip"] = "Muestra un reloj en la parte superior izquierda del rastreador de misiones",
	["lang_ShowTbutton_opt"] = "Mostrar icono de tecla de acceso rápido de la misión seleccionada",
	["lang_ShowTbutton_opt_tip"] = "Muestra un icono con la tecla de acceso rápido para cambiar la misión seleccionada",
	["lang_ShowMQbutton_opt"] = "Mostrar icono de tecla de acceso rápido de la mini misión seleccionada",
	["lang_ShowMQbutton_opt_tip"] = "Muestra un icono con la tecla de acceso rápido para cambiar la mini misión seleccionada",
	
	

	
	-- Menu tips
	["lang_language_settings_tip"] = "Establece tu idioma",
	["lang_preset_settings_tip"] = "Selecciona un preajuste",
	["lang_overall_transparency_tip"] = "Cambia la transparencia global",
	["lang_overall_width_tip"] = "Cambia el ancho de la ventana",
	["lang_position_lock_tip"] = "Bloquea/desbloquea la posición y habilita acciones del ratón",
	["lang_backgroundcolor_opt_tip"] = "Habilita el color de fondo",
	["lang_backgroundcolor_value_tip"] = "Cambia el color de fondo",
	
	["lang_mouse_1_tip"] = "Establece una acción para el clic izquierdo en el nombre de la misión cuando esté en modo cursor",
	["lang_mouse_2_tip"] = "Establece una acción para el clic central en el nombre de la misión cuando esté en modo cursor",
	["lang_mouse_3_tip"] = "Establece una acción para el clic derecho en el nombre de la misión cuando esté en modo cursor",
	["lang_mouse_4_tip"] = "Establece una acción para el botón 4 en el nombre de la misión cuando esté en modo cursore",
	["lang_mouse_5_tip"] = "Establece una acción para el botón 5 en el nombre de la misión cuando esté en modo cursor",
	
	["lang_area_name_tip"] = "Habilita la visualización del nombre de la zona/categoría de la misión.",
	["lang_area_font_tip"] = "Establece la fuente para la zona/categoría de la misión.",
	["lang_area_style_tip"] = "Establece el estilo de fuente para la zona/categoría de la misión.",
	["lang_area_size_tip"] = "Cambia el tamaño de la fuente para la zona/categoría de la misión.",
	["lang_area_padding_tip"] = "Cambia el tamaño del relleno izquierdo y derecho para la zona/categoría de la misión",
	["lang_area_color_tip"] = "Cambia el color de la zona/categoría de la misión",
	["lang_autohidequestzone_option_tip"] = "Sigue la misión seleccionada y oculta otras zonas/categorías de la misión",
	["lang_questzone_option_tip"] = "Muestra misiones en la zona/categoría actual para la misión seleccionada",
	["lang_quests_guild_tip"] = "Muestra misiones de gremioss",
	["lang_quests_mainstory_tip"] = "Muestra misiones de la historia principal",
	["lang_quests_cyrodiil_tip"] = "Muestra misiones de Cyrodiil",

	["lang_quests_sort_tip"] = "Establece el orden de las misiones",
	["lang_quests_nb_tip"] = "Cambia el número de misiones mostradas para la misma zona que la misión seleccionada",
	["lang_quests_show_quest_timer_tip"] = "Muestra un temporizador para misiones con límite de tiempo",
	["lang_quests_level_tip"] = "MUestra el nivel de las misiones",
	["lang_quests_optinfos_tip"] = "Oculta la información/pistas ocultas para todas las misiones, incluida la misión señeccionada.",
	["lang_quests_autoshare_tip"] = "Habilita el compartir misiones automáticamente cuando estás en grupo",
	["lang_quests_autountrack_tip"] = "Deja de rastrear todas las misiones ocultas en la brújula",
	["lang_icon_opt_tip"] = "Habilita el icono de misión",
	["lang_icon_texture_tip"] = "Establece el icono para la misión asistida actual",
	["lang_icon_size_tip"] = "Cambia el tamaño del icono",
	["lang_icon_color_tip"] = "Cambia el color del icono de misión",
	["lang_quests_transparency_opt_tip"] = "Habilita la transparencia para misiones que no están seleccionadas",
	["lang_quests_transparency_tip"] = "Cambia la transparencia de misiones que no están seleccionadas.",

	["lang_titles_font_tip"] = "Establece la fuente para los nombres de las misiones",
	["lang_titles_style_tip"] = "Establece el estilo de fuente para los nombres de las misiones",
	["lang_titles_size_tip"] = "Cambia el tamaño de la fuente para los nombres de las misiones",
	["lang_titles_padding_tip"] = "Cambia el tamaño del relleno izquierdo y derecho para los nombres de las misiones",
	["lang_titles_default_tip"] = "Cambia el color de los nombres de las misiones",
	["lang_titles_custom_tip"] = "Habilita el cambio de color según el nivel del jugador",
	["lang_titles_veasy_tip"] = "Cambia el color de los nombres de las misiones < nivel - 4",
	["lang_titles_easy_tip"] = "Cambia el color de los nombres de las misiones <= nivel - 2",
	["lang_titles_normal_tip"] = "Cambia el color de los nombres de las misiones = nivel +- 1",
	["lang_titles_hard_tip"] = "Cambia el color de los nombres de las misiones >= nivel + 2",
	["lang_titles_vhard_tip"] = "Cambia el color de los nombres de las misiones > nivel + 4",	
	
	["lang_obj_font_tip"] = "Establece la fuente para el texto de la misión",
	["lang_obj_style_tip"] = "Establece el estilo de fuente para el texto de la misión",
	["lang_obj_size_tip"] = "Cambia el tamaño de la fuente para el texto de la misión",
	["lang_obj_padding_tip"] = "Cambia el tamaño del relleno izquierdo y derecho para el texto de la misión",
	["lang_obj_color_tip"] = "Cambia el color del texto de la misión",
	["lang_obj_ccolor_tip"] = "Cambia el color del texto de los objetivos completados",
	["lang_obj_optcolor_tip"] = "Cambia el color del texto de los objetivos opcionales",
	["lang_obj_optccolor_tip"] = "Cambia el color del texto de los objetivos opcionales completados",

	["lang_infos_opt_tip"] = "Muestra el total de misiones actuales",
	["lang_infos_font_tip"] = "Establece la fuente para la información",
	["lang_infos_style_tip"] = "Establece el estilo de fuente para la información",
	["lang_infos_size_tip"] = "Cambia el tamaño de la fuente para la información",
	["lang_infos_color_tip"] = "Cambia el color de la fuente para la informacións",
	
	-- Menu Warn
	["lang_menu_warn_1"] = "|c8B1E1E Cambiar esta opción recargará la UI",
	["lang_menu_warn_2"] = "|c8B1E1E Cambiar esta opción recargará la interfaz de usuario y sobrescribirá tus configuraciones actuales",


	-- Mouse Interactions
	["lang_mouse_ctrl_assisted"] = "Cambiar misión asistida",
	["lang_mouse_ctrl_filterzone"] = "Filtrar por zona actual",
	["lang_mouse_ctrl_share"] = "Compartir misión",
	["lang_mouse_ctrl_showmap"] = "Mostrar en el mapa",
	["lang_mouse_ctrl_remove"] = "Eliminar misión",
	
	-- Console
	["lang_console_autoshare"] = "[VEQ] Compartes automáticamente una misión",
	["lang_console_share"] = "[VEQ] Compartes una misión",
	["lang_console_noshare"] = "[VEQ] Esta misión no se puede compartir",
	["lang_console_abandon"] = "[VEQ] Abandonar misión",
	["lang_choose"] = "Elige: ",









----------------------------------- NEW STUFF

	["lang_tmp_VEQMessage"] = "<<1>>: <<2>>",
	["lang_tmp_VEQMessage_Error"] = "ERROR <<1>>: <<2>>",


	-- Quests Infos
	["quest_optional"] = "Opcional",
	["quest_hint"] = "Pista",	
	["quest_hiddenhint"] = "Pista oculta",
	
	["lang_tracker_type_guild"] = "Gremio",
	["lang_tracker_type_mainstory"] = "Misión principal de historia",
	["lang_tracker_type_undaunted"] = "Intrépidos",
	["lang_tracker_type_prologue"] = "Prólogo",	
	["lang_tracker_type_companion"] = "Compañero",
	["lang_tracker_type_repeatable"] = "RPT",
	["lang_tracker_type_daily"] = "Diaria",
	["lang_tracker_type_dungeon"] = "Mazmorra",
	["lang_tracker_type_solo"] = "Solo",
	["lang_tracker_type_class"] = "Clase",
	["lang_tracker_type_craft"] = "Artesanía",
	["lang_tracker_type_group"] = "Grupo",
	["lang_tracker_type_ava"] = "Guerra de Alianzas",
	["lang_tracker_type_arena"] = "Arena",
	["lang_tracker_type_holiday_event"] = "Evento de vacaciones",
	["lang_tracker_type_raid"] = "Prueba",
	["lang_tracker_type_bg"] = "Campo de batalla",
	["lang_tracker_type_qa_test"] = "Test",
	["lang_tracker_type_dark_brotherhood"] = "Hermandad Oscura",
	["lang_tracker_type_thieves_guild"] = "Gremio de Ladrones",
	["lang_tracker_type_mages_guild"] = "Gremio de Magos",
	["lang_tracker_type_fighters_guild"] = "Gremio de Luchadores",
	["lang_tracker_type_psijic_order"] = "Orden Psijic",
	
	
	
	-- Inventory
	["lang_slots_inventory"] = "Espacios disponibles en el inventario",
	["lang_slot_inventory"] = "Espacio disponible en el inventario",
	["lang_free_space"] = "Liberar algo de espacio",
	["lang_inventory_full"] = "¡El inventario está lleno!",
	
	-- Treasure
	["lang_survey_map"] = "Mapa de prospección",
	["lang_treasure_map"] = "Mapa del tesiri",
	["lang_get_materials"] = "Obtener los materiales",
	["lang_get_treasure"] = "Obtener el tesoro",
	
	-- Skyshards
	["lang_skyshard"] = "Fragmento de cielo",
	["lang_maway"] = "m de distancia",
	["lang_distant_sky"] = "Presencia Etérea de Magia Imperceptible",
	["lang_weak_sky"] = "Presencia Etérea de Magia Débil",
	["lang_moderate_sky"] = "Presencia Etérea de Magia Moderada",
	["lang_strong_sky"] = "Presencia Etérea de Magia Fuerte",
	["lang_huge_sky"] = "Presencia Etérea de Magia Enorme",
	
	-- Leads / antiquities
	["lang_scry_exc"] = "Videncia y excavación en ",
	["lang_antiquity_"] = "Antigüedad - ",
	
	-- Doable writs
	["lang_check_inv"] = "Haz clic aquí para comenzar a fabricar",
	["lang_doable"] = "Realizable ",
	["lang_or"] = " o ",
	
	-- Riding skills
	["lang_stable_rel"] = "Una relación estable",
	["lang_upgrade_skills"] = "Mejora una de tus habilidades de equitación",	
	["lang_stablemaster"] = "Maestro de establos",
	
	-- Backpack & Bank upgrade
	["lang_backpack_upgrade"] = "Mejora del inventario",
	["lang_you_have_the"] = "Tienes ",
	["lang_up_back"] = "de oro! Mejora tu inventario",
	["lang_pack_merchant"] = "Mercader de bolsas",
	["lang_bank_space_upgrade"] = "Mejora del espacio del banco",
	["lang_up_bank"] = "de oro! Mejora el espacio del banco",
	["lang_bank_mon"] = "Banquero o prestamista",
	
	-- Endeavor	
	["lang_endeavor_week"] = "Empresa semanal",
	["lang_endeavor_day"] = "Empresa diaria",
	
	
	
	-- Event Tickets & transmute crystals
	["lang_event_tickets"] = "Billetes de eventos",
    ["lang_transmute_crystals"] = "Cristales de transmutación",
    ["lang_maxed_out_currency"] = "¡Esta moneda está al máximo! Gástala.",
    ["lang_nears_max_currency"] = "Esta moneda está cerca del máximo permitido, gástala.",
	
	
	-- LFG & ready check
	["lang_in"] = " en ",
	["lang_champion_battleground"] = "Campo de batalla de campeón",
	["lang_low_battleground"] = "Campo de batalla de bajo nivel",
	["lang_non_battleground"] = "Campo de batalla no campeón",
	["lang_normal_dungeon_finder"] = GetString(SI_DUNGEONDIFFICULTY1).." Buscador de mazmorras",
	["lang_veteran_dungeon_finder"] = GetString(SI_DUNGEONDIFFICULTY2).." Buscador de mazmorras",
	["lang_tribute_casual"] = "Historias de homenaje casual",
	["lang_tribute_competitive"] = "Historias de homenaje competitivo",
	["lang_lfg"] = "Buscando grupo...",
	["lang_lfo"] = "Buscando un oponente...",
	["lang_everybody_ready"] = "¿Todo el mundo listo?",
	["lang_ready"] = " listo",
	["lang_grc"] = "Comprobar si el grupo está listo",
	["lang_for"] = " para ",
	["lang_LFR"] = "Búsqueda de reemplazo",
	
	-- Entering campaign
	["lang_cyrodiil"] = "Cyrodiil - ",
	["lang_group"] = "Grupo - ",
	["lang_ewt"] = "\n• Tiempo de espera restante: ",
	["lang_entering_campaign"] = "Entrando en la campaña...",
	["lang_n_started"] = "\n• Iniciada ",
	["lang_ago"] = " ago",
	["lang_confirming"] = "Confirmando",
	["lang_finished"] = "Finalizada", 
	["lang_pending_accept"] = "Entrando...",
	["lang_pending_join"] = "Pendiente de unión",
	["lang_leaving_queue"] = "Abandonando cola",
	["lang_exiting_campaign"] = "Saliendo de la campaña...",
	["lang_waiting"] = "Esperando",
	["lang_n_queue_position"] = "\n• Posición en la colan: ",
	
    -- Poison checker  / notifier	
	["lang_out_of_poison"] = "¡Sin veneno!",	
	["lang_craft_some_poison"] = "Crea o compra veneno y aplícalo a tu arma",
	["lang_alchemy_station"] = "Estación de alquimia",
	
    -- Psijic Time Breaches helper
    ["lang_psijic_time_breach"] = "Brecha temporal Psijic #",	
	["lang_6172_helper_9"] = "A mitad de camino entre el Cuenca del Augurio y el Nido de Keelsplitter (Ve al oeste desde el santuario de Ebon Stadmont, salta al estanque y sigue el arroyo, la brecha está al pie de la cascada)",	
	["lang_6172_helper_8"] = "Entre el Nido de Keelsplitter y el Géiser Abisal de Rellenthil, en la pequeña isla con el árbol (al sur del santuario de Ebon Stadmont)",
	["lang_6172_helper_7"] = "En una estructura en ruinas al oeste de Alinor, a mitad de camino entre la Ensenada de Welenkin y el Géiser Abisal de Welenkin (Baja por el camino empedrado al sur del santuario de Cey-Tarn Keep, mantente a la derecha en cada bifurcación, incluido el puente roto que lleva a la estructura)",
	["lang_6172_helper_6"] = "Dentro de la Acrópolis de Direnni, después del puente (Baja por el camino empedrado al sureste del santuario de King's Haven Pass, mantente a la izquierda en la bifurcación)",
	["lang_6172_helper_5"] = "Debajo de la cascada al oeste de Shimmerene (Galopea al norte del santuario de Shimmerene y salta al agua lo más lejos posible)",
	["lang_6172_helper_4"] = "En las ruinas en la colina, al norte del lago junto a la Arboleda del Arconte, al este del Bastión de las Once Fuerzas (Ve al sur del santuario de Shimmerene)",
	["lang_6172_helper_3"] = "En uno de los recintos en Sil-Var-Woad (Ve al sur del santuario de Sil-Var-Woad, entra al zoológico, mantente a la derecha en la bifurcación, en el recinto acuático)",
	["lang_6172_helper_2"] = "En la orilla este de la isla al sureste de Sil-Var-Woad, al sureste del Géiser Abisal de Sil-Var-Woad, cerca de las dos islas pequeñas más al norte",
	["lang_6172_helper_1"] = "Al sur del santuario de Sunhold, al oeste del Géiser Abisal de Sunhold",
	
	
	["lang_6181_helper_9"] = "En un acantilado con vista al Molino de Deleyn, al norte del Dolmen de Daenia (Dirígete al sur desde el santuario de Baelborne Rock, corre por el río, debajo del puente, luego dirígete al sureste, la brecha está un poco más allá del caballete de pintura)",
	["lang_6181_helper_8"] = "Entre las raíces en el lado norte del Árbol Beldama Wyrd (santuario del Árbol Wyrd)",
	["lang_6181_helper_7"] = "En un acantilado en el lado oeste de los Túmulos Funerarios (Dirígete al suroeste desde el santuario de Crosswych hasta la gran mala hierba y luego dirígete al sur-sureste en la cima del acantilado)",
	["lang_6181_helper_6"] = "Dentro de la parte más al sur de un naufragio en el lado oeste de la isla del Faro de Koeglin (Dirígete al oeste-suroeste desde el santuario de las Ruinas de Bonesnap)",
	["lang_6181_helper_5"] = "En el borde del nivel más alto de las Cataratas Cumberland (Dirígete al oeste desde el santuario de Wind Keep, sigue el río corriente arriba hasta la cascada y sube a su cima)",
	["lang_6181_helper_4"] = "Justo al oeste de Moonlit Maw (Dirígete al norte desde el santuario de la Abadía Pariah)",
	["lang_6181_helper_3"] = "En el borde de un acantilado al norte de Salas En, al noreste de El Guerrero, con vista a los Campos de Rain Catcher (Dirígete al oeste desde el santuario de la Abundancia de Morwha, sube, dirígete al oeste nuevamente hasta el borde del acantilado)",
	["lang_6181_helper_2"] = "Contra una pared de acantilado al oeste de la Aerie de Easterly (Dirígete al oeste desde el santuario de las Minas de Kulati, rodea la roca a la derecha, toma el puente, ve a la izquierda para subir a la plataforma más alta)",
	["lang_6181_helper_1"] = "Entre la Vigía de HoonDing y Ragnthar (Dirígete al sur desde el santuario de la Vigía de HoonDing, sube la arena a tu izquierda cuando puedas, dirígete al sur nuevamente)",
	
	
	["lang_6185_helper_9"] = "Entre los dos arroyos de lava más al sur en el lado oeste de Senie (Ve al oeste desde el santuario de Senie)",
    ["lang_6185_helper_8"] = "En una pequeña isla en la cima de la cascada entre Brothers of Strife y Armature's Upheaval (Ve al suroeste desde el santuario de Brothers of Strife)",
    ["lang_6185_helper_7"] = "En la cima de la cresta sobre Vivec's Antlers entre el santuario de Sulfur Pools y Vivec's Antlers (Ve al este desde el santuario de Sulfur Pools)",
    ["lang_6185_helper_6"] = "Junto a una de las piscinas de vapor más grandes en Wittestadr (Ve al noreste desde el santuario de Wittestadr, la brecha está exactamente en el icono de Wittestadr en el mapa)",
    ["lang_6185_helper_5"] = "Entre las dos cascadas río arriba, al suroeste de Darkwater Crossing, al sureste del mapa de Fort Amol (Ve al sureste desde el santuario de Fort Amol)",
    ["lang_6185_helper_4"] = "En el río al oeste del puente, al este de Cradlecrush, al noroeste del Pozo de Bebida de Thane Jeggi (Ve al suroeste desde el santuario de Fort Morvunskar y sigue el camino empedrado, mantente a la izquierda en la bifurcación, mira a tu derecha en el puente)",
    ["lang_6185_helper_3"] = "Noreste de Fort Greenwall, al suroeste de la Cueva del Troll (Pasa por Fort Greenwall al norte desde el santuario de Riften y luego al noreste)",
    ["lang_6185_helper_2"] = "Justo fuera de la cueva de Snapleg (Cruza el puente al norte del santuario de Nimalten y continúa a lo largo del río hasta la cueva)",
    ["lang_6185_helper_1"] = "En la cima de los escalones cerca de la Garganta del Mundo, al noroeste de Ivarstead (Ve al oeste-suroeste desde el santuario de Geirmund's Hall, cruza el puente y sigue los numerosos escalones)",	
	

    ["lang_6197_helper_adamantine"] = "Ve al suroeste desde el santuario de Eastern Evermore, usa la Brecha Temporal en el Cementerio de Pelin, sigue la visión Psijic, desentierra la pieza del bastón",
	["lang_6197_helper_orichalc"] = "Ve al suroeste del santuario de Leki's Blade, usa la Brecha Temporal al norte de Leki's Blade, sigue la visión Psijic, desentierra la pieza del bastón",
	["lang_6197_helper_crystal"] = "Ve al norte del santuario de Hatching Pools, usa la Brecha Temporal en Hatching Pools (bajo el Gran Árbol Hist), sigue la visión Psijic, desentierra la pieza del bastón",
	["lang_6197_helper_walk"] = "Ve al sur desde el santuario de Selfora, usa la Brecha Temporal cerca de Fang Spires, sigue la visión Psijic, desentierra la pieza del bastón",
	
	["lang_6197_helper_pelin"] = "Fragmento de bastón cerca del Cementerio de Pelin",
	["lang_6197_helper_leki"] = "Fragmento de bastón cerca de Leki's Blade",	
	["lang_6197_helper_hist"] = "Fragmento de bastón cerca del Hist",
	["lang_6197_helper_fang"] = "Fragmento de bastón cerca de Fang Spires",	
	
	
	["lang_6194_helper_9"] = "En una estructura en ruinas en el lado oeste del Osario de Telacar (Ve al norte-noroeste desde el santuario de Ossuary)",
	["lang_6194_helper_8"] = "Dentro del tocón de Gil-Var-Delle, al oeste del Dolmen (Ve al sur desde el santuario de Gil-Var-Delle)",
	["lang_6194_helper_7"] = "Dentro de la torre más alta en ruinas, al norte de Reman's Bluff (Ve al oeste-suroeste desde el santuario de Redfur Trading Post)",
	["lang_6194_helper_6"] = "En un promontorio al norte del Campamento Maormer (Cruza el puente al norte-noroeste del santuario de Moonhenge, sigue el camino empedrado, sigue recto hacia el borde del acantilado cuando el camino gira a la derecha)",
	["lang_6194_helper_5"] = "Al norte del Descanso del Pescador (Rodea la montaña por el oeste desde el santuario de la Gruta de la Serpiente))",
	["lang_6194_helper_4"] = "Dentro del Laberinto, justo al norte del centro (Cruza el puente al norte desde el santuario de Greenheart, continúa recto sin seguir el camino, síguelo cuando vuelva a estar bajo tus pies, toma la 1ª entrada del Laberinto a tu izquierda, ve a la derecha en la 1ª bifurcación y a la izquierda en la 2ª)",
	["lang_6194_helper_3"] = "Debajo de un puente al sur de Treehenge, al oeste de Ragnthar (Sigue el camino al norte del santuario de Wilding Run hasta llegar al puente, salta)",
	["lang_6194_helper_2"] = "En el centro de Horseshoe Island (Ve al norte desde el santuario de Vulkwasten)",
	["lang_6194_helper_1"] = "On the island Northeast of Xylo River Basin Dolmen (Go North from Abamath wayshrine)",

	["lang_6190_helper_9"] = "On the cliff south of Bthanual (Follow the road East from Muth Gnaar Hills wayshrine, cross the bridge, keep left at the fork, go South before Bthanual entrance)",
	["lang_6190_helper_8"] = "By the waterfall Northeast of Darkshade Caverns (Go Southwest from Silent Mire wayshrine, climb the rock to the higher platform)",
	["lang_6190_helper_7"] = "In a planter in the middle of the Shrine of Saint Veloth (Follow the road Northwest from Eidolon's Hollow wayshrine, keep left at the 1st fork and right at the 2nd one)",
	["lang_6190_helper_6"] = "On a tiny island by the waterfalls Northeast of The Triple Circle Mine (Go South from Shad Astula wayshrine, swim, jump down the waterfall, swim)",
	["lang_6190_helper_5"] = "Behind the huge gates of Malak's Maw (Go West from West Narsis wayshrine and do a full lap clockwise)",
	["lang_6190_helper_4"] = "Under a tree's roots in the Southwest corner in Bogmother (Go West from Bogmother wayshrine)",
	["lang_6190_helper_3"] = "Inside a stone mouth in western Hei-Halai, near the entrance to the Ruins of Mazzatun (Follow the road North from Stillrise wayshrine, when you see a tower ruin on your left next to the road  go Northwest, Then follow the path on your left to the stone mouth)",
	["lang_6190_helper_2"] = "In a small xanmeer Northwest of the Venomous Fens Dolmen (Go Southeast from Loriasel wayshrine)",
	["lang_6190_helper_1"] = "En la isla al noreste del Dolmen del Valle del Río Xylo (Ve al norte desde el santuario de Abamath)",


	
	["lang_6198_helper_red"] = "Ve al sur del santuario de Brothers of Strife, usa la Brecha Temporal, sigue la visión Psijic, desentierra la pieza del bastón",
	["lang_6198_helper_white"] = "Ve al noroeste desde el santuario de Weeping Giant hasta la ruina de la torre, luego sigue el camino a tu derecha, cruza el puente de tablones, usa la Brecha Temporal, sigue la visión Psijic, desentierra la pieza del bastón",
    ["lang_6198_helper_greensap"] = "Ve al norte del santuario de Greenheart, usa la Brecha Temporal, sigue la visión Psijic, desentierra la pieza del bastón",
    ["lang_6198_helper_snow"] = "Ve al este desde el santuario de Spellscar, entre el acantilado rocoso y Anomalía Adament, al final del acantilado rocoso, gira a la izquierda, usa la Brecha Temporal, sigue la visión Psijic, desentierra la pieza del bastón",

	["lang_6198_helper_bro"] = "Fragmento de bastón cerca de Brothers of Strife",
	["lang_6198_helper_weep"] = "Fragmento de bastón cerca de Weeping Giant",	
	["lang_6198_helper_green"] = "Fragmento de bastón cerca de Greenheart",
	["lang_6198_helper_spell"] = "Fragmento de bastón cerca de Spellscar",	
	
	
	["lang_6468_helper_9"] = "En la pared al oeste de Descanso del Comerciante (Ve al noreste desde el santuario de Oldgate)",
    ["lang_6468_helper_8"] = "En Sanguine Barrows, entre la tumba central y la Cripta de Tribulación (Ve al norte desde el santuario de Sanguine Barrows)",
    ["lang_6468_helper_7"] = "Frente a la torre norte en Lorkrata Hills (Ve al oeste desde el santuario de Fell's Run, una vez dentro de los muros de Lorkrata Hills, toma las escaleras a tu derecha)",
    ["lang_6468_helper_6"] = "En un campo en Edrald Estate (Ve al este-sureste desde el santuario de Fell's Run)",
    ["lang_6468_helper_5"] = "En una isla al oeste de East-Rock Landing, al norte de las Ruinas del Dedo del Orco, al suroeste de la Serpiente (Ve al este desde el santuario de Boralis)",
	["lang_6468_helper_4"] = "En la cabina del capitán de Lagra's Pearl (Ve al noreste desde el santuario de Northpoint)",
	["lang_6468_helper_3"] = "Frente a las criptas de la capilla en Crestshade (Sigue el camino empedrado al sur desde el santuario de Crestshade, en la estatua, ve al suroeste y sube las escaleras, el otro conjunto de escaleras a la izquierda, continúa recto hacia las escaleras de las criptas de la capilla)",
	["lang_6468_helper_2"] = "Justo al oeste de Aesar's Web (Ve al oeste del santuario de Tamrith Camp)",
	["lang_6468_helper_1"] = "Dentro de la caverna de Shadowfate (La entrada está entre Aesar's Web y el santuario de Tamrith Camp)",
	

	["lang_6196_helper_6"] = "Noreste de la Bodega de Ogondar, al oeste de Rkundzelft (Ve al este desde el santuario de Spellscar, entre el acantilado rocoso y la Anomalía Adament, al final del acantilado rocoso, ve al sureste)",
	["lang_6196_helper_5"] = "Fuera de la esquina noroeste de Elinhir (Ve al sur desde el santuario de Elinhir, rodea el acantilado rocoso de Elinhir por la derecha hasta que encuentres la brecha)",
	["lang_6196_helper_4"] = "En una grieta en el extremo sur del Barranco del Escorpión (Ve al suroeste desde el santuario del Archivo del Buscador)",
	["lang_6196_helper_3"] = "Al norte de la Ciudadela de Hel Ra, al este de Mtharnaz (Ve al oeste desde el santuario de Sandy Path)",
	["lang_6196_helper_2"] = "Frente a la Arena Dragonstar (Santuario Dragonstar)",
	["lang_6196_helper_1"] = "En el puente hacia Skyreach Hold (Santuario Skyreach)",
	
	["lang_6199_helper"] = "Desde el santuario del Oasis de Cabeza de Cabra, sube las escaleras y luego ve al suroeste hacia la mina Divad's Chagrin",
	
	
	-- Group frames
	["lang_of"] = " de ",
	
	-- Museum Pieces
	["lang_museum"] = "Volver",

	-- Dailies counter
	["lang_repeatable_quests"] = "Misiones repetibles",
	["lang_ongoing"] = "En curso: ",
	["lang_completed_today"] = "Completado hoy: ",
	
	-- zone todo list
	["lang_todolist"] = "Lista de tareas de la zona",
	
	-- remains silent
	["lang_remains_silent"] = "<Permanecer en silencio>",
	
	-- Dragonguard Supply chest name (change to your language for the feature to work)
	["lang_dragonguard_supply_chest"] = "Cofre de suministros de la Guardia del Dragón",
	 
	-- mini tracker settings
	["lang_mini_quest_tracker_settings"] = "Configuración del rastreador de mini misiones",
	["lang_mini_quest_tracker_invert_opt"] = "Invertir tecla",
	["lang_mini_quest_tracker_invert_tip"] = "Obtén la mini misión anterior en lugar de la siguiente manteniendo presionada esa tecla mientras presionas la tecla de acceso rápido predeterminada",
	["lang_inventory_slots_opt"] = "Mini misión de espacios vacíos en el inventario",
	["lang_inventory_slots_tip"] = "Una mini misión para vaciar tu inventario cuando alcance el límite mínimo de espacios vacíos que has configurado",
	["lang_inventory_slots_limit"] = "Disparador de espacios libres en el inventario",
	["lang_inventory_slots_limit_tip"] = "Número mínimo de espacios libres en el inventario que desencadena la mini misión",	
	["lang_lost_treasure_opt"] = "Mini misión de mapas del tesoro y prospección",
	["lang_lost_treasure_tip"] = "Añade una mini misión para mapas del tesoro y ubicaciones de prospección tan pronto como aparezcan en tu bolsa (perfecto con el complemento Lost Treasure)",	
	["lang_skyshards_opt"] = "Mini misión de fragmentos de cielo",
	["lang_skyshards_tip"] = "Añade una mini misión para conseguir un fragmento de cielo si está a menos de 100 metros de distancia",	
    ["lang_leads_opt"] = "Mini misión de Pistas",
	["lang_leads_tip"] = "Añade una mini misión para videncia y excavar una antigüedad por cada una de las pistas que tengas",
    ["lang_fake_leads_opt"] = "Progresión de videncia y excavación",
	["lang_fake_leads_tip"] = "Añade diariamente una mini misión para videncia y excavar una antigüedad para una progresión suave de estas líneas de habilidades.",
	["lang_writs_opt"] = "Mini misión de encargos realizables",
	["lang_writs_tip"] = "Añade una mini misión para cada encargo realizable (teniendo conocimiento y materiales) en tu inventario. (Necesita tener instalado el complemento WritWorthy para funcionar)",
	["lang_stable_opt"] = "Mini misión de mejora de habilidades de equitación",
	["lang_stable_tip"] = "Añade una mini misión para mejorar tus habilidades de equitación tan pronto como cumplas con las condiciones",	
	["lang_backbank_opt"] = "Mini misión de mejora de mochila y banco",
	["lang_backbank_tip"] = "Añade una mini misión para mejorar tu mochila o espacio en el banco tan pronto como tengas el oro necesario",		
	["lang_endeavor_opt"] = "Mini misión diaria y semanal de empresas",
	["lang_endeavor_tip"] = "Añade empresas diarias y semanales como una mini misión..",
	["lang_goldenPursuit_opt"] = "Mini misión de Persecución Dorada",
	["lang_goldenPursuit_tip"] = "Añade cada Persecución Dorada como una mini misión.",
	["lang_communityEvents_opt"] = "Community Event Mini Quest",
	["lang_communityEvents_tip"] = "Adds each Community Event as a mini quest.",
	["lang_tickets_opt"] = "Mini misión para gastar billetes de evento",
	["lang_tickets_tip"] = "Una mini misión para gastar tus billetes de evento cuando alcancen el mínimo para llegar al límite que configuraste",	
	["lang_tickets_limit"] = "Cantidad mínima de billetes de evento restantes para alcanzar el tope y activar el desencadenante",
	["lang_tickets_limit_tip"] = "Número mínimo de billetes de evento restantes para alcanzar el tope, lo que desencadena la mini misión",
	["lang_transmute_opt"] = "Mini misión para gastar Cristales de Transmutación",
	["lang_transmute_tip"] = "Una mini misión para gastar tus Cristales de Transmutación cuando alcance el mínimo para llegar al límite que configuraste",	
	["lang_transmute_limit"] = "Cantidad mínima de Cristales de Transmutación restantes para alcanzar el tope y activar el desencadenante",
	["lang_transmute_limit_tip"] = "Número mínimo de Cristales de Transmutación restantes para llegar al tope, lo que desencadena la mini misión",
    ["lang_zoneguide_opt"] = "Establecer la próxima misión de la guía de zona como una mini misión",
	["lang_zoneguide_tip"] = "La mini guía de misiones de zona se activa automáticamente y se convierte en una mini misión en VEQ al cambiar de zona y si no tienes una misión activa en esa zona",	
	["lang_POIcompletion_opt"] = "Set undiscovered zone Points of interest as a Mini Quest",
	["lang_POIcompletion_tip"] = "One Undiscovered zone Point of interest becomes a mini quest in VEQ on zone change",
    ["lang_poison_opt"] = "Verificador de veneno",
	["lang_poison_tip"] = "Revisa las ranuras de veneno de tu arma después de cada combate; si te quedas sin veneno, se muestra una mini misión para fabricar veneno",	
	["lang_group_frames_opt"] = "Nombres de compañeros y miembros del grupo como barras de vida",
	["lang_group_frames_tip"] = "Muestra los nombres de los miembros del grupo como barras de vida coloreadas",
	["lang_default_group_frames_opt"] = "Ocultar los marcos de grupo predeterminados del juego",
	["lang_default_group_frames_tip"] = "Activa esta opción en caso de conflicto con otro complemento respecto a la visualización predeterminada de los marcos de grupo",	
	["lang_museum_pieces_opt"] = "Mini misión de piezas de museo",
	["lang_museum_pieces_tip"] = "Añade una mini misión para devolver al museo cada pieza de museo que tengas en tu inventario",
	["lang_dailies_counter_opt"] = "Contador de misiones diarias",
	["lang_dailies_counter_tip"] = "Añade un contador para llevar la cuenta de las 50 misiones diarias por día y el límite de personajes",
	["lang_NumbMiniQuest_opt"] = "Mostrar el número de mini misiones",
	["lang_NumbMiniQuest_opt_tip"] = "Mostrar el número de mini misiones",
	
}