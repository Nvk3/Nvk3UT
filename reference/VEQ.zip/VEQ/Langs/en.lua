VEQ.mylanguage = {
	-- Menu
	["lang_quests_category_view_settings"] = "Settings for Category Zone View",
	["lang_class_show_zone"] = "Show zone in Class Category Zone View",
	["lang_class_show_zone_tip"] = "When using Category Zone View show the zone of the Class quests",
	["lang_craft_show_zone"] = "Show zone in Craft Category Zone View",
	["lang_craft_show_zone_tip"] = "When using Category Zone View show the zone of the Crafting quests",
	["lang_Group_show_zone"] = "Show zone in Group Category Zone View",
	["lang_Group_show_zone_tip"] = "When using Category Zone View show the zone of the Group quests",
	["lang_Dungeon_show_zone"] = "Show zone in Dungeon Category Zone View",
	["lang_Dungeon_show_zone_tip"] = "When using Category Zone View show the zone of the Dungeon quests",
	["lang_Raid_show_zone"] = "Show zone in Raid Category Zone View",
	["lang_Raid_show_zone_tip"] = "When using Category Zone View show the zone of the Raid quests",
	["lang_HideOptObjective"] = "Hide Optional Objectives",
	["lang_HideOptObjective_tip"] = "Hide quests optional objectives",
	["lang_HideOptionalInfo"] = "Hide Optional Information",
	["lang_HideOptionalInfo_tip"] = "Hide Quest Optional Information",
	["lang_HideHintsOption"] = "Hide Quest Hints",
	["lang_HideHintsOption_tip"] = "Hide hints for the quest",
	["lang_HideHiddenOptions"] = "Hide Hidden Quest Hints",
	["lang_HideHiddenOptions_tip"] = "Hide hidden quest hints.",
	["lang_HintColor"] = "Quest Hint Color",
	["lang_HintColor_tip"] = "Color for hints for quest",
	["lang_HintCompleteColor"] = "Quest Hints Completed Color",
	["lang_HintCompleteColor_tip"] = "Quest hints completed color.",
	["lang_HideInCombat"] = "Hide tracker when in combat",
	["lang_HideInCombat_tip"] = "Hide tracker when in combat",
	["lang_QuestObjIcon"] = "Show Quest Step Icons",
	["lang_QuestObjIcon_tip"] = "Show Quest Step Icons instead of text symbols.",
	["lang_HideObjOption"] = "Hide Objectives for all quests EXCEPT",
	["lang_HideObjOption_tip"] = "Option to hide all objectives except for the three options.  Disabled will ignore this option, Focused Quest would hide all objectives except focused quest, Focused Zone will hide all objectives except for the zone the focused quest is in.",
	["lang_Miscellaneous"] = "Miscellaneous",
	["lang_Toggle_AutoHide_off"] = "Auto Hide Zone/Category set to Off",
	["lang_Toggle_AutoHide_on"] = "Auto Hide Zone/Category set to On",
	["lang_Collaspe_All_Zones"] = "Collaspe All Zones/Categories",
	["lang_Expand_All_Zones"] = "Expand All Zones/Categories",
	["lang_Toggle_Category_off"] = "Change to Zone View",
	["lang_Toggle_Category_on"] = "Change to Category View",
	["lang_Toggle_NotFocusTrans_on"] = "Not Focused Transparency set to On",
	["lang_Toggle_NotFocusTrans_off"] = "Not Focused Transparency set to Off",
	["lang_Toggle_HintsHidden_on"] = "Hide Hints and Hidden Hints to On",
	["lang_Toggle_HintsHidden_off"] = "Hide Hints and Hidden Hints to  Off",
	["lang_Toggle_HideObjOption_Disabled"] = "Objectives on for All Quests",
	["lang_Toggle_HideObjOption_FocusedQuest"] = "Objectives on for Focused Quest Only",
	["lang_Toggle_HideObjOption_FocusedZone"] = "Objectives on for Focused Zone Quests",

	

	
	["lang_Chat_AddonMessages"] = "Enable Chat Messages for Addon",
	["lang_Chat_AddonMessages_tip"] = "Enable chat messages, messages from addon as to changes by keybinds, errors, etc.",
	["lang_Chat_QuestInfo"] = "Enable Chat Messages for Quest Info",
	["lang_Chat_QuestInfo_tip"] = "Enable chat messages for quest information.",
	["lang_chat_settings"] = "Chat Settings",
	["lang_Chat_AddonMessage_HeaderColor"] = "Addon Messaging Header Color",
	["lang_Chat_AddonMessage_HeaderColor_tip"] = "Set the header color for addon messaging.",
	["lang_Chat_AddonMessage_MsgColor"] = "Addon Messaging Message Color",
	["lang_Chat_AddonMessage_MsgColor_tip"] = "Set the message color for addon messaging.",
	["lang_Chat_QuestInfo_HeaderColor"] = "Quest Info Header Color",
	["lang_Chat_QuestInfo_HeaderColor_tip"] = "Set the header color for addon messaging.",
	["lang_Chat_QuestInfo_MsgColor"] = "Quest Info Message Color",
	["lang_Chat_QuestInfo_MsgColor_tip"] = "Set the message color for quest information.",
	

	
	["lang_quests_timer_settings"] = "Quest Timer Settings",
	["lang_quests_timer_settings_Tip"] = "Enable/disable Quest Timer and set fonts and colors.",
	["lang_veq_settings"] = "Vestige's Epic Quest",
	["lang_global_settings"] = "Global Settings",
	
	["lang_language_settings"] = "Language",
	["lang_preset_settings"] = "Preset",
	["lang_quests_filtered_settings"] = "Show Quest Types",
	["lang_overall_transparency"] = "Overall Transparency",
	["lang_overall_width"] = "Overall Width",
	["lang_position_lock"] = "Lock Background Position",
	["lang_backgroundcolor_opt"] = "Enable Background Color",
	["lang_backgroundcolor_value"] = "Background Color",
    ["lang_intelligent_background"] = "Intelligent Background",
	["lang_intelligent_background_tip"] = "The Intelligent Background fades out when you are moving or in combat and fades in when you are not",
	

	["lang_mouse_settings"] = "Mouse Controls Settings",
	["lang_mouse_1"] = "Mouse Left Button",
	["lang_mouse_2"] = "Mouse Center Button",
	["lang_mouse_3"] = "Mouse Right Button",
	["lang_mouse_4"] = "Mouse Button 4",
	["lang_mouse_5"] = "Mouse Button 5",

	["lang_timer_title_font"] = "Quest Timer Font",
	["lang_timer_title_font_tip"] = "Font for Quest Timer displayed on focus quests that have a timer.",
	["lang_timer_title_style"] = "Quest Timer Font Style",
	["lang_timer_title_style_tip"] = "Font style used onQuest Timer displayed on focus quests that have a timer.",
	["lang_timer_title_size"] = "Quest Timer Font Size",
	["lang_timer_title_size_tip"] = "Font size for Quest Timer displayed on focus quests that have a timer.",
	["lang_timer_title_color"] = "Queset Timer Font Color",
	["lang_timer_title_color_tip"] = "Font color for Quest Timer displayed on focus quests that have a ",
	
	["lang_area_settings"] = "Zones Quests Settings",
	["lang_area_name"] = "Show Quests Zone/Category Name",
	["lang_area_font"] = "Zone/Category Font",
	["lang_area_style"] = "Zone/Category Font Style",
	["lang_area_size"] = "Zone/Category Font Size",
	["lang_area_padding"] = "Zone/Category Padding Size",
	["lang_area_color"] = "Zone/Category Color",
	["lang_autohidequestzone_option"] = "Enable Auto Hide Zone",
	["lang_questzone_option"] = "Show Quests in Current Zone Only",
	["lang_quests_guild"] = "Show Guilds Quests",
	["lang_quests_mainstory"] = "Show Main Story Quests",
	["lang_quests_cyrodiil"] = "Show Cyrodiil Quests",

	["lang_quests_class"] = "Show Class Quests",
	["lang_quests_class_tip"] = "Toggle class quests being visible.",
	["lang_quests_crafting"] = "Show Crafting Quests",
	["lang_quests_crafting_tip"] = "Toggle crafting quests being visible.",
	["lang_quests_group"] = "Show Group Quests",
	["lang_quests_group_tip"] = "Toggle Group quests being visible.",
	["lang_quests_dungeon"] = "Show Dungeon Quests",
	["lang_quests_dungeon_tip"] = "Toggle dungeon quests being visible.",
	["lang_quests_raid"] = "Show Raid quests",
	["lang_quests_raid_tip"] = "Toggle Raid quests being visible.",
	["lang_quests_AVA"] = "Show AVA quests",
	["lang_quests_AVA_tip"] = "Toggle AVA Quests being visible.",
	["lang_quests_event"] = "Show Event/Holiday Quests",
	["lang_quests_event_tip"] = "Toggle Event/Holiday quests being visible.",
	["lang_quests_BG"] = "Show Battleground Quests",
	["lang_quests_BG_tip"] = "Toggle Battleground quests being visible.",
	["lang_area_hybrid"] = "Show Category Zone View",
	["lang_area_hybrid_tip"] = "Show zones in the classic Catefory view, example, Guild quests listed in its own category not the zone they are in.",

	["lang_no_trans_focused_zone"] = "Focused Quest Zone Transparency",
	["lang_no_trans_focused_zone_tip"] = "The zone or category the focused quest is in, will not use the Not Focused Transparency",
	
	["lang_quests_settings"] = "Quests Settings",
	["lang_quests_sort"] = "Sort Quests By...",
	["lang_quests_nb"] = "Displayed Quests for Same Zone", 
	["lang_quests_show_timer"] = "Show Quest Timer",
	["lang_quests_show_timer_tip"] = "Show Quest Timer for the focused quest when there is a completion timer.  Please note a blank field will appear at the",
	
	

	["lang_quests_hide_obj"] = "Hide Objectives/Hints Except when Focused",
	["lang_quests_hide_obj_tip"] = "Hide the quest objectives and hints from all quests except on the focused quest.",
	
	["lang_quests_hide_obj_optional"] = "Hide Completed Hints and Objectives",
	["lang_quests_hide_obj_optional_tip"] = "Hide the quests optional objectives/hints that have been completed for all quests.",
	
	["lang_quests_level"] = "Show Quests Level",
	["lang_quests_optinfos"] = "Hide ALL Hints and Optional Info",
	["lang_quests_autoshare"] = "Auto Share Quests",
	["lang_quests_autountrack"] = "Auto Untrack Hidden Quests",
	["lang_icon_opt"] = "Enable Quest Icon",
	["lang_icon_texture"] = "Quest Icon Texture",
	["lang_icon_size"] = "Quest Icon Size",
	["lang_icon_color"] = "Quest Icon Color",
	["lang_quests_transparency_opt"] = "Enable Transparency for quests that are not focused.",
	["lang_quests_transparency"] = "Not Focused Quests Transparency",

	["lang_titles_settings"] = "Quest Name Settings",
	["lang_titles_font"] = "Quest Name Font",
	["lang_titles_style"] = "Quest Name Font Style",
	["lang_titles_size"] = "Quest Name Font Size",
	["lang_titles_padding"] = "Quest Name Padding Size",
	["lang_titles_default"] = "Default Quest Name Color",
	["lang_titles_custom"] = "Custom Titles Colors",
	["lang_titles_veasy"] = "Quest Name Color for Very Easy Quests",
	["lang_titles_easy"] = "Quest Name Color for Easy Quests",
	["lang_titles_normal"] = "Quest Name Color for Normal Quests",
	["lang_titles_hard"] = "Quest Name Color for Hard Quests",
	["lang_titles_vhard"] = "Quest Name Color for Very Hard Quests",

	["lang_obj_settings"] = "Objectives/Hints Settings",
	["lang_obj_font"] = "Objectives Font",
	["lang_obj_style"] = "Objectives Font Style",
	["lang_obj_size"] = "Objectives Font Size",
	["lang_obj_padding"] = "Objectives Padding Size",
	["lang_obj_color"] = "Objectives Font Color",
	["lang_obj_ccolor"] = "Completed Objectives Font Color",
	["lang_obj_optcolor"] = "Optional Objectives Font Color",
	["lang_obj_optccolor"] = "Completed Optional Objectives Font Color",

	["lang_infos_settings"] = "Infos Settings",
	["lang_infos_font"] = "Infos Font",
	["lang_infos_style"] = "Infos Font Style",
	["lang_infos_size"] = "Infos Font Size",
	["lang_infos_color"] = "Infos Font Color",
	
	["lang_NumbQuest_opt"] = "Show number of quests",
	["lang_NumbQuest_opt_tip"] = "Show number of started quests and total number of quests",
	["lang_ShowClock_opt"] = "Show Clock",
	["lang_ShowClock_opt_tip"] = "Show clock on the topleft of the quest tracker",
	["lang_ShowTbutton_opt"] = "Show focused quest keybind icon",
	["lang_ShowTbutton_opt_tip"] = "Show icon with keybind to change focused quest",
	["lang_ShowMQbutton_opt"] = "Show focused mini quest keybind icon",
	["lang_ShowMQbutton_opt_tip"] = "Show icon with keybind to change focused mini quest",
	
	

	
	-- Menu tips
	["lang_language_settings_tip"] = "Set your language",
	["lang_preset_settings_tip"] = "Select a preset",
	["lang_overall_transparency_tip"] = "Change the global transparency",
	["lang_overall_width_tip"] = "Change the window width",
	["lang_position_lock_tip"] = "Lock/Unlock position and enable mouse actions",
	["lang_backgroundcolor_opt_tip"] = "Enable background color",
	["lang_backgroundcolor_value_tip"] = "Change the background color",
	
	["lang_mouse_1_tip"] = "Set an action for the left click on quest name when in cursor mode",
	["lang_mouse_2_tip"] = "Set an action for the center click on quest name when in cursor mode",
	["lang_mouse_3_tip"] = "Set an action for the right click on quest name when in cursor mode",
	["lang_mouse_4_tip"] = "Set an action for the button 4 on quest name when in cursor mode",
	["lang_mouse_5_tip"] = "Set an action for the button 5 on quest name when in cursor mode",
	
	["lang_area_name_tip"] = "Enable the quest zone/category name to be displayed.",
	["lang_area_font_tip"] = "Set the font for the zone/category for the quest.",
	["lang_area_style_tip"] = "Set the font style for the zone/category for the quest",
	["lang_area_size_tip"] = "Change the font size for the zone/category for the quest",
	["lang_area_padding_tip"] = "Change the left and right padding size for the zone/category for the quest",
	["lang_area_color_tip"] = "Change the color for the zone/category for the quest",
	["lang_autohidequestzone_option_tip"] = "Follow the focused quest and hide others zone/category for the quest",
	["lang_questzone_option_tip"] = "Show quests in the current zone/category for the focused quest",
	["lang_quests_guild_tip"] = "Show guilds quests",
	["lang_quests_mainstory_tip"] = "Show main story quests",
	["lang_quests_cyrodiil_tip"] = "Show Cyrodiil quests",

	["lang_quests_sort_tip"] = "Set the order for quests",
	["lang_quests_nb_tip"] = "Change the number of quest displayed for the same zone as the focused quest",
	["lang_quests_show_quest_timer_tip"] = "Show timer for timed quests",
	["lang_quests_level_tip"] = "Show quests level",
	["lang_quests_optinfos_tip"] = "Hide hidden infos/hints for all quests, including focused quest.",
	["lang_quests_autoshare_tip"] = "Enable the quest auto share when you are in group",
	["lang_quests_autountrack_tip"] = "Untrack on the compass all hidden quests",
	["lang_icon_opt_tip"] = "Enable the quest icon",
	["lang_icon_texture_tip"] = "Set the icon for the current assisted quest",
	["lang_icon_size_tip"] = "Change the icon size",
	["lang_icon_color_tip"] = "Change the color for the quest icon",
	["lang_quests_transparency_opt_tip"] = "Enable the transparency for other quests than the focused quest",
	["lang_quests_transparency_tip"] = "Change the transparency of quests that are not focused.",

	["lang_titles_font_tip"] = "Set the font for the quest names",
	["lang_titles_style_tip"] = "Set the font style the quest names",
	["lang_titles_size_tip"] = "Change the font size for quest names",
	["lang_titles_padding_tip"] = "Change the left and right padding size for quest names",
	["lang_titles_default_tip"] = "Change the color of quest names",
	["lang_titles_custom_tip"] = "Enable changing color from player level",
	["lang_titles_veasy_tip"] = "Change the color of quest names < level - 4",
	["lang_titles_easy_tip"] = "Change the color of quest names <= level - 2",
	["lang_titles_normal_tip"] = "Change the color of quest names = level +- 1",
	["lang_titles_hard_tip"] = "Change the color of quest names >= level + 2",
	["lang_titles_vhard_tip"] = "Change the color of quest names > level + 4",	
	
	["lang_obj_font_tip"] = "Set the font for the quest text",
	["lang_obj_style_tip"] = "Set the font style the quest text",
	["lang_obj_size_tip"] = "Change the font size for quest text",
	["lang_obj_padding_tip"] = "Change the left and right padding size for quest text",
	["lang_obj_color_tip"] = "Change the color of quest text",
	["lang_obj_ccolor_tip"] = "Change the color of the completed objectives text",
	["lang_obj_optcolor_tip"] = "Change the color of optional quest text",
	["lang_obj_optccolor_tip"] = "Change the color of the completed optional objectives text",

	["lang_infos_opt_tip"] = "Display total of current quests",
	["lang_infos_font_tip"] = "Set the font for informations",
	["lang_infos_style_tip"] = "Set the font style for informations",
	["lang_infos_size_tip"] = "Change the font size for informations",
	["lang_infos_color_tip"] = "Change the font color for informations",
	
	-- Menu Warn
	["lang_menu_warn_1"] = "|c8B1E1E Change this option will reload the UI",
	["lang_menu_warn_2"] = "|c8B1E1E Change this option will reload the UI and overwrites your current settings",


	-- Mouse Interactions
	["lang_mouse_ctrl_assisted"] = "Change Assisted Quest",
	["lang_mouse_ctrl_filterzone"] = "Filter by Current Zone",
	["lang_mouse_ctrl_share"] = "Share a Quest",
	["lang_mouse_ctrl_showmap"] = "Show on Map",
	["lang_mouse_ctrl_remove"] = "Remove a Quest",
	
	-- Console
	["lang_console_autoshare"] = "[VEQ] You auto share a quest",
	["lang_console_share"] = "[VEQ] You share a quest",
	["lang_console_noshare"] = "[VEQ] This quest is not shareable",
	["lang_console_abandon"] = "[VEQ] Abandon quest",
	["lang_choose"] = "Choose: ",









----------------------------------- NEW STUFF

	["lang_tmp_VEQMessage"] = "<<1>>: <<2>>",
	["lang_tmp_VEQMessage_Error"] = "ERROR <<1>>: <<2>>",


	-- Quests Infos
	["quest_optional"] = "Optional",
	["quest_hint"] = "Hint",	
	["quest_hiddenhint"] = "Hidden Hint",
	
	["lang_tracker_type_guild"] = "Guild",
	["lang_tracker_type_mainstory"] = "Main Story Quest",
	["lang_tracker_type_undaunted"] = "Undaunted",
	["lang_tracker_type_prologue"] = "Prologue",	
	["lang_tracker_type_companion"] = "Companion",
	["lang_tracker_type_repeatable"] = "RPT",
	["lang_tracker_type_daily"] = "Daily",
	["lang_tracker_type_dungeon"] = "Dungeon",
	["lang_tracker_type_solo"] = "Solo",
	["lang_tracker_type_class"] = "Class",
	["lang_tracker_type_craft"] = "Crafting",
	["lang_tracker_type_group"] = "Group",
	["lang_tracker_type_ava"] = "Alliance War",
	["lang_tracker_type_arena"] = "Arena",
	["lang_tracker_type_holiday_event"] = "Holiday Event",
	["lang_tracker_type_raid"] = "Trial",
	["lang_tracker_type_bg"] = "Battleground",
	["lang_tracker_type_qa_test"] = "Test",
	["lang_tracker_type_dark_brotherhood"] = "Dark Brotherhood",
	["lang_tracker_type_thieves_guild"] = "Thieves Guild",
	["lang_tracker_type_mages_guild"] = "Mages Guild",
	["lang_tracker_type_fighters_guild"] = "Fighters Guild",
	["lang_tracker_type_psijic_order"] = "Psijic Order",
	
	
	
	-- Inventory
	["lang_slots_inventory"] = " Slots left in Inventory",
	["lang_slot_inventory"] = " Slot left in Inventory",
	["lang_free_space"] = "Free up some Space",
	["lang_inventory_full"] = "Inventory is full!",
	
	-- Treasure
	["lang_survey_map"] = "Survey Map",
	["lang_treasure_map"] = "Treasure Map",
	["lang_get_materials"] = "Get the Materials",
	["lang_get_treasure"] = "Get the Treasure",
	
	-- Skyshards
	["lang_skyshard"] = "Skyshard",
	["lang_maway"] = "m Away",
	["lang_distant_sky"] = "Imperceptible Aetherial Magicka Presence",
	["lang_weak_sky"] = "Weak Aetherial Magicka Presence",
	["lang_moderate_sky"] = "Moderate Aetherial Magicka Presence",
	["lang_strong_sky"] = "Strong Aetherial Magicka Presence",
	["lang_huge_sky"] = "Huge Aetherial Magicka Presence",
	
	-- Leads / antiquities
	["lang_scry_exc"] = "Scry and Excavate in ",
	["lang_antiquity_"] = "Antiquity - ",
	
	-- Doable writs
	["lang_check_inv"] = "Click here to Start Crafting",
	["lang_doable"] = "Doable ",
	["lang_or"] = " or ",
	
	-- Riding skills
	["lang_stable_rel"] = "A Stable Relationship",
	["lang_upgrade_skills"] = "Upgrade one of your Riding Skills",	
	["lang_stablemaster"] = "Stablemaster",
	
	-- Backpack & Bank upgrade
	["lang_backpack_upgrade"] = "Backpack Upgrade",
	["lang_you_have_the"] = "You have the ",
	["lang_up_back"] = "g! Upgrade your Backpack",
	["lang_pack_merchant"] = "Pack Merchant",
	["lang_bank_space_upgrade"] = "Bank Space Upgrade",
	["lang_up_bank"] = "g! Upgrade your Bank Space",
	["lang_bank_mon"] = "Banker or Moneylender",
	
	-- Endeavor	
	["lang_endeavor_week"] = "Weekly Endeavors",
	["lang_endeavor_day"] = "Daily Endeavors",
	
	
	
	-- Event Tickets & transmute crystals
	["lang_event_tickets"] = "Event Tickets",
	["lang_transmute_crystals"] ="Transmute Crystals",
	["lang_maxed_out_currency"] = "That Currency is Maxed out! Spend it.",
	["lang_nears_max_currency"] = "That Currency Nears the Maximum Allowed, Spend it.",
	
	
	-- LFG & ready check
	["lang_in"] = " in ",
	["lang_champion_battleground"] = "Champion Battleground",
	["lang_low_battleground"] = "Low Level Battleground",
	["lang_non_battleground"] = "Non Champion Battleground",
	["lang_normal_dungeon_finder"] = GetString(SI_DUNGEONDIFFICULTY1).." Dungeon Finder",
	["lang_veteran_dungeon_finder"] = GetString(SI_DUNGEONDIFFICULTY2).." Dungeon Finder",
	["lang_tribute_casual"] = "Casual Tales of Tribute",
	["lang_tribute_competitive"] = "Competitive Tales of Tribute",
	["lang_lfg"] = "Looking for Group...",
	["lang_lfo"] = "Looking for Opponent...",
	["lang_everybody_ready"] = "Is Everybody Ready?",
	["lang_ready"] = " ready",
	["lang_grc"] = "Group Ready Check",
	["lang_for"] = " for ",
	["lang_LFR"] = "Seeking replacement",
	
	-- Entering campaign
	["lang_cyrodiil"] = "Cyrodiil - ",
	["lang_group"] = "Group - ",
	["lang_ewt"] = "\n• Remaining Waiting Time: ",
	["lang_entering_campaign"] = "Entering Campaign...",
	["lang_n_started"] = "\n• Started ",
	["lang_ago"] = " ago",
	["lang_confirming"] = "Confirming",
	["lang_finished"] = "Finished", 
	["lang_pending_accept"] = "Entering...",
	["lang_pending_join"] = "Pending Join",
	["lang_leaving_queue"] = "Leaving Queue",
	["lang_exiting_campaign"] = "Exiting Campaign...",
	["lang_waiting"] = "Waiting",
	["lang_n_queue_position"] = "\n• Queue Position: ",
	
    -- Poison checker  / notifier	
	["lang_out_of_poison"] = "Out of Poison!",	
	["lang_craft_some_poison"] = "Craft or buy some Poison and Apply it to your Weapon",
	["lang_alchemy_station"] = "Alchemy Station",
	
    -- Psijic Time Breaches helper
    ["lang_psijic_time_breach"] = "Psijic Time Breach #",	
	["lang_6172_helper_9"] = "Halfway between the Augury Basin and Keelsplitter's Nest (Go West from Ebon Stadmont wayshrine, jump into the pond and follow the stream, the breach is at the foot of the waterfall)",	
	["lang_6172_helper_8"] = "Between Keelsplitter's Nest and Rellenthil Abyssal Geyser, on the tiny island with the tree (South from Ebon Stadmont wayshrine)",
	["lang_6172_helper_7"] = "In a ruined structure west of Alinor, halfway between Welenkin Cove and Welenkin Abyssal Geyser (Go down the cobblestone path South from Cey-Tarn Keep wayshrine, keep right at each fork including the broken bridge leading to the structure)",
	["lang_6172_helper_6"] = "Inside the Direnni Acropolis, after the bridge (Go down the cobblestone path Southeast from King's Haven Pass wayshrine, keep left at the fork)",
	["lang_6172_helper_5"] = "Below the waterfall west of Shimmerene (Gallop North from Shimmerene wayshrine and jump in the water the farthest you can)",
	["lang_6172_helper_4"] = "In the ruins on the hill, North of the lake by Archon's Grove, East of Keep of the Eleven Forces (Go South from the Shimmerene wayshrine)",
	["lang_6172_helper_3"] = "In one of the enclosures in Sil-Var-Woad (Go South from the Sil-Var-Woad wayshrine, enter the zoo, keep right at the fork, in the water enclosure)",
	["lang_6172_helper_2"] = "On the East shore of the island Southeast of Sil-Var-Woad, Southeast of the Sil-Var-Woad Abyssal Geyser, nearby the two Northmost tiny islands",
	["lang_6172_helper_1"] = "South of Sunhold Wayshrine, West of the Sunhold Abyssal Geyser",
	
	
	["lang_6181_helper_9"] = "On a cliff overlooking Deleyn's Mill, North of Daenia Dolmen (Head South from Baelborne Rock wayshrine, run in the river, under the bridge, then head Southeast, the breach is a bit farther than the painting easel)",
	["lang_6181_helper_8"] = "Between the roots on the North side of the Beldama Wyrd Tree (Wyrd Tree wayshrine)",
	["lang_6181_helper_7"] = "On a bluff on the West side of Burial Mounds (Go Southwest from Crosswych wayshrine until the huge bad weed and then head South-southeast on top of the bluff)",
	["lang_6181_helper_6"] = "Inside the Southmost part of a shipwreck on the West side of the Koeglin Lighthouse island (Go West-southwest from Bonesnap Ruins wayshrine)",
	["lang_6181_helper_5"] = "On the edge of the highest tier of Cumberland Falls (Go west from Wind Keep wayshrine, follow the river upstream to the waterfall, and climb at it's top)",
	["lang_6181_helper_4"] = "Just west of Moonlit Maw (Go North from Pariah Abbey wayshrine)",
	["lang_6181_helper_3"] = "On the edge of a cliff north of Salas En, northeast of The Warrior, overlooking Rain Catcher Fields (Go West from Morwha's Bounty wayshrine, climb, go West again to the edge of the cliff)",
	["lang_6181_helper_2"] = "Against a cliff wall west of Easterly Aerie (Go West from Kulati Mines wayshrine, surround the rock to the right, take the bridge, go left to climb on the higher platform)",
	["lang_6181_helper_1"] = "Between HoonDing's Watch and Ragnthar (Go South from HoonDing's Watch wayshrine, climb the sand on your left when you can, go South again)",
	
	
	["lang_6185_helper_9"] = "Between the two Southmost lava Streams on the West side of Senie (Go West from Senie wayshrine)",
    ["lang_6185_helper_8"] = "On an tiny Island at the top of the Waterfall between Brothers of Strife and Armature's Upheaval (Go Southwest from Brothers of Strife wayshrine)",
    ["lang_6185_helper_7"] = "On top of the ridge above Vivec's Antlers between Sulfur Pools wayshrine and Vivec's Antlers (Go East from Sulfur Pools wayshrine)",
    ["lang_6185_helper_6"] = "Next to one of the larger steam pools at Wittestadr (Go Northeast from Wittestadr wayshrine, the breach is exactly at the Wittestadr icon on the map)",
    ["lang_6185_helper_5"] = "Between the two Waterfalls upstream the river Southwest of Darkwater Crossing, Southeast of the Fort Amol map (Go Southeast from Fort Amol wayshrine)",
    ["lang_6185_helper_4"] = "In the river West the bridge East of Cradlecrush, Northwest of Thane Jeggi's Drinking Hole (Go Southwest from Fort Morvunskar wayshrine and follow the cobblestone road, keep left at the fork, look on your right at the bridge)",
    ["lang_6185_helper_3"] = "Northeast of Fort Greenwall, Southwest of Troll Cave (Go through Fort Greenwall North from Riften wayshrine, and then Northeast)",
    ["lang_6185_helper_2"] = "Just outside Snapleg Cave (Cross the bridge North of Nimalten wayshrine and continue along the river to the cave)",
    ["lang_6185_helper_1"] = "At the top of the steps near the Throat of the World, Northwest of Ivarstead (Go West-southwest from Geirmund's Hall wayshrine, cross the bridge and follow the plethora of steps)",	
	

    ["lang_6197_helper_adamantine"] = "Go Southwest from Eastern Evermore wayshrine, use the Time Breach in Pelin Graveyard, follow the Psijic sight, dig up the staff piece",
	["lang_6197_helper_orichalc"] = "Go Southwest of Leki's Blade wayshrine, use the Time Breach North of Leki's Blade, follow the Psijic sight, dig up the staff piece",
	["lang_6197_helper_crystal"] = "Go North of the Hatching Pools wayshrine, use the Time Breach in Hatching Pools (under the Great Hist Tree), follow the Psijic sight, dig up the staff piece",
	["lang_6197_helper_walk"] = "Go South from Selfora wayshrine, use the Time Breach near Fang Spires, follow the Psijic sight, dig up the staff piece",
	
	["lang_6197_helper_pelin"] = "Staff Fragment near Pelin Graveyard",
	["lang_6197_helper_leki"] = "Staff Fragment near Leki's Blade",	
	["lang_6197_helper_hist"] = "Staff Fragment near the Hist",
	["lang_6197_helper_fang"] = "Staff Fragment near Fang Spires",	
	
	
	["lang_6194_helper_9"] = "In a ruined structure on the West side of the Ossuary of Telacar (Go North-northwest from Ossuary wayshrine)",
	["lang_6194_helper_8"] = "Inside the stump of Gil-Var-Delle, West of the Dolmen (Go South from Gil-Var-Delle wayshrine)",
	["lang_6194_helper_7"] = "Inside the highest tower ruin, North of Reman's Bluff (Go West-southwest from Redfur Trading Post wayshrine)",
	["lang_6194_helper_6"] = "On a promontory north of Maormer Camp (Cross the very bridge North-northwest of Moonhenge wayshrine, follow the cobblestone road, go straight ahead to the edge of the cliff when the road turns right)",
	["lang_6194_helper_5"] = "North of Fisherman's Rest (Surround the mountain by West from Serpent's Grotto wayshrine)",
	["lang_6194_helper_4"] = "Within the Labyrinth, just north of the center (Take the very bridge North from Greenheart wayshrine, continue straight ahead without following the road, follow it when it's back under your feet, take the 1st Labyrinth entrance on your left, go right at the 1st fork and left at the 2nd)",
	["lang_6194_helper_3"] = "Under a bridge south of Treehenge, west of Ragnthar (Follow the path North of Wilding Run wayshrine until you reach the bridge, jump)",
	["lang_6194_helper_2"] = "In the middle of Horseshoe Island (Go North from Vulkwasten wayshrine)",
	["lang_6194_helper_1"] = "On the island Northeast of Xylo River Basin Dolmen (Go North from Abamath wayshrine)",

	["lang_6190_helper_9"] = "On the cliff south of Bthanual (Follow the road East from Muth Gnaar Hills wayshrine, cross the bridge, keep left at the fork, go South before Bthanual entrance)",
	["lang_6190_helper_8"] = "By the waterfall Northeast of Darkshade Caverns (Go Southwest from Silent Mire wayshrine, climb the rock to the higher platform)",
	["lang_6190_helper_7"] = "In a planter in the middle of the Shrine of Saint Veloth (Follow the road Northwest from Eidolon's Hollow wayshrine, keep left at the 1st fork and right at the 2nd one)",
	["lang_6190_helper_6"] = "On a tiny island by the waterfalls Northeast of The Triple Circle Mine (Go South from Shad Astula wayshrine, swim, jump down the waterfall, swim)",
	["lang_6190_helper_5"] = "Behind the huge gates of Malak's Maw (Go West from West Narsis wayshrine and do a full lap clockwise)",
	["lang_6190_helper_4"] = "Under a tree's roots in the Southwest corner in Bogmother (Go West from Bogmother wayshrine)",
	["lang_6190_helper_3"] = "Inside a stone mouth in western Hei-Halai, near the entrance to the Ruins of Mazzatun (Follow the road North from Stillrise wayshrine, when you see a tower ruin on your left next to the road  go Northwest, Then follow the path on your left to the stone mouth)",
	["lang_6190_helper_2"] = "In a small xanmeer Northwest of the Venomous Fens Dolmen (Go Southeast from Loriasel wayshrine)",
	["lang_6190_helper_1"] = "At the foot of the Hist tree in the middle of Percolating Mire (Go Northeast from Percolating Mire wayshrine)",


	
	["lang_6198_helper_red"] = "Go South of Brothers of Strife wayshrine, use the Time Breach, follow the Psijic sight, dig up the staff piece",
	["lang_6198_helper_white"] = "Go Northwest from Weeping Giant wayshrine until the tower ruin, then follow the path on your right, cross the planks bridge, use the Time Breach, follow the Psijic sight, dig up the staff piece",
    ["lang_6198_helper_greensap"] = "Go North of Greenheart Wayshrine wayshrine, use the Time Breach, follow the Psijic sight, dig up the staff piece",
    ["lang_6198_helper_snow"] = "Go East from Spellscar wayshrine, between the rock cliff and Adament Anomaly, at the end of the rock cliff, turn left, use the Time Breach, follow the Psijic sight, dig up the staff piece",

	["lang_6198_helper_bro"] = "Staff Fragment near the Brothers of Strife",
	["lang_6198_helper_weep"] = "Staff Fragment near the Weeping Giant",	
	["lang_6198_helper_green"] = "Staff Fragment near Greenheart",
	["lang_6198_helper_spell"] = "Staff Fragment near Spellscar",	
	
	
	["lang_6468_helper_9"] = "On the wall West of Trader's Rest (Go Northeast from Oldgate wayshrine)",
    ["lang_6468_helper_8"] = "At Sanguine Barrows, between the central tomb and Tribulation Crypt (Go North from Sanguine Barrows wayshrine)",
    ["lang_6468_helper_7"] = "In front of the Northern tower at Lorkrata Hills (Go West from Fell's Run wayshrine, once inside Lorkrata Hills walls take the stairs on your right)",
    ["lang_6468_helper_6"] = "In a field at Edrald Estate (Go East-southeast from Fell's Run wayshrine)",
    ["lang_6468_helper_5"] = "On an island West of East-Rock Landing, North of Orc's Finger Ruins, Southwest of the Serpent (Go East from Boralis wayshrine)",
	["lang_6468_helper_4"] = "In the captain's cabin of Lagra's Pearl (Go Northeast from Northpoint wayshrine)",
	["lang_6468_helper_3"] = "In front of the Chapel Crypts at Crestshade (Follow the cobblestone road South from the Crestshade wayshrine, at the statue, go Southwest and go up the stairs, the other set of stairs on the left, continue straight ahead to the stairs of  the Chapel Crypts)",
	["lang_6468_helper_2"] = "Just west of Aesar's Web (Go West of Tamrith Camp wayshrine)",
	["lang_6468_helper_1"] = "Inside Shadowfate Cavern (The entrance is between Aesar's Web and Tamrith Camp wayshrine)",
	

	["lang_6196_helper_6"] = "Northeast of Ogondar's Winery, West of Rkundzelft (Go East from Spellscar wayshrine, between the rock cliff and Adament Anomaly, at the end of the rock cliff go Southeast)",
	["lang_6196_helper_5"] = "Outside the Northwest corner of Elinhir (Go South from Elinhir wayshrine, surround Elinhir rock cliff by the right until you find the breach)",
	["lang_6196_helper_4"] = "In a crevice at the South end of Scorpion Ravine (Go Southwest from Seeker's Archive wayshrine)",
	["lang_6196_helper_3"] = "North of Hel Ra Citadel, East of Mtharnaz (Go West from Sandy Path wayshrine)",
	["lang_6196_helper_2"] = "In front of Dragonstar Arena (Dragonstar wayshrine)",
	["lang_6196_helper_1"] = "On the bridge to Skyreach Hold (Skyreach wayshrine)",
	
	["lang_6199_helper"] = "From Goat's Head Oasis wayshrine, climb the stairs then go Southwest to Divad's Chagrin mine",
	
	
	-- Group frames
	["lang_of"] = " of ",
	
	-- Museum Pieces
	["lang_museum"] = "Return",

	-- Dailies counter
	["lang_repeatable_quests"] = "Repeatable Quests",
	["lang_ongoing"] = "Ongoing: ",
	["lang_completed_today"] = "Completed Today: ",
	
	-- zone todo list
	["lang_todolist"] = "Zone to-do list",
	
	-- remains silent
	["lang_remains_silent"] = "<You nod knowingly.>",
	
	-- Dragonguard Supply chest name (change to your language for the feature to work)
	["lang_dragonguard_supply_chest"] = "Dragonguard Supply Chest",
	 
	-- mini tracker settings
	["lang_mini_quest_tracker_settings"] = "Mini Quest Tracker Settings",
	["lang_mini_quest_tracker_invert_opt"] = "Invert key",
	["lang_mini_quest_tracker_invert_tip"] = "Get previous Mini quest instead of next by long pressing that key while presing the default keybind",
	["lang_inventory_slots_opt"] = "Empty Inventory Slots Mini Quest",
	["lang_inventory_slots_tip"] = "A mini quest to empty your inventory when it reaches the minimal empty slot limit you set up",
	["lang_inventory_slots_limit"] = "Free inventory slots trigger",
	["lang_inventory_slots_limit_tip"] = "Number of minimum free inventory slots which triggers the mini quest",	
	["lang_lost_treasure_opt"] = "Lost Treasure Mini Quest",
	["lang_lost_treasure_tip"] = "Adds a mini quest for treasure maps and survey locations as soon as they pop in your bag (perfect with the Lost Treasure addon)",	
	["lang_skyshards_opt"] = "Skyshards Mini Quest",
	["lang_skyshards_tip"] = "Adds a mini quest to get a skyshard if it is closer than 100m away",	
    ["lang_leads_opt"] = "Leads Mini Quest",
	["lang_leads_tip"] = "Adds a mini quest to go scrying and excavating an antiquity for each of the leads you have",
    ["lang_fake_leads_opt"] = "Scrying and Excavating progression",
	["lang_fake_leads_tip"] = "Daily adds a mini quest to go scrying and excavating an antiquity for a smooth progression of these skill lines",
	["lang_writs_opt"] = "Doable Writs Mini Quest",
	["lang_writs_tip"] = "Adds a mini quest for each Doable Writ (have knowledge + have mats) in your inventory. (Needs the WritWorthy addon installed to work)",
	["lang_stable_opt"] = "Riding Skills Upgrade Mini Quest",
	["lang_stable_tip"] = "Adds a mini quest to upgrade your riding skills as soon as you meet the conditions",	
	["lang_backbank_opt"] = "Backpack & Bank Upgrade Mini Quest",
	["lang_backbank_tip"] = "Adds a mini quest to upgrade your backpack or bank space as soon as you have the required gold",		
	["lang_endeavor_opt"] = "Daily & Weekly Endeavor Mini Quest",
	["lang_endeavor_tip"] = "Adds daily & weekly endeavors as a mini quest.",
	["lang_goldenPursuit_opt"] = "Golden Pursuit Mini Quest",
	["lang_goldenPursuit_tip"] = "Adds each Golden Pursuit as a mini quest.",
	["lang_communityEvents_opt"] = "Community Event Mini Quest",
	["lang_communityEvents_tip"] = "Adds each Community Event as a mini quest.",
	["lang_tickets_opt"] = "Spend Event Tickets Mini Quest",
	["lang_tickets_tip"] = "A mini quest to spend your Event Tickets when it reaches the minimal left to cap limit you set up",	
	["lang_tickets_limit"] = "Minimum Event Tickets Left to cap trigger",
	["lang_tickets_limit_tip"] = "Number of minimum Event Tickets Left to cap which triggers the mini quest",
	["lang_transmute_opt"] = "Spend Transmute Crystals Mini Quest",
	["lang_transmute_tip"] = "A mini quest to spend your Transmute Crystals when it reaches the minimal left to cap limit you set up",	
	["lang_transmute_limit"] = "Minimum Transmute Crystals Left to cap trigger",
	["lang_transmute_limit_tip"] = "Number of minimum Transmute Crystals Left to cap which triggers the mini quest",
    ["lang_zoneguide_opt"] = "Set next Zone Guide quest as a Mini Quest",
	["lang_zoneguide_tip"] = "Zone guide mini quests auto enables and becomes a mini quest in VEQ on zone change and if you have no active quest in that zone",
    ["lang_POIcompletion_opt"] = "Set undiscovered zone Points of interest as a Mini Quest",
	["lang_POIcompletion_tip"] = "One Undiscovered zone Point of interest becomes a mini quest in VEQ on zone change",
    ["lang_poison_opt"] = "Poison Checker",
	["lang_poison_tip"] = "Checks your weapon poison slots after each combat, if you are out of poison a miniquest to craft poison is displayed",	
	["lang_group_frames_opt"] = "Companions & Group members' names as lifebars",
	["lang_group_frames_tip"] = "Displays group member's names as colored lifebars",
	["lang_default_group_frames_opt"] = "Hide the game's default group frames",
	["lang_default_group_frames_tip"] = "Toggle this switch in case of conflict with another addon concerning the default group frames display",	
	["lang_museum_pieces_opt"] = "Museum Pieces Mini quest",
	["lang_museum_pieces_tip"] = "Adds a mini quest to bring back to the museum every museum piece you have in your inventory",
	["lang_dailies_counter_opt"] = "Daily Quests Counter",
	["lang_dailies_counter_tip"] = "Adds a counter to keep track of the 50 daily quests per day & character limit",
	["lang_NumbMiniQuest_opt"] = "Show number of mini quests",
	["lang_NumbMiniQuest_opt_tip"] = "Show number of mini quests",
	
}