VEQ.mylanguage = {
-- Menü - Çevirmen : XANTOS-TR | Ramazan USLU | https://discord.gg/6gwkDJnkaV
["lang_quests_category_view_settings"] = "Kategori Bölge Görünümü Ayarları",
["lang_class_show_zone"] = "Bölgeyi Sınıf Kategorisi Bölge Görünümünde göster",
["lang_class_show_zone_tip"] = "Kategori Bölge Görünümünü kullanırken Sınıf görevlerinin bölgesini gösterin",
["lang_craft_show_zone"] = "Bölgeyi El Sanatları Kategorisi Bölge Görünümünde göster",
["lang_craft_show_zone_tip"] = "Kategori Bölgesi Görünümünü kullanırken Crafting görevlerinin bölgesini gösterin",
["lang_Group_show_zone"] = "Bölgeyi Grup Kategorisi Bölge Görünümünde göster",
["lang_Group_show_zone_tip"] = "Kategori Bölge Görünümünü kullanırken Grup görevlerinin bölgesini gösterin",
["lang_Dungeon_show_zone"] = "Zindan Kategorisi Bölge Görünümünde bölgeyi göster",
["lang_Dungeon_show_zone_tip"] = "Kategori Bölge Görünümünü kullanırken Zindan görevlerinin bölgesini gösterin",
["lang_Raid_show_zone"] = "Baskın Kategorisi Bölge Görünümünde bölgeyi göster",
["lang_Raid_show_zone_tip"] = "Kategori Bölge Görünümünü kullanırken Raid görevlerinin bölgesini gösterin",
["lang_HideOptObjective"] = "İsteğe Bağlı Hedefleri Gizle",
["lang_HideOptObjective_tip"] = "Görevlerin isteğe bağlı hedeflerini gizle",
["lang_HideOptionalInfo"] = "İsteğe Bağlı Bilgileri Gizle",
["lang_HideOptionalInfo_tip"] = "İsteğe Bağlı Görev Bilgilerini Gizle",
["lang_HideHintsOption"] = "Görev İpuçlarını Gizle",
["lang_HideHintsOption_tip"] = "Görev için ipuçlarını gizle",
["lang_HideHiddenOptions"] = "Gizli Görev İpuçlarını Gizle",
["lang_HideHiddenOptions_tip"] = "Gizli görev ipuçlarını gizle.",
["lang_HintColor"] = "Görev İpucu Rengi",
["lang_HintColor_tip"] = "Görev ipuçlarının rengi",
["lang_HintCompleteColor"] = "Görev İpuçları Tamamlanan Renk",
["lang_HintCompleteColor_tip"] = "Görev ipuçlarının rengi tamamlandı.",
["lang_HideInCombat"] = "Savaş sırasında izleyiciyi gizle",
["lang_HideInCombat_tip"] = "Savaş sırasında izleyiciyi gizle",
["lang_QuestObjIcon"] = "Görev Adımı Simgelerini Göster",
["lang_QuestObjIcon_tip"] = "Metin sembolleri yerine Görev Adımı Simgelerini göster.",
["lang_HideObjOption"] = "HARİÇ tüm görevler için Hedefleri Gizle",
["lang_HideObjOption_tip"] = "Üç seçenek dışındaki tüm hedefleri gizleme seçeneği. Devre dışı bırakıldığında bu seçenek göz ardı edilir, Odaklanmış Görev, odaklanılan görev dışındaki tüm hedefleri gizler, Odaklanmış Bölge, odaklanılan görevin bulunduğu bölge dışındaki tüm hedefleri gizler. ",
["lang_Miscellaneous"] = "Çeşitli",
["lang_Toggle_AutoHide_off"] = "Bölgeyi/Kategoriyi Otomatik Gizleme Kapalı olarak ayarlandı",
["lang_Toggle_AutoHide_on"] = "Bölgeyi/Kategoriyi Otomatik Gizleme Açık olarak ayarlandı",
["lang_Collaspe_All_Zones"] = "Tüm Bölgeleri/Kategorileri Daralt",
["lang_Expand_All_Zones"] = "Tüm Bölgeleri/Kategorileri Genişlet",
["lang_Toggle_Category_off"] = "Bölge Görünümüne Değiştir",
["lang_Toggle_Category_on"] = "Kategori Görünümüne Değiştir",
["lang_Toggle_NotFocusTrans_on"] = "Odaklanmamış Şeffaflık Açık olarak ayarlandı",
["lang_Toggle_NotFocusTrans_off"] = "Odaklanmamış Şeffaflık Kapalı olarak ayarlandı",
["lang_Toggle_HintsHidden_on"] = "İpuçlarını ve Gizli İpuçlarını Gizle Açık",
["lang_Toggle_HintsHidden_off"] = "İpuçlarını ve Gizli İpuçlarını Gizle - Kapalı",
["lang_Toggle_HideObjOption_Disabled"] = "Tüm Görevler için Hedefler Açık",
["lang_Toggle_HideObjOption_FocusedQuest"] = "Yalnızca Odaklanmış Görev için Hedefler açık",
["lang_Toggle_HideObjOption_FocusedZone"] = "Odaklanmış Bölge Görevleri için Hedefler",
 
 
 
 
["lang_Chat_AddonMessages"] = "Eklenti için Sohbet Mesajlarını Etkinleştir",
["lang_Chat_AddonMessages_tip"] = "Sohbet mesajlarını, tuş bağlantılarına göre değişiklikler, hatalar vb. ile ilgili eklenti mesajlarını etkinleştirin.",
["lang_Chat_QuestInfo"] = "Görev Bilgisi için Sohbet Mesajlarını Etkinleştir",
["lang_Chat_QuestInfo_tip"] = "Görev bilgileri için sohbet mesajlarını etkinleştirin.",
["lang_chat_settings"] = "Sohbet Ayarları",
["lang_Chat_AddonMessage_HeaderColor"] = "Eklenti Mesajlaşma Başlık Rengi",
["lang_Chat_AddonMessage_HeaderColor_tip"] = "Eklenti mesajları için başlık rengini ayarlayın.",
["lang_Chat_AddonMessage_MsgColor"] = "Eklenti Mesajlaşma Mesajı Rengi",
["lang_Chat_AddonMessage_MsgColor_tip"] = "Eklenti mesajları için mesaj rengini ayarlayın.",
["lang_Chat_QuestInfo_HeaderColor"] = "Görev Bilgisi Başlığı Rengi",
["lang_Chat_QuestInfo_HeaderColor_tip"] = "Eklenti mesajları için başlık rengini ayarlayın.",
["lang_Chat_QuestInfo_MsgColor"] = "Görev Bilgi Mesajı Rengi",
["lang_Chat_QuestInfo_MsgColor_tip"] = "Görev bilgileri için mesaj rengini ayarlayın.",
 
 
 
["lang_quests_timer_settings"] = "Görev Zamanlayıcı Ayarları",
["lang_quests_timer_settings_Tip"] = "Görev Zamanlayıcıyı etkinleştirin/devre dışı bırakın ve yazı tiplerini ve renkleri ayarlayın.",
["lang_veq_settings"] = "Vestige's Epic Quest",
["lang_global_settings"] = "Genel Ayarlar",
 
["lang_language_settings"] = "Dil",
["lang_preset_settings"] = "Ön Ayar",
["lang_quests_filtered_settings"] = "Görev Türlerini Göster",
["lang_overall_transparency"] = "Genel Şeffaflık",
["lang_overall_width"] = "Genel Genişlik",
["lang_position_lock"] = "Arka Plan Konumunu Kilitle",
["lang_backgroundcolor_opt"] = "Arka Plan Rengini Etkinleştir",
["lang_backgroundcolor_value"] = "Arka Plan Rengi",
    ["lang_intelligent_background"] = "Intelligent Background",
	["lang_intelligent_background_tip"] = "The Intelligent Background fades out when you are moving or in combat and fades in when you are not",
 
["lang_mouse_settings"] = "Fare Kontrol Ayarları",
["lang_mouse_1"] = "Farenin Sol Düğmesi",
["lang_mouse_2"] = "Farenin Orta Düğmesi",
["lang_mouse_3"] = "Farenin Sağ Düğmesi",
["lang_mouse_4"] = "Fare Düğmesi 4",
["lang_mouse_5"] = "Fare Düğmesi 5",
 
["lang_timer_title_font"] = "Görev Zamanlayıcı Yazı Tipi",
["lang_timer_title_font_tip"] = "Zamanlayıcısı olan odaklanma görevlerinde Görev Zamanlayıcısı yazı tipi görüntülenir.",
["lang_timer_title_style"] = "Görev Zamanlayıcı Yazı Tipi Stili",
["lang_timer_title_style_tip"] = "Zamanlayıcısı olan odaklanma görevlerinde görüntülenen Görev Zamanlayıcısında kullanılan yazı tipi stili.",
["lang_timer_title_size"] = "Görev Zamanlayıcı Yazı Tipi Boyutu",
["lang_timer_title_size_tip"] = "Zamanlayıcısı olan odak görevlerinde görüntülenen Görev Zamanlayıcısı için yazı tipi boyutu.",
["lang_timer_title_color"] = "Queset Zamanlayıcı Yazı Tipi Rengi",
["lang_timer_title_color_tip"] = "Odaklanma görevlerinde görüntülenen Görev Zamanlayıcısı için yazı tipi rengi ",
 
["lang_area_settings"] = "Bölge Görev Ayarları",
["lang_area_name"] = "Görev Bölgesini/Kategori Adını Göster",
["lang_area_font"] = "Bölge/Kategori Yazı Tipi",
["lang_area_style"] = "Bölge/Kategori Yazı Tipi Stili",
["lang_area_size"] = "Bölge/Kategori Yazı Tipi Boyutu",
["lang_area_padding"] = "Bölge/Kategori Dolgu Boyutu",
["lang_area_color"] = "Bölge/Kategori Rengi",
["lang_autohidequestzone_option"] = "Bölgeyi Otomatik Gizlemeyi Etkinleştir",
["lang_questzone_option"] = "Yalnızca Geçerli Bölgedeki Görevleri Göster",
["lang_quests_guild"] = "Lonca Görevlerini Göster",
["lang_quests_mainstory"] = "Ana Hikaye Görevlerini Göster",
["lang_quests_cyrodiil"] = "Cyrodiil Görevlerini Göster",
 
["lang_quests_class"] = "Sınıf Görevlerini Göster",
["lang_quests_class_tip"] = "Sınıf görevlerinin görünür olmasını değiştir.",
["lang_quests_crafting"] = "Hazırlık Görevlerini Göster",
["lang_quests_crafting_tip"] = "Hazırlık görevlerinin görünür olmasını aç/kapat.",
["lang_quests_group"] = "Grup Görevlerini Göster",
["lang_quests_group_tip"] = "Grup görevlerinin görünür olmasını değiştir.",
["lang_quests_dungeon"] = "Zindan Görevlerini Göster",
["lang_quests_dungeon_tip"] = "Zindan görevlerinin görünür olmasını değiştir.",
["lang_quests_raid"] = "Baskın görevlerini göster",
["lang_quests_raid_tip"] = "Baskın görevlerinin görünür olmasını aç/kapat.",
["lang_quests_AVA"] = "AVA görevlerini göster",
["lang_quests_AVA_tip"] = "AVA Görevlerinin görünür olmasını değiştir.",
["lang_quests_event"] = "Etkinlik/Tatil Görevlerini Göster",
["lang_quests_event_tip"] = "Etkinlik/Tatil görevlerinin görünür olmasını değiştir.",
["lang_quests_BG"] = "Savaş Alanı Görevlerini Göster",
["lang_quests_BG_tip"] = "Battleground görevlerinin görünür olmasını değiştir.",
["lang_area_hybrid"] = "Kategori Bölgesi Görünümünü Göster",
["lang_area_hybrid_tip"] = "Klasik Catefory görünümünde bölgeleri göster; örneğin, Lonca görevleri bulundukları bölgede değil kendi kategorisinde listelenir.",
 
["lang_no_trans_focused_zone"] = "Odaklanmış Görev Bölgesi Şeffaflığı",
["lang_no_trans_focused_zone_tip"] = "Odaklanmış görevin bulunduğu bölge veya kategori, Odaklanmamış Şeffaflığı kullanmayacaktır",
 
["lang_quests_settings"] = "Görev Ayarları",
["lang_quests_sort"] = "Görevleri Şuna Göre Sırala...",
["lang_quests_nb"] = "Aynı Bölge için Görüntülenen Görevler",
["lang_quests_show_timer"] = "Görev Zamanlayıcısını Göster",
["lang_quests_show_timer_tip"] = "Tamamlanma zamanlayıcısı olduğunda odaklanılan görev için Görev Zamanlayıcısını göster. Lütfen görevde boş bir alan görüneceğini unutmayın",
 
 
 
["lang_quests_hide_obj"] = "Odaklanma Durumu Dışında Hedefleri/İpuçlarını Gizle",
["lang_quests_hide_obj_tip"] = "Odaklanan görev dışındaki tüm görevlerden görev hedeflerini ve ipuçlarını gizleyin.",
 
["lang_quests_hide_obj_opsiyonel"] = "Tamamlanan İpuçları ve Hedefleri Gizle",
["lang_quests_hide_obj_ Optional_tip"] = "Tüm görevler için tamamlanan görevin isteğe bağlı hedeflerini/ipuçlarını gizleyin.",
 
["lang_quests_level"] = "Görev Seviyesini Göster",
["lang_quests_optinfos"] = "TÜM İpuçlarını ve İsteğe Bağlı Bilgileri Gizle",
["lang_quests_autoshare"] = "Görevleri Otomatik Paylaş",
["lang_quests_autountrack"] = "Gizli Görevlerin İzini Otomatik Kaldır",
["lang_icon_opt"] = "Görev Simgesini Etkinleştir",
["lang_icon_texture"] = "Görev Simgesi Dokusu",
["lang_icon_size"] = "Görev Simgesi Boyutu",
["lang_icon_color"] = "Görev Simgesi Rengi",
["lang_quests_transparency_opt"] = "Odaklanmayan görevler için Şeffaflığı etkinleştirin.",
["lang_quests_transparency"] = "Odaklanmamış Görevler Şeffaflığı",
 
["lang_titles_settings"] = "Görev Adı Ayarları",
["lang_titles_font"] = "Görev Adı Yazı Tipi",
["lang_titles_style"] = "Görev Adı Yazı Tipi Stili",
["lang_titles_size"] = "Görev Adı Yazı Tipi Boyutu",
["lang_titles_padding"] = "Görev Adı Dolgu Boyutu",
["lang_titles_default"] = "Varsayılan Görev Adı Rengi",
["lang_titles_custom"] = "Özel Başlık Renkleri",
["lang_titles_veasy"] = "Çok Kolay Görevler için Görev Adı Rengi",
["lang_titles_easy"] = "Kolay Görevler için Görev Adı Rengi",
["lang_titles_normal"] = "Normal Görevler için Görev Adı Rengi",
["lang_titles_hard"] = "Zor Görevler için Görev Adı Rengi",
["lang_titles_vhard"] = "Çok Zor Görevler için Görev Adı Rengi",
 
["lang_obj_settings"] = "Hedefler/İpuçları Ayarları",
["lang_obj_font"] = "Hedefler Yazı Tipi",
["lang_obj_style"] = "Hedef Yazı Tipi Stili",
["lang_obj_size"] = "Hedeflerin Yazı Tipi Boyutu",
["lang_obj_padding"] = "Hedeflerin Dolgu Boyutu",
["lang_obj_color"] = "Hedeflerin Yazı Tipi Rengi",
["lang_obj_ccolor"] = "Tamamlanan Hedeflerin Yazı Tipi Rengi",
["lang_obj_optcolor"] = "İsteğe Bağlı Hedef Yazı Tipi Rengi",
["lang_obj_optccolor"] = "İsteğe Bağlı Hedeflerin Yazı Tipi Rengi Tamamlandı",
 
["lang_infos_settings"] = "Bilgi Ayarları",
["lang_infos_font"] = "Bilgi Yazı Tipi",
["lang_infos_style"] = "Bilgi Yazı Tipi Stili",
["lang_infos_size"] = "Bilgi Yazı Tipi Boyutu",
["lang_infos_color"] = "Bilgi Yazı Tipi Rengi",
 
["lang_NumbQuest_opt"] = "Görev sayısını göster",
["lang_NumbQuest_opt_tip"] = "Başlatılan görev sayısını ve toplam görev sayısını göster",
["lang_ShowClock_opt"] = "Saati Göster",
["lang_ShowClock_opt_tip"] = "Görev izleyicinin sol üst kısmında saati göster",
["lang_ShowTbutton_opt"] = "Odaklanmış görev tuş atama simgesini göster",
["lang_ShowTbutton_opt_tip"] = "Odaklanmış görevi değiştirmek için tuş atamalı simgeyi göster",
["lang_ShowMQbutton_opt"] = "Odaklanmış mini görev tuş atama simgesini göster",
["lang_ShowMQbutton_opt_tip"] = "Odaklanılan mini görevi değiştirmek için tuş atamalı simgeyi göster",
 
 
 
 
-- Menü ipuçları
["lang_language_settings_tip"] = "Dilinizi ayarlayın",
["lang_preset_settings_tip"] = "Bir ön ayar seçin",
["lang_overall_transparency_tip"] = "Genel şeffaflığı değiştir",
["lang_overall_width_tip"] = "Pencere genişliğini değiştirin",
["lang_position_lock_tip"] = "Konumu Kilitle/Kilidini Aç ve fare eylemlerini etkinleştir",
["lang_backgroundcolor_opt_tip"] = "Arka plan rengini etkinleştir",
["lang_backgroundcolor_value_tip"] = "Arka plan rengini değiştir",
 
["lang_mouse_1_tip"] = "Sol tıklama için bir eylem ayarlayın",
["lang_mouse_2_tip"] = "Orta tıklama için bir eylem ayarlayın",
["lang_mouse_3_tip"] = "Sağ tıklama için bir eylem ayarlayın",
["lang_mouse_4_tip"] = "4. düğme için bir eylem ayarlayın",
["lang_mouse_5_tip"] = "5. düğme için bir eylem ayarlayın",
 
["lang_area_name_tip"] = "Görev bölgesi/kategori adının görüntülenmesini etkinleştirin.",
["lang_area_font_tip"] = "Görev için bölge/kategori yazı tipini ayarlayın.",
["lang_area_style_tip"] = "Görev için bölge/kategori için yazı tipi stilini ayarlayın",
["lang_area_size_tip"] = "Görev için bölge/kategorinin yazı tipi boyutunu değiştirin",
["lang_area_padding_tip"] = "Görevin bölgesi/kategorisi için sol ve sağ dolgu boyutunu değiştirin",
["lang_area_color_tip"] = "Görevin bölgesinin/kategorisinin rengini değiştirin",
["lang_autohidequestzone_option_tip"] = "Odaklanmış görevi takip edin ve görev için diğer bölgeleri/kategorileri gizleyin",
["lang_questzone_option_tip"] = "Odaklanan görev için mevcut bölgedeki/kategorideki görevleri göster",
["lang_quests_guild_tip"] = "Lonca görevlerini göster",
["lang_quests_mainstory_tip"] = "Ana hikaye görevlerini göster",
["lang_quests_cyrodiil_tip"] = "Cyrodiil görevlerini göster",
 
["lang_quests_sort_tip"] = "Görevlerin sırasını ayarlayın",
["lang_quests_nb_tip"] = "Odaklanan görevle aynı bölge için görüntülenen görev sayısını değiştirin",
["lang_quests_show_quest_timer_tip"] = "Süreli görevler için zamanlayıcıyı göster",
["lang_quests_level_tip"] = "Görev seviyesini göster",
["lang_quests_optinfos_tip"] = "Odaklanmış görev dahil tüm görevler için gizli bilgileri/ipuçlarını gizle.",
["lang_quests_autoshare_tip"] = "Gruptayken otomatik görev paylaşımını etkinleştirin",
["lang_quests_autountrack_tip"] = "Pusuladaki tüm gizli görevlerin izini kaldır",
["lang_icon_opt_tip"] = "Görev simgesini etkinleştirin",
["lang_icon_texture_tip"] = "Geçerli yardımlı görevin simgesini ayarlayın",
["lang_icon_size_tip"] = "Simge boyutunu değiştirin",
["lang_icon_color_tip"] = "Görev simgesinin rengini değiştirin",
["lang_quests_transparency_opt_tip"] = "Odaklanan görev dışındaki diğer görevler için şeffaflığı etkinleştirin",
["lang_quests_transparency_tip"] = "Odaklanmayan görevlerin şeffaflığını değiştirin.",
 
["lang_titles_font_tip"] = "Görev adları için yazı tipini ayarlayın",
["lang_titles_style_tip"] = "Görev adlarının yazı tipi stilini ayarlayın",
["lang_titles_size_tip"] = "Görev adlarının yazı tipi boyutunu değiştirin",
["lang_titles_padding_tip"] = "Görev adları için sol ve sağ dolgu boyutunu değiştirin",
["lang_titles_default_tip"] = "Görev adlarının rengini değiştirin",
["lang_titles_custom_tip"] = "Oyuncu seviyesinden renk değiştirmeyi etkinleştir",
["lang_titles_veasy_tip"] = "Görev adlarının rengini < seviye - 4 olarak değiştirin",
["lang_titles_easy_tip"] = "Görev adlarının rengini değiştirin <= seviye - 2",
["lang_titles_normal_tip"] = "Görev adlarının rengini değiştirin = seviye +- 1",
["lang_titles_hard_tip"] = "Görev adlarının rengini değiştirin >= seviye + 2",
["lang_titles_vhard_tip"] = "Görev adlarının rengini değiştirin > seviye + 4",
 
["lang_obj_font_tip"] = "Görev metni için yazı tipini ayarlayın",
["lang_obj_style_tip"] = "Yazı tipi stilini kuyrukta ayarlayınst metin",
["lang_obj_size_tip"] = "Görev metninin yazı tipi boyutunu değiştirin",
["lang_obj_padding_tip"] = "Görev metni için sol ve sağ dolgu boyutunu değiştirin",
["lang_obj_color_tip"] = "Görev metninin rengini değiştir",
["lang_obj_ccolor_tip"] = "Tamamlanan hedefler metninin rengini değiştirin",
["lang_obj_optcolor_tip"] = "İsteğe bağlı görev metninin rengini değiştirin",
["lang_obj_optccolor_tip"] = "Tamamlanan isteğe bağlı hedefler metninin rengini değiştirin",
 
["lang_infos_opt_tip"] = "Geçerli görevlerin toplamını görüntüle",
["lang_infos_font_tip"] = "Bilgiler için yazı tipini ayarlayın",
["lang_infos_style_tip"] = "Bilgiler için yazı tipi stilini ayarlayın",
["lang_infos_size_tip"] = "Bilgiler için yazı tipi boyutunu değiştirin",
["lang_infos_color_tip"] = "Bilgilerin yazı tipi rengini değiştirin",
 
-- Menü Uyarısı
["lang_menu_warn_1"] = "|c8B1E1E Bu seçeneği değiştirmek kullanıcı arayüzünü yeniden yükleyecektir",
["lang_menu_warn_2"] = "|c8B1E1E Bu seçeneği değiştirmek kullanıcı arayüzünü yeniden yükleyecek ve mevcut ayarlarınızın üzerine yazacaktır",
 
 
-- Fare Etkileşimleri
["lang_mouse_ctrl_assisted"] = "Yardımlı Görevi Değiştir",
["lang_mouse_ctrl_filterzone"] = "Geçerli Bölgeye Göre Filtrele",
["lang_mouse_ctrl_share"] = "Bir Görevi Paylaşın",
["lang_mouse_ctrl_showmap"] = "Haritada Göster",
["lang_mouse_ctrl_remove"] = "Görevi Kaldır",
 
-- Konsol
["lang_console_autoshare"] = "Bir görevi otomatik olarak paylaşırsınız",
["lang_console_share"] = "Bir görevi paylaşıyorsunuz",
["lang_console_noshare"] = "Bu görev paylaşılamaz",
["lang_console_abandon"] = "Görevi terk et",
["lang_choose"] = "Seçin: ",
 
 
 
 
 
 
 
 
 
----------------------------------- YENİ ŞEYLER
 
["lang_tmp_VEQMessage"] = "<<1>>: <<2>>",
["lang_tmp_VEQMessage_Error"] = "HATA <<1>>: <<2>>",
 
 
-- Görev Bilgileri
["quest_opsiyonel"] = "İsteğe bağlı",
["quest_hint"] = "İpucu",
["quest_hiddenhint"] = "Gizli İpucu",
 
["lang_tracker_type_guild"] = "Lonca",
["lang_tracker_type_mainstory"] = "Ana Hikaye Görevi",
["lang_tracker_type_undaunted"] = "Korkusuz",
["lang_tracker_type_prologue"] = "Giriş",
["lang_tracker_type_companion"] = "Yardımcı",
["lang_tracker_type_repeatable"] = "RPT",
["lang_tracker_type_daily"] = "Günlük",
["lang_tracker_type_dungeon"] = "Zindan",
["lang_tracker_type_solo"] = "Yalnız",
["lang_tracker_type_class"] = "Sınıf",
["lang_tracker_type_craft"] = "Hazırlık",
["lang_tracker_type_group"] = "Grup",
["lang_tracker_type_ava"] = "İttifak Savaşı",
["lang_tracker_type_arena"] = "Arena",
["lang_tracker_type_holiday_event"] = "Tatil Etkinliği",
["lang_tracker_type_raid"] = "Deneme",
["lang_tracker_type_bg"] = "Savaş Alanı",
["lang_tracker_type_qa_test"] = "Test",
["lang_tracker_type_dark_brotherhood"] = "Karanlık Kardeşlik",
["lang_tracker_type_thieves_guild"] = "Hırsızlar Loncası",
["lang_tracker_type_mages_guild"] = "Büyücüler Loncası",
["lang_tracker_type_fighters_guild"] = "Savaşçılar Loncası",
["lang_tracker_type_psijic_order"] = "Psijic Düzeni",
 
 
 
-- Envanter
["lang_slots_inventory"] = " Envanterde kalan yuvalar",
["lang_slot_inventory"] = " Envanterde kalan yuva",
["lang_free_space"] = "Biraz yer açın",
["lang_inventory_full"] = "Envanter dolu!",
 
-- Hazine
["lang_survey_map"] = "Anket Haritası",
["lang_treasure_map"] = "Hazine Haritası",
["lang_get_materials"] = "Malzemeleri Alın",
["lang_get_treasure"] = "Hazineyi Alın",
 
-- Gök Parçaları
["lang_skyshard"] = "Skyshard",
["lang_maway"] = "m Uzakta",
["lang_distant_sky"] = "Algılanamaz Eterik Magicka Varlığı",
["lang_weak_sky"] = "Zayıf Eterik Magicka Varlığı",
["lang_moderate_sky"] = "Orta Düzeyde Eterik Magicka Varlığı",
["lang_strong_sky"] = "Güçlü Eterik Magicka Varlığı",
["lang_huge_sky"] = "Devasa Eterik Magicka Varlığı",
 
-- Potansiyel müşteriler/eski eserler
["lang_scry_exc"] = "Tarama ve Kazma",
["lang_antiquity_"] = "Antik Çağ - ",
 
-- Yapılabilir yazılar
["lang_check_inv"] = "Hazırlığa Başlamak için burayı tıklayın",
["lang_doable"] = "Yapılabilir ",
["lang_or"] = " veya ",
 
-- Binicilik becerileri
["lang_stable_rel"] = "İstikrarlı Bir İlişki",
["lang_upgrade_skills"] = "Binicilik Becerilerinizden birini yükseltin",
["lang_stablemaster"] = "Stablemaster",
 
-- Sırt Çantası ve Banka yükseltmesi
["lang_backpack_upgrade"] = "Sırt Çantası Yükseltmesi",
["lang_you_have_the"] = "Elinizde ",
["lang_up_back"] = "g! Sırt Çantanızı Yükseltin",
["lang_pack_merchant"] = "Paket Satıcısı",
["lang_bank_space_upgrade"] = "Banka Alanı Yükseltmesi",
["lang_up_bank"] = "g! Banka Alanınızı Yükseltin",
["lang_bank_mon"] = "Bankacı veya Borç Veren",
 
-- Çaba
["lang_endeavor_week"] = "Haftalık Çalışma",
["lang_endeavor_day"] = "Günlük Çalışma",
 
-- Etkinlik Biletleri ve kristalleri dönüştürme
["lang_event_tickets"] = "Etkinlik Biletleri",
["lang_transmute_crystals"] ="Kristalleri Dönüştür",
["lang_maxed_out_currency"] = "Bu Para Biriminin Maksimum Sınırı Doldu! Harcayın.",
["lang_nears_max_currency"] = "Bu Para Birimi İzin Verilen Maksimum Değere Yakın, Harcayın.",
 
 
-- LFG ve hazır kontrolü
["lang_in"] = " in ",
["lang_champion_battleground"] = "Şampiyon Savaş Alanı",
["lang_low_battleground"] = "Düşük Seviyeli Savaş Alanı",
["lang_non_battleground"] = "Şampiyon Olmayan Savaş Alanı",
["lang_normal_dungeon_finder"] = GetString(SI_DUNGEONDIFFICULTY1).." Zindan Bulucu",
["lang_veteran_dungeon_finder"] = GetString(SI_DUNGEONDIFFICULTY2).." Zindan Bulucu",
["lang_tribute_casual"] = "Gündelik Haraç Masalları",
["lang_tribute_competitive"] = "Rekabetçi Haraç Hikayeleri",
["lang_lfg"] = "Grup aranıyor...",
["lang_lfo"] = "Rakip aranıyor...",
["lang_everybody_ready"] = "Herkes Hazır mı?",
["lang_ready"] = " hazır",
["lang_grc"] = "Grup Hazır Kontrolü",
["lang_for"] = " için ",
["lang_LFR"] = "Yenisi aranıyor",
 
-- Hikayeye giriliyor
["lang_cyrodiil"] = "Cyrodiil - ",
["lang_group"] = "Grup - ",
["lang_ewt"] = "\n• Kalan Bekleme Süresi: ",
["lang_entering_campaign"] = "Hikayeye Giriliyor...",
["lang_n_started"] = "\n• Başladı ",
["lang_ago"] = " önce",
["lang_confirming"] = "Onaylanıyor",
["lang_finished"] = "Bitti",
["lang_pending_accept"] = "Giriliyor...",
["lang_pending_join"] = "Katılmayı Bekliyor",
["lang_leaving_queue"] = "Kuyruktan Ayrılıyor",
["lang_exiting_campaign"] = "Hikayeden Çıkılıyor...",
["lang_waiting"] = "Bekliyor",
["lang_n_queue_position"] = "\n• Sıra Konumu: ",
 
    -- Zehir denetleyicisi / bildirimcisi
["lang_out_of_poison"] = "Zehir Bitti!",
["lang_craft_some_poison"] = "Bir miktar Zehir üretin veya satın alın ve onu Silahınıza uygulayın",
["lang_alchemy_station"] = "Kimya İstasyonu",
 
    -- Psijic Zaman İhlalleri yardımcısı
    ["lang_psijic_time_breach"] = "Psijic Zaman İhlali #",
["lang_6172_helper_9"] = "Augury Havzası ile Keelsplitter Yuvası'nın ortasında (Ebon Stadmont yol tapınağından batıya gidin, gölete atlayın ve nehri takip edin, yarık şelalenin dibindedir)",
["lang_6172_helper_8"] = "Keelsplitter Yuvası ile Rellenthil Abyssal Gayzeri arasında, ağaçlı küçük adada (Ebon Stadmont yol tapınağının güneyinde)",
["lang_6172_helper_7"] = "Alinor'un batısındaki yıkık bir yapıda, Welenkin Koyu ile Welenkin Abyssal Gayzeri'nin ortasında (Cey-Tarn Kalesi yol tapınağının güneyindeki arnavut kaldırımlı yoldan aşağı gidin, yapıya giden kırık köprü de dahil olmak üzere her çataldan sağdan ilerleyin) )",
["lang_6172_helper_6"] = "Direnni Akropolü içinde, köprüden sonrae (King's Haven Geçidi yol tapınağından güneydoğuya doğru arnavut kaldırımlı yoldan aşağı gidin, yol ayrımından soldan devam edin)",
["lang_6172_helper_5"] = "Shimmerene'nin batısındaki şelalenin altında (Shimmerene yol tapınağından Kuzeye doğru dörtnala gidin ve mümkün olan en uzağa suya atlayın)",
["lang_6172_helper_4"] = "Tepedeki harabelerde, Gölün kuzeyinde, Archon Korusu'nun yanında, Onbir Kuvvet Kalesi'nin doğusunda (Pırıltılı yol tapınağından güneye gidin)",
["lang_6172_helper_3"] = "Sil-Var-Woad'daki muhafazalardan birinde (Sil-Var-Woad yol tapınağından güneye gidin, hayvanat bahçesine girin, su muhafazasındaki çatalın sağından ilerleyin)",
["lang_6172_helper_2"] = "Sil-Var-Woad'ın güneydoğusundaki adanın doğu kıyısında, Sil-Var-Woad Abisal Gayzerinin güneydoğusunda, en kuzeydeki iki küçük adanın yakınında",
["lang_6172_helper_1"] = "Sunhold Wayshrine'ın güneyinde, Sunhold Abisal Gayzerinin Batısında",
 
 
["lang_6181_helper_9"] = "Daenia Dolmen'in kuzeyinde, Deleyn Değirmeni'ne bakan bir uçurumun üzerinde (Baelborne Kayası yol tapınağından güneye ilerleyin, nehirde koşun, köprünün altından geçin, sonra güneydoğuya doğru ilerleyin, gedik resim şövalesinden biraz daha uzaktadır) ",
["lang_6181_helper_8"] = "Beldama Wyrd Ağacı'nın (Wyrd Ağacı yol tapınağı) Kuzey tarafındaki köklerin arasında",
["lang_6181_helper_7"] = "Mezar Höyüklerinin Batı yakasındaki bir kayalıkta (Crosswych yol tapınağından güneybatıya, devasa kötü ota kadar ilerleyin ve ardından kayalığın tepesinden güney-güneydoğuya ilerleyin)",
["lang_6181_helper_6"] = "Koeglin Deniz Feneri adasının Batı yakasındaki bir gemi enkazının en güney kısmında (Bonesnap Harabeleri yol tapınağından Batı-güneybatıya gidin)",
["lang_6181_helper_5"] = "Cumberland Şelaleleri'nin en yüksek kademesinin kenarında (Rüzgar Kalesi yol tapınağından batıya gidin, şelaleye kadar nehri takip edin ve tepesine tırmanın)",
["lang_6181_helper_4"] = "Ayışığı Maw'ın hemen batısı (Pariah Manastırı yol tapınağından kuzeye gidin)",
["lang_6181_helper_3"] = "Salas En'in kuzeyindeki bir uçurumun kenarında, The Warrior'ın kuzeydoğusunda, Rain Catcher Fields'a bakan (Morwha's Bounty yol tapınağından batıya gidin, tırmanın, tekrar batıya uçurumun kenarına gidin)",
["lang_6181_helper_2"] = "Easterly Aerie'nin batısındaki bir uçurum duvarının karşısında (Kulati Madenleri yol tapınağından batıya gidin, kayayı sağa doğru çevirin, köprüye girin, daha yüksek platforma tırmanmak için sola gidin)",
["lang_6181_helper_1"] = "HoonDing's Watch ile Ragnthar arasında (HoonDing's Watch yol tapınağından güneye gidin, mümkün olduğunda solunuzdaki kuma tırmanın, tekrar güneye gidin)",
 
 
["lang_6185_helper_9"] = "Senie'nin Batı yakasındaki en güneydeki iki lav akıntısı arasında (Senie yol tapınağından batıya gidin)",
    ["lang_6185_helper_8"] = "Brothers of Strife ile Armature's Upheaval arasındaki Şelalenin tepesindeki küçük bir adada (Brothers of Strife yol tapınağından güneybatıya gidin)",
    ["lang_6185_helper_7"] = "Kükürt Havuzları yol tapınağı ile Vivec Boynuzları arasındaki Vivec Boynuzları üzerindeki sırtın tepesinde (Kükürt Havuzları yol tapınağından Doğuya gidin)",
    ["lang_6185_helper_6"] = "Wittestadr'daki daha büyük buhar havuzlarından birinin yanında (Wittestadr yol tapınağından kuzeydoğuya gidin, gedik tam olarak haritadaki Wittestadr simgesinin üzerindedir)",
    ["lang_6185_helper_5"] = "Nehrin yukarısındaki iki Şelale arasında Darkwater Geçidi'nin güneybatısında, Fort Amol haritasının güneydoğusunda (Fort Amol yol tapınağından güneydoğuya gidin)",
    ["lang_6185_helper_4"] = "Nehrin batısında, Cradlecrush'un doğusundaki köprü, Thane Jeggi İçme Deliği'nin kuzeybatısında (Fort Morvunskar yol tapınağından güneybatıya gidin ve arnavut kaldırımlı yolu takip edin, çataldan sola dönün, sağınıza köprüye bakın) ",
    ["lang_6185_helper_3"] = "Fort Greenwall'un kuzeydoğusunda, Troll Mağarasının güneybatısında (Riften yol tapınağından Kuzey Kalesi Greenwall'a gidin vetavuk Kuzeydoğu)",
    ["lang_6185_helper_2"] = "Snapleg Mağarası'nın hemen dışında (Nimalten yol tapınağının kuzeyindeki köprüyü geçin ve nehir boyunca mağaraya doğru devam edin)",
    ["lang_6185_helper_1"] = "Ivarstead'in Kuzeybatısında, Dünya Boğazı yakınındaki merdivenlerin tepesinde (Geirmund's Hall yol tapınağından batı-güneybatıya gidin, köprüyü geçin ve çok sayıda basamağı takip edin)",
 
 
    ["lang_6197_helper_adamantine"] = "Doğu Evermore yol tapınağından güneybatıya gidin, Pelin Mezarlığı'ndaki Zaman İhlalini kullanın, Psijic görüşünü takip edin, asa parçasını kazın",
["lang_6197_helper_orichalc"] = "Leki's Blade yol tapınağının güneybatısına gidin, Leki's Blade'in kuzeyindeki Zaman Aşımını kullanın, Psijic görüşünü takip edin, asa parçasını kazın",
["lang_6197_helper_crystal"] = "Kuluçka Havuzları yol tapınağının kuzeyine gidin, Kuluçka Havuzlarındaki Zaman İhlalini kullanın (Büyük Hist Ağacının altında), Psijic görüşünü takip edin, asa parçasını kazın",
["lang_6197_helper_walk"] = "Selfora yol tapınağından güneye gidin, Fang Kuleleri yakınındaki Zaman İhlalini kullanın, Psijic görüşünü takip edin, asa parçasını kazın",
 
["lang_6197_helper_pelin"] = "Pelin Mezarlığı Yakınındaki Asa Parçası",
["lang_6197_helper_leki"] = "Leki'nin Kılıcının Yanında Asa Parçası",
["lang_6197_helper_hist"] = "Hist'e Yakın Asa Parçası",
["lang_6197_helper_fang"] = "Fang Kuleleri yakınındaki Asa Parçası",
 
 
["lang_6194_helper_9"] = "Telacar Kemikliği'nin Batı yakasındaki yıkık bir yapıda (Ossuary yol tapınağından kuzey-kuzeybatıya gidin)",
["lang_6194_helper_8"] = "Gil-Var-Delle kütüğü içinde, Dolmen'in batısında (Gil-Var-Delle yol tapınağından güneye gidin)",
["lang_6194_helper_7"] = "En yüksek kule harabesinin içinde, Reman Kayalıklarının Kuzeyi (Redfur Ticaret Merkezi yol tapınağından Batı-güneybatıya gidin)",
["lang_6194_helper_6"] = "Maormer Kampı'nın kuzeyindeki bir burunda (Moonhenge yol tapınağının kuzey-kuzeybatısındaki köprüyü geçin, arnavut kaldırımlı yolu takip edin, yol sağa döndüğünde uçurumun kenarına doğru düz ilerleyin)",
["lang_6194_helper_5"] = "Balıkçı Yeri'nin Kuzeyi (Yılan Mağarası yol tapınağından dağı Batı tarafından çevreleyin)",
["lang_6194_helper_4"] = "Labirentin içinde, merkezin hemen kuzeyinde (Greenheart yol tapınağından Kuzeydeki köprüyü kullanın, yolu takip etmeden düz devam edin, tekrar ayaklarınızın altına geldiğinde onu takip edin, önünüzdeki 1. Labirent girişini kullanın) sola gidin, 1. yol ayrımından sağa gidin ve 2. yol ayrımından sola gidin)",
["lang_6194_helper_3"] = "Ragnthar'ın batısında, Treehenge'in güneyinde bir köprünün altında (Köprüye ulaşana kadar Wilding Run yol tapınağının kuzeyindeki yolu takip edin, atlayın)",
["lang_6194_helper_2"] = "Horseshoe Adası'nın ortasında (Vulkwasten yol tapınağından kuzeye gidin)",
["lang_6194_helper_1"] = "Xylo Nehri Havzası Dolmen'in kuzeydoğusundaki adada (Abamath yol tapınağından kuzeye gidin)",
 
["lang_6190_helper_9"] = "Bthanual'ın güneyindeki uçurumda (Muth Gnaar Tepeleri yol tapınağından doğuya giden yolu takip edin, köprüyü geçin, çataldan soldan devam edin, Bthanual girişinden önce güneye gidin)",
["lang_6190_helper_8"] = "Darkshade Mağaraları'nın kuzeydoğusundaki şelalenin yanında (Sessiz Mire yol tapınağından güneybatıya gidin, kayaya daha yüksek platforma tırmanın)",
["lang_6190_helper_7"] = "Saint Veloth Tapınağı'nın ortasındaki bir ekicide (Eidolon'un Hollow yol tapınağından kuzeybatı yolunu takip edin, 1. çataldan sola ve 2. çataldan sağa devam edin)",
["lang_6190_helper_6"] = "Triple Circle Madeninin kuzeydoğusundaki şelalelerin yanındaki küçük bir adada (Shad Astula yol tapınağından güneye gidin, yüzün, şelaleden aşağı atlayın, yüzün)",
["lang_6190_helper_5"] = "Malak's Maw'ın dev kapılarının arkasında (Batı Narsis yol tapınağından batıya gidin ve saat yönünde tam bir tur atın)",
["lang_6190_helper_4"] = "Bir ağacın ro altındaBogmother'ın güneybatı köşesinde (Bogmother yol tapınağından Batıya Git)",
["lang_6190_helper_3"] = "Batı Hei-Halai'de, Mazzatun Harabeleri girişine yakın bir taş ağzın içinde (Stilrise yol tapınağından kuzeye giden yolu takip edin, kuzeybatıya giden yolun yanında solunuzda bir kule harabesi gördüğünüzde, Daha sonra solunuzda taş ağza giden patikayı takip edin)",
["lang_6190_helper_2"] = "Zehirli Bataklık Dolmenlerinin kuzeybatısındaki küçük bir xanmeerde (Loriasel yol tapınağından güneydoğuya gidin)",
["lang_6190_helper_1"] = "Süzülmüş Çamur'un ortasındaki Hist ağacının dibinde (Süzülmüş Çamur yol tapınağından Kuzeydoğu'ya gidin)",
 
 
 
["lang_6198_helper_red"] = "Brothers of Strife yol tapınağının güneyine gidin, Zaman İhlalini kullanın, Psijic görüşünü takip edin, asa parçasını kazın",
["lang_6198_helper_white"] = "Ağlayan Dev yol tapınağından kule harabesine kadar kuzeybatıya gidin, ardından sağınızdaki yolu takip edin, tahta köprüyü geçin, Zaman İhlalini kullanın, Psijic görüşünü takip edin, asa parçasını kazın",
    ["lang_6198_helper_greensap"] = "Greenheart Wayshrine yol tapınağının kuzeyine gidin, Zaman İhlalini kullanın, Psijic görüşünü takip edin, asa parçasını kazın",
    ["lang_6198_helper_snow"] = "Spelscar yol tapınağından doğuya gidin, kayalık uçurum ile Adament Anomalisi arasında, kayalık uçurumun sonunda sola dönün, Zaman İhlalini kullanın, Psijic görüşünü takip edin, asa parçasını kazın",
 
["lang_6198_helper_bro"] = "Nefret Kardeşlerinin Yanındaki Asa Parçası",
["lang_6198_helper_weep"] = "Ağlayan Dev'in Yanında Asa Parçası",
["lang_6198_helper_green"] = "Greenheart yakınındaki Personel Parçası",
["lang_6198_helper_spell"] = "Spellscar yakınındaki Asa Parçası",
 
 
["lang_6468_helper_9"] = "Trader's Rest'in batısındaki duvarda (Oldgate yol tapınağından kuzeydoğuya gidin)",
    ["lang_6468_helper_8"] = "Sanguine Barrows'ta, merkezi mezar ile Tribulation Crypt arasında (Sanguine Barrows yol tapınağından kuzeye gidin)",
    ["lang_6468_helper_7"] = "Lorkrata Tepeleri'ndeki Kuzey kulesinin önünde (Fell's Run yol tapınağından batıya gidin, Lorkrata Tepeleri duvarlarına girdikten sonra sağınızdaki merdivenleri kullanın)",
    ["lang_6468_helper_6"] = "Edrald Malikanesi'ndeki bir tarlada (Fell's Run wayshrine'dan doğu-güneydoğuya gidin)",
    ["lang_6468_helper_5"] = "Doğu Kaya Çıkarma Bölgesi'nin batısında, Ork Parmak Harabeleri'nin kuzeyinde, Yılan'ın güneybatısındaki bir adada (Borali yol tapınağından doğuya gidin)",
["lang_6468_helper_4"] = "Lagra'nın İncisi'nin kaptan kabininde (Northpoint yol tapınağından kuzeydoğuya gidin)",
["lang_6468_helper_3"] = "Crestshade'deki Şapel Mezarlarının önünde (Crestshade yol tapınağından güneye giden arnavut kaldırımlı yolu takip edin, heykele gelin, güneybatıya gidin ve merdivenlerden yukarı çıkın, soldaki diğer merdiven dizisi, düz devam edin) Şapel Kriptlerinin merdivenlerine kadar)",
["lang_6468_helper_2"] = "Aesar Ağı'nın hemen batısında (Tarrith Kampı yol tapınağının batısına gidin)",
["lang_6468_helper_1"] = "Gölge Kaderi Mağarası İçinde (Giriş, Aesar'ın Ağı ile Tamrith Kampı yol tapınağı arasındadır)",
 
 
["lang_6196_helper_6"] = "Ogondar Şaraphanesi'nin kuzeydoğusunda, Rkundzelft'in batısında (Spelscar yol tapınağından doğuya gidin, kayalık uçurum ile Adament Anomalisi arasında, kayalık uçurumun sonunda Güneydoğu'ya gidin)",
["lang_6196_helper_5"] = "Elinhir'in Kuzeybatı köşesinin dışında (Elinhir yol tapınağından güneye gidin, gediği bulana kadar Elinhir kaya uçurumunu sağdan çevreleyin)",
["lang_6196_helper_4"] = "Scorpion Geçidi'nin güney ucundaki bir yarıkta (Arayıcı Arşivi yol tapınağından güneybatıya gidin)",
["lang_6196_helper_3"] = "Hel Ra Kalesi'nin kuzeyi, Mtharnaz'ın doğusu (Sandy Path yol tapınağından batıya gidin)",
["lang_6196_helper_2"] = "Dragonstar Arena'nın (Dragonstar yol tapınağı) önünde",
["lang_6196_helper_1"] ="Skyreach Hold'a (Skyreach wayshrine) giden köprüde",
 
["lang_6199_helper"] = "Goat's Head Oasis yol tapınağından merdivenleri çıkın ve güneybatıya, Divad'ın Chagrin madenine gidin",
 
 
-- Çerçeveleri gruplandırma
["lang_of"] = " / ",
 
-- Müze Parçaları
["lang_museum"] = "Aranan",
 
-- Günlük sayaç
["lang_repeatable_quests"] = "Tekrarlanabilir Görevler",
["lang_ongoing"] = "Devam ediyor: ",
["lang_completed_today"] = "Bugün Tamamlandı: ",

	-- zone todo list
	["lang_todolist"] ="Zone to-do list",
	
	
	-- remains silent
	["lang_remains_silent"] = "<You nod knowingly.>",
	
	-- Dragonguard Supply chest name (change to your language for the feature to work)
	["lang_dragonguard_supply_chest"] = "Dragonguard Supply Chest",
 
-- mini izleyici ayarları
["lang_mini_quest_tracker_settings"] = "Mini Görev Takipçi Ayarları",
	["lang_mini_quest_tracker_invert_opt"] = "Invert key",
	["lang_mini_quest_tracker_invert_tip"] = "Get previous Mini quest instead of next by long pressing that key while presing the default keybind",
["lang_inventory_slots_opt"] = "Envanter Yuvalarını Boşalt Mini Görev",
["lang_inventory_slots_tip"] = "Ayarladığınız minimum boş yuva sınırına ulaştığında envanterinizi boşaltmaya yönelik mini bir görev",
["lang_inventory_slots_limit"] = "Ücretsiz envanter yuvaları tetikleyicisi",
["lang_inventory_slots_limit_tip"] = "Mini görevi tetikleyen minimum ücretsiz envanter yuvası sayısı",
["lang_lost_treasure_opt"] = "Kayıp Hazine Mini Görevi",
["lang_lost_treasure_tip"] = "Çantanıza girer girmez hazine haritaları ve araştırma konumları için mini bir görev ekler (Lost Treasure eklentisi ile mükemmel)",
["lang_skyshards_opt"] = "Skyshards Mini Görevi",
["lang_skyshards_tip"] = "100 metreden daha yakınsa gökyüzü parçası almak için mini bir görev ekler",
    ["lang_leads_opt"] = "Mini Göreve Liderlik Ediyor",
["lang_leads_tip"] = "Sahip olduğunuz her ipucu için antik çağları araştırmak ve kazmak için mini bir görev ekler",
	["lang_fake_leads_opt"] = "Scrying and Excavating progression",
	["lang_fake_leads_tip"] = "Daily adds a mini quest to go scrying and excavating an antiquity for a smooth progression of these skill lines",
["lang_writs_opt"] = "Doable Mini Görevi Yazıyor",
["lang_writs_tip"] = "Envanterinizdeki her Doable Writ (bilgiye sahip + matlara sahip) için bir mini görev ekler. (Çalışması için WritWorthy eklentisinin kurulu olması gerekir)",
["lang_stable_opt"] = "Binicilik Becerilerini Yükseltme Mini Görevi",
["lang_stable_tip"] = "Koşulları karşıladığınız anda sürüş becerilerinizi geliştirmek için mini bir görev ekler",
["lang_backbank_opt"] = "Sırt Çantası ve Banka Yükseltme Mini Görevi",
["lang_backbank_tip"] = "Gerekli altını topladığınız anda sırt çantanızı veya banka alanınızı yükseltmek için mini bir görev ekler",
["lang_endeavor_opt"] = "Günlük ve Haftalık Endeavor Mini Görevi",
["lang_endeavor_tip"] = "Her günlük ve haftalık çabayı mini bir görev olarak ekler.",
	["lang_goldenPursuit_opt"] = "Golden Pursuit Mini Quest",
	["lang_goldenPursuit_tip"] = "Adds each Golden Pursuit as a mini quest.",
		["lang_communityEvents_opt"] = "Community Event Mini Quest",
	["lang_communityEvents_tip"] = "Adds each Community Event as a mini quest.",
["lang_tickets_opt"] = "Etkinlik Biletlerini Mini Görev Harcayın",
["lang_tickets_tip"] = "Etkinlik Biletlerinizi, ayarladığınız minimum sol limit sınırına ulaştığında harcamak için mini bir görev",
["lang_tickets_limit"] = "En üst sınıra kadar kalan Minimum Etkinlik Bileti Sayısı",
["lang_tickets_limit_tip"] = "Mini görevi tetikleyen, sınıra kadar kalan minimum Etkinlik Bileti sayısı",
["lang_transmute_opt"] = "Dönüştürme Kristalleri Mini Görevini Harcayın",
["lang_transmute_tip"] = "Dönüştürme Kristallerinizi, ayarladığınız minimum sol sınır sınırına ulaştığında harcamak için mini bir görev",
["lang_transmute_limit"] = "Tetikleyiciyi sınırlamak için bırakılan Minimum Dönüştürme Kristalleri",
["lang_transmute_limit_tip"] = "Mini görevi tetikleyen, sınıra kadar kalan minimum Dönüştürme Kristallerinin sayısı",
    ["lang_zoneguide_opt"] = "Sonraki Bölge Rehberi görevini Mini Görev olarak ayarla",
["lang_zoneguide_tip"] = "Bölge rehberi mini görevleri otomatik olarak etkinleştirilir ve VEQ'da bölge değiştiğinde ve o bölgede aktif bir göreviniz yoksa mini bir göreve dönüşür",
    ["lang_POIcompletion_opt"] = "Set undiscovered zone Points of interest as a Mini Quest",
	["lang_POIcompletion_tip"] = "One Undiscovered zone Point of interest becomes a mini quest in VEQ on zone change",
    ["lang_poison_opt"] = "Zehir Denetleyicisi",
["lang_poison_tip"] = "Her dövüşten sonra silahınızın zehir yuvalarını kontrol eder, zehiriniz bittiyse zehir üretmeye yönelik bir mini görev görüntülenir",
["lang_group_frames_opt"] = "Yoldaşların ve Grup üyelerinin yaşam çubuğu olarak adları",
["lang_group_frames_tip"] = "Grup üyelerinin adlarını renkli yaşam çubukları olarak görüntüler",
["lang_default_group_frames_opt"] = "Oyunun varsayılan grup çerçevelerini gizle",
["lang_default_group_frames_tip"] = "Başka bir anahtarla çakışması durumunda bu anahtarı değiştirin varsayılan grup çerçeveleri görünümüne ilişkin eklenti",
["lang_museum_pieces_opt"] = "Müze Parçaları Mini görevi",
["lang_museum_pieces_tip"] = "Envanterinizdeki her müze parçasını müzeye geri getirmek için mini bir görev ekler",
["lang_dailies_counter_opt"] = "Günlük Görev Sayacı",
["lang_dailies_counter_tip"] = "Gün başına 50 günlük görevi ve karakter sınırını takip etmek için bir sayaç ekler",
["lang_NumbMiniQuest_opt"] = "Mini görevlerin sayısını göster",
["lang_NumbMiniQuest_opt_tip"] = "Mini görevlerin sayısını göster",
 
}