If you want to translate the addon to your language, make a copy of the en.lua file in the Langs folder

(if your language file already exist and is marked INCOMPLETE, get the missing lines from en.lua and translate them)

rename it to fr.lua for french, ru.lua for russian etc, translate the text (after the = sign only for each line),
test it, send me a https://justpaste.it/ link type in the comments (link below) so I can add your translation in the next update.

https://www.esoui.com/downloads/info3228-VestigesEpicQuest.html#comments

You can also add me on discord for easier contact & share files : Masteroshi430#2305