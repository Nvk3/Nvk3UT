-- Traduction française par XXXspartiateXXX

VEQ.mylanguage = {
	-- Menu
	["lang_quests_category_view_settings"] = "Paramètres pour l'affichage de la zone de catégorie",
	["lang_class_show_zone"] = "Afficher la zone dans l'affichage de zone de la catégorie Classe",
	["lang_class_show_zone_tip"] = "Lorsque vous utilisez l'affichage de zone de la catégorie, cela affiche la zone des quêtes de classe.",
	["lang_craft_show_zone"] = "Afficher la zone dans l'affichage de zone de la catégorie Métier",
	["lang_craft_show_zone_tip"] = "Lorsque vous utilisez l'affichage de zone de la catégorie, cela affiche la zone des quêtes d'artisanat.",
	["lang_Group_show_zone"] = "Afficher la zone dans l'affichage de zone de la catégorie Groupe",
	["lang_Group_show_zone_tip"] = "Lorsque vous utilisez l'affichage de zone de la catégorie, cela affiche la zone des quêtes de groupe.",
	["lang_Dungeon_show_zone"] = "Afficher la zone dans l'affichage de zone de la catégorie Donjon",
	["lang_Dungeon_show_zone_tip"] = "Lorsque vous utilisez l'affichage de zone de la catégorie, cela affiche la zone des quêtes de donjon.",
	["lang_Raid_show_zone"] = "Afficher la zone dans l'affichage de la zone de la catégorie Raid",
	["lang_Raid_show_zone_tip"] = "Lorsque vous utilisez l'affichage de zone de la catégorie, cela affiche la zone des quêtes de raid.",
	["lang_HideOptObjective"] = "Masquer les objectifs optionnels",
	["lang_HideOptObjective_tip"] = "Masque les objectifs optionnels des quêtes.",
	["lang_HideOptionalInfo"] = "Masquer les informations optionnels",
	["lang_HideOptionalInfo_tip"] = "Masque les informations optionnels de la quête.",
	["lang_HideHintsOption"] = "Masquer les indices de quête",
	["lang_HideHintsOption_tip"] = "Masque les indices pour la quête.",
	["lang_HideHiddenOptions"] = "Masquer les indices de quête cachés",
	["lang_HideHiddenOptions_tip"] = "Masque les indices de quête cachés.",
	["lang_HintColor"] = "Couleur de l'indice de quête",
	["lang_HintColor_tip"] = "Couleur des indices pour la quête.",
	["lang_HintCompleteColor"] = "Couleur des indices de quête terminée",
	["lang_HintCompleteColor_tip"] = "Couleur des indices de la quête terminée.",
	["lang_HideInCombat"] = "Masquer le suivi en combat",
	["lang_HideInCombat_tip"] = "Masque le suivi de quête en combat.",
	["lang_QuestObjIcon"] = "Afficher les icônes d'étape de quête",
	["lang_QuestObjIcon_tip"] = "Affiche les icônes d'étape de quête au lieu des symboles textuels.",
	["lang_HideObjOption"] = "Masquer les objectifs pour toutes les quêtes SAUF",
	["lang_HideObjOption_tip"] = "Option pour masquer tous les objectifs à l'exception des trois options. Désactivé ignorera cette option, la quête suivie masquera tous les objectifs sauf la quête suivie, la zone suivie masquera tous les objectifs sauf la zone dans laquelle se trouve la quête suivie.",
	["lang_Miscellaneous"] = "Divers",
	["lang_Toggle_AutoHide_off"] = "Masquer automatiquement la zone/catégorie sur Désactivé",
	["lang_Toggle_AutoHide_on"] = "Masquer automatiquement la zone/catégorie sur Activé",
	["lang_Collaspe_All_Zones"] = "Réduire toutes les zones/catégories",
	["lang_Expand_All_Zones"] = "Développer toutes les zones/catégories",
	["lang_Toggle_Category_off"] = "Passer à l'affichage des zones",
	["lang_Toggle_Category_on"] = "Passer à l'affichage des catégories",
	["lang_Toggle_NotFocusTrans_on"] = "Transparence non suivie déterminée sur Activé",
	["lang_Toggle_NotFocusTrans_off"] = "Transparence non suivie déterminée sur Désactivé",
	["lang_Toggle_HintsHidden_on"] = "Masquer les indices et indices cachés sur Activé",
	["lang_Toggle_HintsHidden_off"] = "Masquer les indices et indices cachés sur Désactivé",
	["lang_Toggle_HideObjOption_Disabled"] = "Objectifs activés pour toutes les quêtes",
	["lang_Toggle_HideObjOption_FocusedQuest"] = "Objectifs activés pour la quête suivie uniquement",
	["lang_Toggle_HideObjOption_FocusedZone"] = "Objectifs activés pour les quêtes de zone suivies",

	

	
	["lang_Chat_AddonMessages"] = "Activer les messages de Tchat pour l'addon",
	["lang_Chat_AddonMessages_tip"] = "Active les messages de Tchat, les messages de l'addon concernant les modifications apportées par les raccourcis clavier, les erreurs, etc.",
	["lang_Chat_QuestInfo"] = "Activer les messages de Tchat pour les informations de quête",
	["lang_Chat_QuestInfo_tip"] = "Activer les messages de Tchat pour les informations sur la quête.",
	["lang_chat_settings"] = "Paramètres de Tchat",
	["lang_Chat_AddonMessage_HeaderColor"] = "Couleur de l'en-tête de messagerie",
	["lang_Chat_AddonMessage_HeaderColor_tip"] = "Détermine la couleur de l'en-tête pour la messagerie de l'addon.",
	["lang_Chat_AddonMessage_MsgColor"] = "Couleur du message de messagerie",
	["lang_Chat_AddonMessage_MsgColor_tip"] = "Détermine la couleur du message pour la messagerie de l'addon.",
	["lang_Chat_QuestInfo_HeaderColor"] = "Couleur de l'en-tête des informations de quête",
	["lang_Chat_QuestInfo_HeaderColor_tip"] = "Détermine la couleur de l'en-tête pour la messagerie de l'addon.",
	["lang_Chat_QuestInfo_MsgColor"] = "Couleur du message d'information de quête",
	["lang_Chat_QuestInfo_MsgColor_tip"] = "Détermine la couleur du message pour les informations sur la quête.",
	

	
	["lang_quests_timer_settings"] = "Paramètres de la minuterie de quête",
	["lang_quests_timer_settings_Tip"] = "Active/Désactive la minuterie de quête et détermine les polices et les couleurs.",
	["lang_veq_settings"] = "Vestige's Epic Quest",
	["lang_global_settings"] = "Paramètres globaux",
	
	["lang_language_settings"] = "Langue",
	["lang_preset_settings"] = "Préréglé",
	["lang_quests_filtered_settings"] = "Afficher les types de quête",
	["lang_overall_transparency"] = "Transparence globale",
	["lang_overall_width"] = "Largeur hors tout",
	["lang_position_lock"] = "Verrouiller la position d'arrière-plan",
	["lang_backgroundcolor_opt"] = "Activer la couleur d'arrière-plan",
	["lang_backgroundcolor_value"] = "Couleur de l'arrière plan",
    ["lang_intelligent_background"] = "Intelligent Background",
	["lang_intelligent_background_tip"] = "The Intelligent Background fades out when you are moving or in combat and fades in when you are not",

	["lang_mouse_settings"] = "Paramètres des commandes de la souris",
	["lang_mouse_1"] = "Bouton gauche de la souris",
	["lang_mouse_2"] = "Bouton de la molette",
	["lang_mouse_3"] = "Bouton droit de la souris",
	["lang_mouse_4"] = "Bouton de la souris 4",
	["lang_mouse_5"] = "Bouton de la souris 5",

	["lang_timer_title_font"] = "Police de la minuterie",
	["lang_timer_title_font_tip"] = "Police pour la minuterie de quête affichée sur les quêtes suivies qui ont un chronomètre.",
	["lang_timer_title_style"] = "Style de la police de la minuterie",
	["lang_timer_title_style_tip"] = "Style de la police utilisée sur la minuterie de quête affichée sur les quêtes suivies qui ont un chronomètre.",
	["lang_timer_title_size"] = "Taille de la police de la minuterie",
	["lang_timer_title_size_tip"] = "Taille de la police pour la minuterie de quête affiché sur les quêtes suivies qui ont un chronomètre.",
	["lang_timer_title_color"] = "Couleur de la police de la minuterie",
	["lang_timer_title_color_tip"] = "Couleur de la police pour la minuterie de quête affichée sur les quêtes suivies qui ont un chronomètre.",
	
	["lang_area_settings"] = "Paramètres des quêtes de zones",
	["lang_area_name"] = "Afficher le nom de la zone/catégorie",
	["lang_area_font"] = "Police de la zone/catégorie",
	["lang_area_style"] = "Style de la police de la zone/catégorie",
	["lang_area_size"] = "Taille de la police de la zone/catégorie",
	["lang_area_padding"] = "Taille de remplissage de la zone/catégorie",
	["lang_area_color"] = "Couleur de la zone/catégorie",
	["lang_autohidequestzone_option"] = "Activer le masquage de zone automatique",
	["lang_questzone_option"] = "Afficher les quêtes dans la zone uniquement",
	["lang_quests_guild"] = "Afficher les quêtes des guildes",
	["lang_quests_mainstory"] = "Afficher les quêtes de l'histoire principale",
	["lang_quests_cyrodiil"] = "Afficher les quêtes de Cyrodiil",

	["lang_quests_class"] = "Afficher les quêtes de classe",
	["lang_quests_class_tip"] = "Affiche les quêtes de classe étant visibles.",
	["lang_quests_crafting"] = "Afficher les quêtes d'artisanat",
	["lang_quests_crafting_tip"] = "Affiche les quêtes d'artisanat étant visibles.",
	["lang_quests_group"] = "Afficher les quêtes de groupe",
	["lang_quests_group_tip"] = "Affiche les quêtes de groupe étant visibles.",
	["lang_quests_dungeon"] = "Afficher les quêtes de donjon",
	["lang_quests_dungeon_tip"] = "Affiche les quêtes de donjon étant visibles.",
	["lang_quests_raid"] = "Afficher les quêtes de raid",
	["lang_quests_raid_tip"] = "Affiche les quêtes de raid étant visibles.",
	["lang_quests_AVA"] = "Afficher les quêtes AVA",
	["lang_quests_AVA_tip"] = "Affiche les quêtes AVA étant visibles.",
	["lang_quests_event"] = "Afficher les quêtes d'événement/vacances",
	["lang_quests_event_tip"] = "Affiche les quêtes d'événement/vacances visibles.",
	["lang_quests_BG"] = "Afficher les quêtes de champ de bataille",
	["lang_quests_BG_tip"] = "Affiche les quêtes du champ de bataille.",
	["lang_area_hybrid"] = "Afficher la zone de catégorie",
	["lang_area_hybrid_tip"] = "Affiche les zones dans l'affichage Catégorie classique, par exemple, les quêtes de guilde répertoriées dans sa propre catégorie et non la zone dans laquelle elles se trouvent.",

	["lang_no_trans_focused_zone"] = "Transparence de la zone de quête suivie",
	["lang_no_trans_focused_zone_tip"] = "La zone ou la catégorie dans laquelle se trouve la quête suivie n'utilisera pas la transparence non suivie.",
	
	["lang_quests_settings"] = "Paramètres des quêtes",
	["lang_quests_sort"] = "Trier les quêtes par...",
	["lang_quests_nb"] = "Nombre de quêtes affichées pour la même zone",
	["lang_quests_show_timer"] = "Afficher la minuterie de quête",
	["lang_quests_show_timer_tip"] = "Affiche la minuterie de la quête suivie lorsqu'il y a un chronomètre de complétion. Veuillez noter qu'un champ vide apparaîtra à la fin.",
	
	

	["lang_quests_hide_obj"] = "Masquer les objectifs/indices non suivis",
	["lang_quests_hide_obj_tip"] = "Masque les objectifs et les indices de toutes les quêtes, sauf ceux de la quête suivie.",
	
	["lang_quests_hide_obj_optional"] = "Masquer les indices/objectifs terminés",
	["lang_quests_hide_obj_optional_tip"] = "Masque les objectifs et indices optionnels des quêtes qui ont été complétés pour toutes les quêtes.",
	
	["lang_quests_level"] = "Afficher le niveau des quêtes",
	["lang_quests_optinfos"] = "Masquer TOUS les indices/infos optionnels",
	["lang_quests_autoshare"] = "Partage automatique des quêtes",
	["lang_quests_autountrack"] = "Masquer auto. les quêtes non suivies",
	["lang_icon_opt"] = "Activer l'icône du suivi de quête",
	["lang_icon_texture"] = "Texture de l'icône du suivi de quête",
	["lang_icon_size"] = "Taille de l'icône du suivi de quête",
	["lang_icon_color"] = "Couleur de l'icône du suivi de quête",
	["lang_quests_transparency_opt"] = "Activer la transparence pour les quêtes non suivies.",
	["lang_quests_transparency"] = "Transparence des quêtes non suivies",

	["lang_titles_settings"] = "Paramètres de nom de quête",
	["lang_titles_font"] = "Police du nom de la quête",
	["lang_titles_style"] = "Style de police du nom de la quête",
	["lang_titles_size"] = "Taille de la police du nom de la quête",
	["lang_titles_padding"] = "Taille du remplissage du nom de la quête",
	["lang_titles_default"] = "Couleur du nom de quête par défaut",
	["lang_titles_custom"] = "Couleurs des titres personnalisés",
	["lang_titles_veasy"] = "Couleur du nom d'une quête très facile",
	["lang_titles_easy"] = "Couleur du nom d'une quête facile",
	["lang_titles_normal"] = "Couleur du nom d'une quête normale",
	["lang_titles_hard"] = "Couleur du nom d'une quête difficile",
	["lang_titles_vhard"] = "Couleur du nom d'une quête très difficile",

	["lang_obj_settings"] = "Paramètres des objectifs/indices",
	["lang_obj_font"] = "Police des objectifs",
	["lang_obj_style"] = "Style de la police des objectifs",
	["lang_obj_size"] = "Taille de la police des objectifs",
	["lang_obj_padding"] = "Taille du remplissage des objectifs",
	["lang_obj_color"] = "Couleur de la police des objectifs",
	["lang_obj_ccolor"] = "Couleur de la police des objectifs complétés",
	["lang_obj_optcolor"] = "Couleur de la police des objectifs optionnels",
	["lang_obj_optccolor"] = "Couleur de la police des obj. opt. terminés",

	["lang_infos_settings"] = "Paramètres d'informations",
	["lang_infos_font"] = "Afficher les informations",
	["lang_infos_style"] = "Style de la police des informations",
	["lang_infos_size"] = "Taille de la police des informations",
	["lang_infos_color"] = "Couleur de la police des informations",
	
	["lang_NumbQuest_opt"] = "Afficher le nombre de quêtes",
	["lang_NumbQuest_opt_tip"] = "Affiche le nombre de quêtes commencées et le nombre total de quêtes.",
	["lang_ShowClock_opt"] = "Afficher l'horloge",
	["lang_ShowClock_opt_tip"] = "Afficher l'horloge en haut à gauche du suivi des quêtes.",
	["lang_ShowTbutton_opt"] = "Afficher l'icône de raccourci du suivi de quête",
	["lang_ShowTbutton_opt_tip"] = "Affiche l'icône avec le raccourci clavier pour changer la quête suivie.",
	["lang_ShowMQbutton_opt"] = "Afficher l'icône de raccourci de mini-quête suivie",
	["lang_ShowMQbutton_opt_tip"] = "Affiche l'icône avec le raccourci clavier pour changer la mini-quête suivie.",
	



	-- Menu tips
	["lang_language_settings_tip"] = "Détermine votre langue.",
	["lang_preset_settings_tip"] = "Sélectionne un préréglage.",
	["lang_overall_transparency_tip"] = "Modifie la transparence globale.",
	["lang_overall_width_tip"] = "Modifie la largeur de la fenêtre.",
	["lang_position_lock_tip"] = "Verrouille/Déverrouille la position de la fenêtre et active les actions de la souris.",
	["lang_backgroundcolor_opt_tip"] = "Active le fond.",
	["lang_backgroundcolor_value_tip"] = "Modifie la couleur de fond.",
	
	["lang_mouse_1_tip"] = "Détermine une action pour le clic gauche.",
	["lang_mouse_2_tip"] = "Détermine une action pour le clic de la molette.",
	["lang_mouse_3_tip"] = "Détermine une action pour le clic droit.",
	["lang_mouse_4_tip"] = "Détermine une action pour le bouton 4.",
	["lang_mouse_5_tip"] = "Détermine une action pour le bouton 5.",
	
	["lang_area_name_tip"] = "Active l'affichage du nom de la zone/catégorie de la quête.",
	["lang_area_font_tip"] = "Détermine la police de la zone/catégorie de la quête.",
	["lang_area_style_tip"] = "Détermine le style de police pour la zone/catégorie de la quête.",
	["lang_area_size_tip"] = "Modifie la taille de la police de la zone/catégorie de la quête.",
	["lang_area_padding_tip"] = "Modifie la taille de remplissage gauche et droite pour la zone/catégorie de la quête.",
	["lang_area_color_tip"] = "Modifie la couleur de la zone/catégorie de la quête.",
	["lang_autohidequestzone_option_tip"] = "Se focalise sur la quête suivie et masque les autres quêtes de zones/catégories.",
	["lang_questzone_option_tip"] = "Affiche les quêtes dans la zone/catégorie actuelle pour la quête ciblée.",
	["lang_quests_guild_tip"] = "Affiche les quêtes des guildes.",
	["lang_quests_mainstory_tip"] = "Affiche les quêtes de l'histoire principale.",
	["lang_quests_cyrodiil_tip"] = "Affiche les quêtes de Cyrodiil.",

	["lang_quests_sort_tip"] = "Détermine l'ordre des quêtes.",
	["lang_quests_nb_tip"] = "Modifie le nombre de quêtes affichées pour la même zone que la quête en cours.",
	["lang_quests_show_quest_timer_tip"] = "Affiche la minuterie pour les quêtes chronométrées.",
	["lang_quests_level_tip"] = "Affiche le niveau des quêtes.",
	["lang_quests_optinfos_tip"] = "Masque les informations et indices cachées pour toutes les quêtes, y compris la quête suivie.",
	["lang_quests_autoshare_tip"] = "Active le partage automatique de quête lorsque vous êtes en groupe.",
	["lang_quests_autountrack_tip"] = "Masque sur la boussole toutes les quêtes qui ne sont pas suivies.",
	["lang_icon_opt_tip"] = "Active l'icône du suivi de la quête.",
	["lang_icon_texture_tip"] = "Détermine l'icône du suivi de la quête en cours.",
	["lang_icon_size_tip"] = "Modifie la taille de l'icône du suivi de la quête.",
	["lang_icon_color_tip"] = "Modifie la couleur de l'icône du svuivi de la quête.",
	["lang_quests_transparency_opt_tip"] = "Active la transparence pour les autres quêtes hormis la quête suivie.",
	["lang_quests_transparency_tip"] = "Détermine la transparence des quêtes qui ne sont pas suivies.",
	
	["lang_titles_font_tip"] = "Détermine la police des noms de quête.",
	["lang_titles_style_tip"] = "Détermine le style de la police des noms de quête.",
	["lang_titles_size_tip"] = "Modifie la taille de la police des noms de quête.",
	["lang_titles_padding_tip"] = "Modifie la taille de remplissage gauche et droite pour les noms de quête.",
	["lang_titles_default_tip"] = "Modifie la couleur des noms de quête.",
	["lang_titles_custom_tip"] = "Active la modification de couleur en fonction du niveau du joueur.",
	["lang_titles_veasy_tip"] = "Modifie la couleur des noms de quête < niveau - 4.",
	["lang_titles_easy_tip"] = "Modifie la couleur des noms de quête <= niveau - 2.",
	["lang_titles_normal_tip"] = "Modifie la couleur des noms de quête = niveau +- 1.",
	["lang_titles_hard_tip"] = "Modifie la couleur des noms de quête >= niveau + 2.",
	["lang_titles_vhard_tip"] = "Modifie la couleur des noms de quête > niveau + 4.",
	
	["lang_obj_font_tip"] = "Détermine la police du texte de la quête.",
	["lang_obj_style_tip"] = "Détermine le style de la police du texte de la quête.",
	["lang_obj_size_tip"] = "Modifie la taille de la police du texte de la quête.",
	["lang_obj_padding_tip"] = "Modifie la taille de remplissage gauche et droite pour le texte de la quête.",
	["lang_obj_color_tip"] = "Modifie la couleur du texte de la quête.",
	["lang_obj_ccolor_tip"] = "Modifie la couleur du texte des objectifs complétés.",
	["lang_obj_optcolor_tip"] = "Modifie la couleur du texte de quête optionnel.",
	["lang_obj_optccolor_tip"] = "Modifie la couleur du texte des objectifs optionnels complétés.",

	["lang_infos_opt_tip"] = "Affiche le total des quêtes en cours.",
	["lang_infos_font_tip"] = "Détermine la police des informations.",
	["lang_infos_style_tip"] = "Détermine le style de la police des informations.",
	["lang_infos_size_tip"] = "Modifie la taille de la police des informations.",
	["lang_infos_color_tip"] = "Modifie la couleur de la police des informations.",
	
	-- Menu Warn
	["lang_menu_warn_1"] = "|c8B1E1E Modifier cette option rechargera l'UI",
	["lang_menu_warn_2"] = "|c8B1E1E Modifier cette option rechargera l'UI et écrasera vos paramètres actuels",
	

	-- Mouse Interactions
	["lang_mouse_ctrl_assisted"] = "Modifie la quête suivie",
	["lang_mouse_ctrl_filterzone"] = "Filtrer par zone actuelle",
	["lang_mouse_ctrl_share"] = "Partager une quête",
	["lang_mouse_ctrl_showmap"] = "Afficher sur la carte",
	["lang_mouse_ctrl_remove"] = "Supprimer une quête",
	
	-- Console
	["lang_console_autoshare"] = "Vous partagez automatiquement une quête",
	["lang_console_share"] = "Vous partagez une quête",
	["lang_console_noshare"] = "Cette quête n'est pas partageable",
	["lang_console_abandon"] = "Abandonner la quête",
	["lang_choose"] = "Choisir: ",









----------------------------------- NEW STUFF

	["lang_tmp_VEQMessage"] = "<<1>>: <<2>>",
	["lang_tmp_VEQMessage_Error"] = "ERREUR <<1>>: <<2>>",


	-- Quests Infos
	["quest_optional"] = "Optionnel",
	["quest_hint"] = "Indice",
	["quest_hiddenhint"] = "Indice caché",
	
	["lang_tracker_type_guild"] = "Guilde",
	["lang_tracker_type_mainstory"] = "Histoire Principale",
	["lang_tracker_type_undaunted"] = "Indomptables",
	["lang_tracker_type_prologue"] = "Prologue",	
	["lang_tracker_type_companion"] = "Compagnon",
	["lang_tracker_type_repeatable"] = "Répétable",
	["lang_tracker_type_daily"] = "Journalière",
	["lang_tracker_type_solo"] = "Solo",
	["lang_tracker_type_dungeon"] = "Donjon",
	["lang_tracker_type_class"] = "Classe",
	["lang_tracker_type_craft"] = "Artisanat",
	["lang_tracker_type_group"] = "Groupe",
	["lang_tracker_type_ava"] = "Guerre d'alliance",
	["lang_tracker_type_arena"] = "Arène",
	["lang_tracker_type_holiday_event"] = "Évènement de vacances",
	["lang_tracker_type_raid"] = "Épreuve",
	["lang_tracker_type_bg"] = "Champ de bataille",
	["lang_tracker_type_qa_test"] = "Tester",
	["lang_tracker_type_dark_brotherhood"] = "Confrérie noire",
	["lang_tracker_type_thieves_guild"] = "Guilde des voleurs",
	["lang_tracker_type_mages_guild"] = "Guilde des mages",
	["lang_tracker_type_fighters_guild"] = "Guilde des guerriers",
	["lang_tracker_type_psijic_order"] = "Ordre Psijique",
	
	-- Inventory
	["lang_slots_inventory"] = " Emplacements restants dans l'inventaire",
	["lang_slot_inventory"] = " Emplacement restant dans l'inventaire",
	["lang_free_space"] = "Libérez de l'espace",
	["lang_inventory_full"] = "L'inventaire est complet !",
	
	-- Treasure
	["lang_survey_map"] = "Repérage d'artisan",
	["lang_treasure_map"] = "Carte au trésor",
	["lang_get_materials"] = "Prendre les matériaux",
	["lang_get_treasure"] = "Prendre le trésor",
	
	-- Skyshards
	["lang_skyshard"] = "Éclat céleste",
	["lang_maway"] = "m de distance",
	["lang_distant_sky"] = "Présence imperceptible de magie éthérée",
	["lang_weak_sky"] = "Faible présence de magie éthérée",
	["lang_moderate_sky"] = "Présence modérée de magie éthérée",
	["lang_strong_sky"] = "Forte présence de magie éthérée",
	["lang_huge_sky"] = "Énorme présence de magie éthérée",
	
	-- Leads / antiquities
	["lang_scry_exc"] = "Sonder et fouiller dans ",
	["lang_antiquity_"] = "Antiquité - ",
	
	-- Doable writs
	["lang_check_inv"] = "Vérifier votre inventaire pour commencer à fabriquer",
	["lang_doable"] = "Fabricable ",
	["lang_or"] = " ou ",
	
	-- Riding skills
	["lang_stable_rel"] = "Une relation durable",
	["lang_upgrade_skills"] = "Améliorez l'une de vos compétences d'équitation",
	["lang_stablemaster"] = "Maîtresse des écuries",
	
	-- Backpack & Bank upgrade
	["lang_backpack_upgrade"] = "Amélioration du sac",
	["lang_you_have_the"] = "Vous avez les",
	["lang_up_back"] = " or ! Améliorez votre sac",
	["lang_pack_merchant"] = "Marchand de sacs",
	["lang_bank_space_upgrade"] = "Amélioration de l'espace de banque",
	["lang_up_bank"] = " or ! Améliorez votre espace de banque",
	["lang_bank_mon"] = "Banquier ou Prêteur",
	
	-- Endeavor	
	["lang_endeavor_week"] = "Efforts hebdomadaire",
	["lang_endeavor_day"] = "Efforts journalier",
	
	-- Event Tickets & transmute crystals
	["lang_event_tickets"] = "Tickets d'événement",
	["lang_transmute_crystals"] ="Cristaux de transmutation",
	["lang_maxed_out_currency"] = "Cette devise est au maximum ! Dépensez-en.",
	["lang_nears_max_currency"] = "Cette devise se rapproche du maximum autorisé, dépensez-en.",
	
	
	-- LFG & ready check
	["lang_in"] = " dans ",
	["lang_champion_battleground"] = "Champ de bataille des champions",
	["lang_low_battleground"] = "Champ de bataille de bas niveau",
	["lang_non_battleground"] = "Champ de bataille non champion",
	["lang_normal_dungeon_finder"] = "Recherche de donjon "..GetString(SI_DUNGEONDIFFICULTY1),
	["lang_veteran_dungeon_finder"] = "Recherche de donjon "..GetString(SI_DUNGEONDIFFICULTY2),
	["lang_tribute_casual"] = "Récits de Gloires simple",
	["lang_tribute_competitive"] = "Récits de Gloires compétitif",
	["lang_lfg"] = "Recherche de groupe...",
	["lang_lfo"] = "Recherche d'adversaire...",
	["lang_everybody_ready"] = "Est-ce que tout le monde est prêt ?",
	["lang_ready"] = " prêt",
	["lang_grc"] = "Appel de préparation",
	["lang_for"] = " pour ",
	["lang_LFR"] = "Recherche de remplacement",
	
	-- Entering campaign
	["lang_cyrodiil"] = "Cyrodiil - ",
	["lang_group"] = "Groupe - ",
	["lang_ewt"] = "\n• Temps d'attente restant: ",
	["lang_entering_campaign"] = "Entrer dans la campagne...",
	["lang_n_started"] = "\n• A débuté ",
	["lang_ago"] = " depuis",
	["lang_confirming"] = "Confirmation",
	["lang_finished"] = "Finie", 
	["lang_pending_accept"] = "Entrer...",
	["lang_pending_join"] = "En attente de rejoindre",
	["lang_leaving_queue"] = "Quitter la file d'attente",
	["lang_exiting_campaign"] = "Quitter la campagne...",
	["lang_waiting"] = "En attente",
	["lang_n_queue_position"] = "\n• Position dans la file d'attente ",
	
    -- Poison checker / equip / notifier	
	["lang_out_of_poison"] = "Sortez du poison !",
	["lang_craft_some_poison"] = "Fabriquez ou achetez du poison et équipez-le sur votre arme",
	["lang_alchemy_station"] = "Station d'alchimie",
	
    -- Psijic Time Breaches helper
    ["lang_psijic_time_breach"] = "Faille temporelle Psijique #",
	["lang_6172_helper_9"] = "Halfway between the Augury Basin and Keelsplitter's Nest (Go West from Ebon Stadmont wayshrine, jump into the pond and follow the stream, the breach is at the foot of the waterfall)",	
	["lang_6172_helper_8"] = "Between Keelsplitter's Nest and Rellenthil Abyssal Geyser, on the tiny island with the tree (South from Ebon Stadmont wayshrine)",
	["lang_6172_helper_7"] = "In a ruined structure west of Alinor, halfway between Welenkin Cove and Welenkin Abyssal Geyser (Go down the cobblestone path South from Cey-Tarn Keep wayshrine, keep right at each fork including the broken bridge leading to the structure)",
	["lang_6172_helper_6"] = "Inside the Direnni Acropolis, after the bridge (Go down the cobblestone path Southeast from King's Haven Pass wayshrine, keep left at the fork)",
	["lang_6172_helper_5"] = "Below the waterfall west of Shimmerene (Gallop North from Shimmerene wayshrine and jump in the water the farthest you can)",
	["lang_6172_helper_4"] = "In the ruins on the hill, North of the lake by Archon's Grove, East of Keep of the Eleven Forces (Go South from the Shimmerene wayshrine)",
	["lang_6172_helper_3"] = "In one of the enclosures in Sil-Var-Woad (Go South from the Sil-Var-Woad wayshrine, enter the zoo, keep right at the fork, in the water enclosure)",
	["lang_6172_helper_2"] = "On the East shore of the island Southeast of Sil-Var-Woad, Southeast of the Sil-Var-Woad Abyssal Geyser, nearby the two Northmost tiny islands",
	["lang_6172_helper_1"] = "South of Sunhold Wayshrine, West of the Sunhold Abyssal Geyser",
	
	
	["lang_6181_helper_9"] = "On a cliff overlooking Deleyn's Mill, North of Daenia Dolmen (Head South from Baelborne Rock wayshrine, run in the river, under the bridge, then head Southeast, the breach is a bit farther than the painting easel)",
	["lang_6181_helper_8"] = "Between the roots on the North side of the Beldama Wyrd Tree (Wyrd Tree wayshrine)",
	["lang_6181_helper_7"] = "On a bluff on the West side of Burial Mounds (Go Southwest from Crosswych wayshrine until the huge bad weed and then head South-southeast on top of the bluff)",
	["lang_6181_helper_6"] = "Inside the Southmost part of a shipwreck on the West side of the Koeglin Lighthouse island (Go West-southwest from Bonesnap Ruins wayshrine)",
	["lang_6181_helper_5"] = "On the edge of the highest tier of Cumberland Falls (Go west from Wind Keep wayshrine, follow the river upstream to the waterfall, and climb at it's top)",
	["lang_6181_helper_4"] = "Just west of Moonlit Maw (Go North from Pariah Abbey wayshrine)",
	["lang_6181_helper_3"] = "On the edge of a cliff north of Salas En, northeast of The Warrior, overlooking Rain Catcher Fields (Go West from Morwha's Bounty wayshrine, climb, go West again to the edge of the cliff)",
	["lang_6181_helper_2"] = "Against a cliff wall west of Easterly Aerie (Go West from Kulati Mines wayshrine, surround the rock to the right, take the bridge, go left to climb on the higher platform)",
	["lang_6181_helper_1"] = "Between HoonDing's Watch and Ragnthar (Go South from HoonDing's Watch wayshrine, climb the sand on your left when you can, go South again)",
	
	
	["lang_6185_helper_9"] = "Between the two Southmost lava Streams on the West side of Senie (Go West from Senie wayshrine)",
    ["lang_6185_helper_8"] = "On an tiny Island at the top of the Waterfall between Brothers of Strife and Armature's Upheaval (Go Southwest from Brothers of Strife wayshrine)",
    ["lang_6185_helper_7"] = "On top of the ridge above Vivec's Antlers between Sulfur Pools wayshrine and Vivec's Antlers (Go East from Sulfur Pools wayshrine)",
    ["lang_6185_helper_6"] = "Next to one of the larger steam pools at Wittestadr (Go Northeast from Wittestadr wayshrine, the breach is exactly at the Wittestadr icon on the map)",
    ["lang_6185_helper_5"] = "Between the two Waterfalls upstream the river Southwest of Darkwater Crossing, Southeast of the Fort Amol map (Go Southeast from Fort Amol wayshrine)",
    ["lang_6185_helper_4"] = "In the river West the bridge East of Cradlecrush, Northwest of Thane Jeggi's Drinking Hole (Go Southwest from Fort Morvunskar wayshrine and follow the cobblestone road, keep left at the fork, look on your right at the bridge)",
    ["lang_6185_helper_3"] = "Northeast of Fort Greenwall, Southwest of Troll Cave (Go through Fort Greenwall North from Riften wayshrine, and then Northeast)",
    ["lang_6185_helper_2"] = "Just outside Snapleg Cave (Cross the bridge North of Nimalten wayshrine and continue along the river to the cave)",
    ["lang_6185_helper_1"] = "At the top of the steps near the Throat of the World, Northwest of Ivarstead (Go West-southwest from Geirmund's Hall wayshrine, cross the bridge and follow the plethora of steps)",	
	

    ["lang_6197_helper_adamantine"] = "Go Southwest from Eastern Evermore wayshrine, use the Time Breach in Pelin Graveyard, follow the Psijic sight, dig up the staff piece",
	["lang_6197_helper_orichalc"] = "Go Southwest of Leki's Blade wayshrine, use the Time Breach North of Leki's Blade, follow the Psijic sight, dig up the staff piece",
	["lang_6197_helper_crystal"] = "Go North of the Hatching Pools wayshrine, use the Time Breach in Hatching Pools (under the Great Hist Tree), follow the Psijic sight, dig up the staff piece",
	["lang_6197_helper_walk"] = "Go South from Selfora wayshrine, use the Time Breach near Fang Spires, follow the Psijic sight, dig up the staff piece",
	
	["lang_6197_helper_pelin"] = "Staff Fragment near Pelin Graveyard",
	["lang_6197_helper_leki"] = "Staff Fragment near Leki's Blade",	
	["lang_6197_helper_hist"] = "Staff Fragment near the Hist",
	["lang_6197_helper_fang"] = "Staff Fragment near Fang Spires",	
	
	
	["lang_6194_helper_9"] = "In a ruined structure on the West side of the Ossuary of Telacar (Go North-northwest from Ossuary wayshrine)",
	["lang_6194_helper_8"] = "Inside the stump of Gil-Var-Delle, West of the Dolmen (Go South from Gil-Var-Delle wayshrine)",
	["lang_6194_helper_7"] = "Inside the highest tower ruin, North of Reman's Bluff (Go West-southwest from Redfur Trading Post wayshrine)",
	["lang_6194_helper_6"] = "On a promontory north of Maormer Camp (Cross the very bridge North-northwest of Moonhenge wayshrine, follow the cobblestone road, go straight ahead to the edge of the cliff when the road turns right)",
	["lang_6194_helper_5"] = "North of Fisherman's Rest (Surround the mountain by West from Serpent's Grotto wayshrine)",
	["lang_6194_helper_4"] = "Within the Labyrinth, just north of the center (Take the very bridge North from Greenheart wayshrine, continue straight ahead without following the road, follow it when it's back under your feet, take the 1st Labyrinth entrance on your left, go right at the 1st fork and left at the 2nd)",
	["lang_6194_helper_3"] = "Under a bridge south of Treehenge, west of Ragnthar (Follow the path North of Wilding Run wayshrine until you reach the bridge, jump)",
	["lang_6194_helper_2"] = "In the middle of Horseshoe Island (Go North from Vulkwasten wayshrine)",
	["lang_6194_helper_1"] = "On the island Northeast of Xylo River Basin Dolmen (Go North from Abamath wayshrine)",

	["lang_6190_helper_9"] = "On the cliff south of Bthanual (Follow the road East from Muth Gnaar Hills wayshrine, cross the bridge, keep left at the fork, go South before Bthanual entrance)",
	["lang_6190_helper_8"] = "By the waterfall Northeast of Darkshade Caverns (Go Southwest from Silent Mire wayshrine, climb the rock to the higher platform)",
	["lang_6190_helper_7"] = "In a planter in the middle of the Shrine of Saint Veloth (Follow the road Northwest from Eidolon's Hollow wayshrine, keep left at the 1st fork and right at the 2nd one)",
	["lang_6190_helper_6"] = "On a tiny island by the waterfalls Northeast of The Triple Circle Mine (Go South from Shad Astula wayshrine, swim, jump down the waterfall, swim)",
	["lang_6190_helper_5"] = "Behind the huge gates of Malak's Maw (Go West from West Narsis wayshrine and do a full lap clockwise)",
	["lang_6190_helper_4"] = "Under a tree's roots in the Southwest corner in Bogmother (Go West from Bogmother wayshrine)",
	["lang_6190_helper_3"] = "Inside a stone mouth in western Hei-Halai, near the entrance to the Ruins of Mazzatun (Follow the road North from Stillrise wayshrine, when you see a tower ruin on your left next to the road  go Northwest, Then follow the path on your left to the stone mouth)",
	["lang_6190_helper_2"] = "In a small xanmeer Northwest of the Venomous Fens Dolmen (Go Southeast from Loriasel wayshrine)",
	["lang_6190_helper_1"] = "At the foot of the Hist tree in the middle of Percolating Mire (Go Northeast from Percolating Mire wayshrine)",


	
	["lang_6198_helper_red"] = "Go South of Brothers of Strife wayshrine, use the Time Breach, follow the Psijic sight, dig up the staff piece",
	["lang_6198_helper_white"] = "Go Northwest from Weeping Giant wayshrine until the tower ruin, then follow the path on your right, cross the planks bridge, use the Time Breach, follow the Psijic sight, dig up the staff piece",
    ["lang_6198_helper_greensap"] = "Go North of Greenheart Wayshrine wayshrine, use the Time Breach, follow the Psijic sight, dig up the staff piece",
    ["lang_6198_helper_snow"] = "Go East from Spellscar wayshrine, between the rock cliff and Adament Anomaly, at the end of the rock cliff, turn left, use the Time Breach, follow the Psijic sight, dig up the staff piece",

	["lang_6198_helper_bro"] = "Staff Fragment near the Brothers of Strife",
	["lang_6198_helper_weep"] = "Staff Fragment near the Weeping Giant",	
	["lang_6198_helper_green"] = "Staff Fragment near Greenheart",
	["lang_6198_helper_spell"] = "Staff Fragment near Spellscar",	
	
	
	["lang_6468_helper_9"] = "On the wall West of Trader's Rest (Go Northeast from Oldgate wayshrine)",
    ["lang_6468_helper_8"] = "At Sanguine Barrows, between the central tomb and Tribulation Crypt (Go North from Sanguine Barrows wayshrine)",
    ["lang_6468_helper_7"] = "In front of the Northern tower at Lorkrata Hills (Go West from Fell's Run wayshrine, once inside Lorkrata Hills walls take the stairs on your right)",
    ["lang_6468_helper_6"] = "In a field at Edrald Estate (Go East-southeast from Fell's Run wayshrine)",
    ["lang_6468_helper_5"] = "On an island West of East-Rock Landing, North of Orc's Finger Ruins, Southwest of the Serpent (Go East from Boralis wayshrine)",
	["lang_6468_helper_4"] = "In the captain's cabin of Lagra's Pearl (Go Northeast from Northpoint wayshrine)",
	["lang_6468_helper_3"] = "In front of the Chapel Crypts at Crestshade (Follow the cobblestone road South from the Crestshade wayshrine, at the statue, go Southwest and go up the stairs, the other set of stairs on the left, continue straight ahead to the stairs of  the Chapel Crypts)",
	["lang_6468_helper_2"] = "Just west of Aesar's Web (Go West of Tamrith Camp wayshrine)",
	["lang_6468_helper_1"] = "Inside Shadowfate Cavern (The entrance is between Aesar's Web and Tamrith Camp wayshrine)",
	

	["lang_6196_helper_6"] = "Northeast of Ogondar's Winery, West of Rkundzelft (Go East from Spellscar wayshrine, between the rock cliff and Adament Anomaly, at the end of the rock cliff go Southeast)",
	["lang_6196_helper_5"] = "Outside the Northwest corner of Elinhir (Go South from Elinhir wayshrine, surround Elinhir rock cliff by the right until you find the breach)",
	["lang_6196_helper_4"] = "In a crevice at the South end of Scorpion Ravine (Go Southwest from Seeker's Archive wayshrine)",
	["lang_6196_helper_3"] = "North of Hel Ra Citadel, East of Mtharnaz (Go West from Sandy Path wayshrine)",
	["lang_6196_helper_2"] = "In front of Dragonstar Arena (Dragonstar wayshrine)",
	["lang_6196_helper_1"] = "On the bridge to Skyreach Hold (Skyreach wayshrine)",
	
	["lang_6199_helper"] = "From Goat's Head Oasis wayshrine, climb the stairs then go Southwest to Divad's Chagrin mine",
	
	
	-- Group frames
	["lang_of"] = " de ",
	
	-- Museum Pieces
	["lang_museum"] = "Rendre",

	-- Dailies counter
	["lang_repeatable_quests"] = "Quêtes répétables",
	["lang_ongoing"] = "En cours: ",
	["lang_completed_today"] = "Complétée(s) aujourd'hui: ",
	
	-- zone todo list
	["lang_todolist"] ="Zone to-do list",
	
	
	-- remains silent
	["lang_remains_silent"] = "<You nod knowingly.>",
	
	-- Dragonguard Supply chest name (change to your language for the feature to work)
	["lang_dragonguard_supply_chest"] = "Dragonguard Supply Chest",
	
	-- mini tracker settings
	["lang_mini_quest_tracker_settings"] = "Paramètres du suivi des mini-quêtes",
	["lang_mini_quest_tracker_invert_opt"] = "Invert key",
	["lang_mini_quest_tracker_invert_tip"] = "Get previous Mini quest instead of next by long pressing that key while presing the default keybind",
	["lang_inventory_slots_opt"] = "Mini-quête des emplacements d'inventaire vides",
	["lang_inventory_slots_tip"] = "Une mini-quête pour vider votre inventaire lorsque cela atteint la limite minimale d'emplacements vides que vous avez configurée.",
	["lang_inventory_slots_limit"] = "Minimum d'emplacements d'inventaire gratuits",
	["lang_inventory_slots_limit_tip"] = "Nombre d'emplacements d'inventaire gratuits minimum pour déclencher la mini-quête.",	
	["lang_lost_treasure_opt"] = "Mini-quête de trésor perdu",
	["lang_lost_treasure_tip"] = "Ajoute une mini-quête pour les cartes au trésor et les lieux d'enquête dès qu'ils apparaissent dans votre sac (parfait avec l'addon Lost Treasure).",	
	["lang_skyshards_opt"] = "Mini-quête des éclats célestes",
	["lang_skyshards_tip"] = "Ajoute une mini-quête pour obtenir un éclat céleste s'il est à moins de 100 m.",	
    ["lang_leads_opt"] = "Mini-quête des pistes",
	["lang_leads_tip"] = "Ajoute une mini-quête pour aller sonder et fouiller une antiquité pour chacune des pistes que vous avez.",
	["lang_fake_leads_opt"] = "Scrying and Excavating progression",
	["lang_fake_leads_tip"] = "Daily adds a mini quest to go scrying and excavating an antiquity for a smooth progression of these skill lines",
	["lang_writs_opt"] = "Mini-quête des commandes réalisables",
	["lang_writs_tip"] = "Ajoute une mini-quête pour chaque commande réalisable (avoir les connaissances + avoir les matériaux) dans votre inventaire. (Nécessite l'addon WritWorthy installé pour fonctionner).",
	["lang_stable_opt"] = "Mini-quête d'amélioration de l'équitation",
	["lang_stable_tip"] = "Ajoute une mini-quête pour améliorer vos compétences d'équitation dès que vous remplissez les conditions.",
	["lang_backbank_opt"] = "Mini-quête d'amélioration du sac et de la banque",
	["lang_backbank_tip"] = "Ajoute une mini-quête pour améliorer votre inventaire ou votre espace de banque dès que vous avez l'or requis.",
	["lang_endeavor_opt"] = "Mini-quête d'Efforts journalier et hebdomadaire",
	["lang_endeavor_tip"] = "Ajoute chaque Effort journalier et hebdomadaire en tant que mini-quête.",
	["lang_goldenPursuit_opt"] = "Golden Pursuit Mini Quest",
	["lang_goldenPursuit_tip"] = "Adds each Golden Pursuit as a mini quest.",
	["lang_communityEvents_opt"] = "Community Event Mini Quest",
	["lang_communityEvents_tip"] = "Adds each Community Event as a mini quest.",
	["lang_tickets_opt"] = "Mini-quête de dépense des tickets d'événement",
	["lang_tickets_tip"] = "Une mini-quête pour dépenser vos tickets d'événement lorsque cela atteint la limite minimale restante que vous avez configurée.",
	["lang_tickets_limit"] = "Minimum de tickets d'événement restants",
	["lang_tickets_limit_tip"] = "Nombre de tickets d'événement minimum restant à atteindre pour déclencher la mini-quête.",
	["lang_transmute_opt"] = "Mini-quête des cristaux de transmutation",
	["lang_transmute_tip"] = "Une mini-quête pour dépenser vos cristaux de transmutation lorsque cela atteint la limite minimale restante que vous avez configurée.",	
	["lang_transmute_limit"] = "Minimum de cristaux de transmutation restants",
	["lang_transmute_limit_tip"] = "Nombre de cristaux de transmutation minimum restant à atteindre pour déclencher la mini-quête.",
    ["lang_zoneguide_opt"] = "Détermine la prochaine quête du guide de zone",
	["lang_zoneguide_tip"] = "Les mini-quêtes du guide de zone s'activent automatiquement et deviennent une mini-quête dans VEQ lors du changement de zone et si vous n'avez pas de quête active dans cette zone.",	
    ["lang_POIcompletion_opt"] = "Set undiscovered zone Points of interest as a Mini Quest",
	["lang_POIcompletion_tip"] = "One Undiscovered zone Point of interest becomes a mini quest in VEQ on zone change",
    ["lang_poison_opt"] = "Vérificateur de Poison",
	["lang_poison_tip"] = "Vérifie les emplacements de poison de votre arme après chaque combat, si vous n'avez plus de poison, une mini-quête pour fabriquer du poison s'affichera.",	
	["lang_group_frames_opt"] = "Noms des membres du groupe comme barres de vie",
	["lang_group_frames_tip"] = "Affiche les noms des compagnons et des membres du groupe sous forme de barres de vie colorées.",
	["lang_default_group_frames_opt"] = "Masquer les barres de groupe par défaut du jeu",
	["lang_default_group_frames_tip"] = "Bascule cette commande en cas de conflit avec un autre addon concernant l'affichage des barres de groupe par défaut.",
	["lang_museum_pieces_opt"] = "Mini-quête des pièces de musée",
	["lang_museum_pieces_tip"] = "Ajoute une mini-quête pour ramener au musée chaque pièce de musée que vous avez dans votre inventaire.",
	["lang_dailies_counter_opt"] = "Compteur de quêtes quotidiennes",
	["lang_dailies_counter_tip"] = "Ajoute un compteur pour suivre la limite de 50 quêtes quotidiennes par jour et personnage.",
	["lang_NumbMiniQuest_opt"] = "Show number of mini quests",
	["lang_NumbMiniQuest_opt_tip"] = "Show number of mini quests",
	
}